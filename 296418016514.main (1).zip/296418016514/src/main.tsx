import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from 'sonner';
import App from "./App";
import "./index.css";

// 简单的错误处理函数
const handleError = (error: Error) => {
  console.error('应用初始化错误:', error);
};

// 包装渲染逻辑以捕获潜在错误
function renderApp() {
  try {
    const rootElement = document.getElementById("root");
    
    if (!rootElement) {
      throw new Error('未找到根元素 #root');
    }
    
    createRoot(rootElement).render(
      <StrictMode>
        <BrowserRouter>
          <App />
          <Toaster />
        </BrowserRouter>
      </StrictMode>
    );
  } catch (error) {
    handleError(error instanceof Error ? error : new Error('未知错误'));
    // 显示简单的错误信息给用户
    const errorElement = document.createElement('div');
    errorElement.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      padding: 16px;
      background-color: #ef4444;
      color: white;
      text-align: center;
      z-index: 9999;
    `;
    errorElement.textContent = '应用加载失败，请刷新页面重试';
    document.body.appendChild(errorElement);
  }
}

// DOM加载完成后渲染应用
document.addEventListener('DOMContentLoaded', renderApp);

// 确保即使DOMContentLoaded未触发也能渲染
if (document.readyState === 'interactive' || document.readyState === 'complete') {
  renderApp();
}
