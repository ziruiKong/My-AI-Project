import { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner';
import { generateId, formatTimestamp, generateConversationSummary, createCozeConversation } from '../lib/utils';

// 定义消息类型
interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'text' | 'image' | 'file';
  fileInfo?: {
    name: string;
    size: number;
    type: string;
    url?: string;
  };
  isFavorite?: boolean; // 添加收藏标记
  model?: 'deepseek-chat' | 'deepseek-reasoner' | 'kimi-k2'; // 消息创建时使用的模型
  processingTime?: number; // 处理时间（秒）
  // 保留字段以保持兼容性
}

// 定义对话类型
interface Conversation {
  id: string;
  title: string;
  timestamp: string;
  summary?: string; // 添加摘要字段
  firstMessage?: string; // 添加第一条消息字段
}

// 定义聊天上下文类型
interface ChatContextType {
  conversations: Conversation[];
  currentConversation: string | null;
  currentModel: 'deepseek-chat' | 'deepseek-reasoner' | 'kimi-k2';
  messages: Message[];
  favoriteMessages: Message[]; // 收藏的消息
  addMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
  createConversation: () => void;
  selectConversation: (id: string) => void;
  deleteConversation: (id: string) => void;
  getConversationHistory: (conversationId: string) => Array<{ role: string; content: string }>;
  setCurrentModel: (model: 'deepseek-chat' | 'deepseek-reasoner' | 'kimi-k2') => void;
  updateConversationSummary: (conversationId: string, messages: Message[]) => void;
  toggleFavorite: (messageId: string) => void; // 切换收藏状态
  currentProvider: 'deepseek' | 'coze';
  setCurrentProvider: (provider: 'deepseek' | 'coze') => void;
  stopGeneration: () => void; // 暂停生成的函数
  getCozeConversationId: (conversationId: string) => Promise<string>;
}

// 创建上下文
const ChatContext = createContext<ChatContextType | undefined>(undefined);

// 创建Provider组件
export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 从localStorage加载对话历史
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const saved = localStorage.getItem('conversations');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('加载对话历史失败:', error);
      return [];
    }
  });

  // 当前对话ID
  const [currentConversation, setCurrentConversation] = useState<string | null>(null);
  
  // 当前使用的模型
  const [currentModel, setCurrentModel] = useState<'deepseek-chat' | 'deepseek-reasoner' | 'kimi-k2'>(() => {
    try {
      const saved = localStorage.getItem('currentModel');
      return saved === 'deepseek-reasoner' || saved === 'kimi-k2' ? saved as 'deepseek-reasoner' | 'kimi-k2' : 'deepseek-chat';
    } catch (error) {
      console.error('加载当前模型设置失败:', error);
      return 'deepseek-chat';
    }
  });
  
   // 当前使用的AI服务提供商
  const [currentProvider, setCurrentProvider] = useState<'deepseek' | 'coze'>('deepseek');
  
  // Coze会话ID映射
  const [cozeConversationIds, setCozeConversationIds] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('cozeConversationIds');
      return saved ? JSON.parse(saved) : {};
    } catch (error) {
      console.error('加载Coze会话ID映射失败:', error);
      return {};
    }
  });
  
  // 收藏的消息
  const [favoriteMessages, setFavoriteMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem('favoriteMessages');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('加载收藏消息失败:', error);
      return [];
    }
  });
  
  // 保存当前模型到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('currentModel', currentModel);
    } catch (error) {
      console.error('保存当前模型设置失败:', error);
    }
  }, [currentModel]);
  
  // 保存当前AI服务提供商到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('currentProvider', currentProvider);
    } catch (error) {
      console.error('保存当前提供商设置失败:', error);
    }
  }, [currentProvider]);
  
    // 保存收藏的消息到localStorage，添加存储限制处理
    useEffect(() => {
        try {
            // 检查localStorage是否有足够空间
            const testKey = 'storage_test_' + Date.now();
            localStorage.setItem(testKey, JSON.stringify(favoriteMessages));
            localStorage.removeItem(testKey);
            
            // 如果测试通过，保存实际数据
            localStorage.setItem('favoriteMessages', JSON.stringify(favoriteMessages));
        } catch (error) {
            console.error('保存收藏消息失败，本地存储可能已满:', error);
            
            // 尝试删除更多旧的收藏来释放更大空间
            if (favoriteMessages.length > 0) {
                // 只保留最近的3条收藏，释放更多空间
                const trimmedFavorites = [...favoriteMessages].slice(Math.max(0, favoriteMessages.length - 3));
                try {
                    localStorage.setItem('favoriteMessages', JSON.stringify(trimmedFavorites));
                    setFavoriteMessages(trimmedFavorites);
                    toast.error('收藏消息过多，已自动清理部分旧的收藏');
                } catch (innerError) {
                    console.error('即使清理后仍无法保存收藏消息:', innerError);
                    // 放弃保存收藏，确保应用继续运行
                }
            }
        }
    }, [favoriteMessages]);
  
  // 保存Coze会话ID映射到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('cozeConversationIds', JSON.stringify(cozeConversationIds));
    } catch (error) {
      console.error('保存Coze会话ID映射失败:', error);
    }
  }, [cozeConversationIds]);

  // 当前对话的消息
  const [messages, setMessages] = useState<Message[]>([]);

  // 当切换对话时，加载对应的消息
  useEffect(() => {
    if (currentConversation) {
      try {
        const saved = localStorage.getItem(`messages_${currentConversation}`);
        setMessages(saved ? JSON.parse(saved) : []);
      } catch (error) {
        console.error('加载对话消息失败:', error);
        // 特别处理存储超出配额错误
        if (error instanceof DOMException && error.name === 'QuotaExceededError') {
          console.warn('localStorage空间已满，尝试清理部分旧数据...');
          try {
            // 尝试清理当前对话的部分旧消息
            const allKeys = Object.keys(localStorage);
            // 只保留最近的一条消息，清空其他消息
            localStorage.setItem(`messages_${currentConversation}`, JSON.stringify([]));
            setMessages([]);
            toast.warning('本地存储空间已满，已清理部分历史消息');
          } catch (innerError) {
            console.error('清理数据也失败:', innerError);
            setMessages([]);
          }
        } else {
          setMessages([]);
        }
      }
    } else {
      setMessages([]);
    }
  }, [currentConversation]);

  // 保存对话到localStorage
  useEffect(() => {
    try {
      localStorage.setItem('conversations', JSON.stringify(conversations));
    } catch (error) {
      console.error('保存对话列表失败，本地存储可能已满:', error);
      toast.warning('无法保存对话列表，可能会在刷新后丢失部分数据');
    }
  }, [conversations]);

  // 生成对话标题的辅助函数
  const generateConversationTitle = (content: string): string => {
    // 移除常见的开场白，获取更核心的主题
    const openingPrefixes = ['你好', '你好！', '我想', '请问', '如何', '怎样', '能不能', '可以帮我', '帮我', '我需要', '有没有', '有什么', '什么是', '解释一下', '介绍一下', '请', '']
    let trimmedContent = content.trim();
    
    // 去除开场白
    for (const prefix of openingPrefixes) {
      if (trimmedContent.startsWith(prefix)) {
        trimmedContent = trimmedContent.substring(prefix.length).trim();
        break;
      }
    }
    
    // 如果内容太短，直接使用
    if (trimmedContent.length <= 20) {
      return trimmedContent;
    }
    
    // 尝试提取第一个句子作为主题
    const firstSentenceEnd = Math.min(
      trimmedContent.indexOf('？') + 1 || 30,
      trimmedContent.indexOf('。') + 1 || 30,
      trimmedContent.indexOf('!') + 1 || 30,
      trimmedContent.indexOf('.') + 1 || 30,
      30
    );
    
    const title = trimmedContent.substring(0, firstSentenceEnd);
    return title.endsWith('？') || title.endsWith('。') || title.endsWith('!') || title.endsWith('.') 
      ? title 
      : title + '...';
  };

  // 添加消息
  const addMessage = (message: Omit<Message, 'id' | 'timestamp'>) => {
    if (!currentConversation) return;

    const newMessage: Message = {
      ...message,
      id: generateId(),
      timestamp: new Date()
    };

    // 使用函数式更新确保我们基于最新状态进行更新
    setMessages(prevMessages => {
      const updatedMessages = [...prevMessages, newMessage];
      
      // 保存消息到localStorage，添加错误处理
      try {
        localStorage.setItem(`messages_${currentConversation}`, JSON.stringify(updatedMessages));
      } catch (error) {
        console.error('保存消息失败，本地存储可能已满:', error);
        // 尝试清理消息历史以释放空间
        try {
          // 只保留最近的5条消息，比之前保留更少以确保空间足够
          const trimmedMessages = updatedMessages.slice(-5);
          localStorage.setItem(`messages_${currentConversation}`, JSON.stringify(trimmedMessages));
          toast.info('本地存储已满，已自动保留最近的5条消息');
        } catch (innerError) {
          console.error('即使清理后仍无法保存消息:', innerError);
          // 继续更新状态，让应用可以继续工作，只是不会持久化存储
          // 不再抛出错误，避免影响应用正常运行
          console.warn('无法保存消息到本地存储，但应用将继续运行');
        }
      }
      return updatedMessages;
    });
    
    // 如果是用户消息，更新对话标题和时间戳
    if (message.sender === 'user') {
      // 获取当前对话
      const conversation = conversations.find(c => c.id === currentConversation);
      // 如果是第一条消息，保存到firstMessage字段
      const isFirstMessage = messages.length === 0;
      
      const updatedConversations = conversations.map(conversation => 
        conversation.id === currentConversation
          ? { 
              ...conversation, 
              title: generateConversationTitle(message.content),
              timestamp: formatTimestamp(new Date()),
              firstMessage: isFirstMessage ? message.content : conversation.firstMessage
            }
          : conversation
      );
      setConversations(updatedConversations);
    }
    
    // 如果是AI消息，使用setTimeout确保在消息添加后再更新摘要
    if (message.sender === 'ai') {
      setTimeout(() => {
        // 获取最新的消息
        const saved = localStorage.getItem(`messages_${currentConversation}`);
        const currentMessages = saved ? JSON.parse(saved) : [];
        updateConversationSummary(currentConversation, currentMessages);
      }, 100);
    }
  };

  // 创建新对话
  const createConversation = () => {
     const newConversation: Conversation = {
      id: generateId(),
      title: '新对话',
      timestamp: formatTimestamp(new Date()),
      firstMessage: undefined // 初始时没有第一条消息
    };

    const updatedConversations = [newConversation, ...conversations];
    setConversations(updatedConversations);
    setCurrentConversation(newConversation.id);
    setMessages([]);
  };

  // 选择对话
  const selectConversation = (id: string) => {
    setCurrentConversation(id);
  };

  // 更新对话摘要
  const updateConversationSummary = (conversationId: string, messages: Message[]) => {
    // 生成摘要
    const summary = generateConversationSummary(messages);
    
    // 更新对话列表中的摘要
    const updatedConversations = conversations.map(conversation => 
      conversation.id === conversationId
        ? { ...conversation, summary }
        : conversation
    );
    
    setConversations(updatedConversations);
  };
  
  // 删除对话
  const deleteConversation = (id: string) => {
    const updatedConversations = conversations.filter(conversation => conversation.id !== id);
    setConversations(updatedConversations);
    
    // 如果删除的是当前对话，则切换到其他对话
    if (currentConversation === id) {
      if (updatedConversations.length > 0) {
        setCurrentConversation(updatedConversations[0].id);
      } else {
        setCurrentConversation(null);
      }
    }
    
    // 删除对话相关的localStorage数据
    localStorage.removeItem(`messages_${id}`);
    
     // 同时从收藏夹中移除该对话的消息
    setFavoriteMessages(prevFavorites => 
      prevFavorites.filter(msg => {
        // 查找是否有该对话的消息
        const isFromDeletedConversation = localStorage.getItem(`messages_${id}`)?.includes(msg.id);
        return !isFromDeletedConversation;
      })
    );
    
    // 同时删除对应的Coze会话ID映射
    setCozeConversationIds(prev => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });
  };

  // 切换消息收藏状态
  const toggleFavorite = (messageId: string) => {
    // 查找当前对话中是否有该消息
    const message = messages.find(msg => msg.id === messageId);
    
    if (message) {
      // 检查消息是否已经在收藏列表中
      const isAlreadyFavorite = favoriteMessages.some(fav => fav.id === messageId);
      
      if (isAlreadyFavorite) {
        // 从收藏列表中移除
        setFavoriteMessages(prevFavorites => 
          prevFavorites.filter(fav => fav.id !== messageId)
        );
      } else {
        // 添加到收藏列表
         // 存储完整的消息内容，确保用户可以查看完整信息
        const messageToStore = {
            ...message
            // 不再截断内容，以确保用户可以查看完整信息
            // content: message.content.length > 200 ? message.content.substring(0, 200) + '...' : message.content
        };
        setFavoriteMessages(prevFavorites => [...prevFavorites, messageToStore]);
      }
            
      // 更新当前对话中的消息状态
      setMessages(prevMessages => 
        prevMessages.map(msg => 
          msg.id === messageId 
            ? { ...msg, isFavorite: !isAlreadyFavorite }
            : msg
        )
      );
      
      // 同时更新localStorage中的消息状态
      if (currentConversation) {
        try {
          const savedMessages = localStorage.getItem(`messages_${currentConversation}`);
          if (savedMessages) {
            const parsedMessages = JSON.parse(savedMessages);
            const updatedMessages = parsedMessages.map((msg: Message) => 
              msg.id === messageId 
                ? { ...msg, isFavorite: !isAlreadyFavorite }
                : msg
            );
            localStorage.setItem(`messages_${currentConversation}`, JSON.stringify(updatedMessages));
          }
        } catch (error) {
          console.error('更新消息收藏状态失败:', error);
        }
      }
    }
  };

   // 获取对话历史用于API调用 - 支持多提供商格式
   const getConversationHistory = (conversationId: string): Array<{ role: string; content: string | Array<any> }> => {
     try {
       const saved = localStorage.getItem(`messages_${conversationId}`);
       if (!saved) return [];
       
       try {
         const messages: Message[] = JSON.parse(saved);
         // 确保按照API要求的格式构建对话历史
         // 1. 按时间顺序排列消息
         // 2. 正确设置每个消息的role（user或assistant）
         // 3. 保留完整的消息内容
         return messages.map(msg => {
           // 对于图片消息，需要特殊处理content格式
           if (msg.type === 'image' && msg.fileInfo?.url) {
             return {
               role: msg.sender === 'user' ? 'user' : 'assistant',
               content: [
                 { type: 'text', text: msg.content },
                 { type: 'image_url', image_url: { url: msg.fileInfo.url } }
               ]
             };
           }
           // 对于普通文件，在content中标记
           else if (msg.type === 'file' && msg.fileInfo) {
             return {
               role: msg.sender === 'user' ? 'user' : 'assistant',
               content: `${msg.content || ''}[${msg.fileInfo.name}文件已上传]`
             };
           }
           // 普通文本消息
           return {
             role: msg.sender === 'user' ? 'user' : 'assistant',
             content: msg.content
           };
         });
       } catch (error) {
         console.error('解析对话历史失败:', error);
         return [];
       }
     } catch (error) {
       console.error('获取对话历史失败:', error);
       return [];
     }
   }

  // 初始化时，如果没有对话，创建一个
  useEffect(() => {
    if (conversations.length === 0) {
      createConversation();
    } else if (!currentConversation) {
      setCurrentConversation(conversations[0].id);
    }
  }, [conversations, currentConversation]);

  // 当加载消息时，如果是AI消息且没有摘要，生成摘要
  useEffect(() => {
    if (currentConversation && messages.length > 0) {
      const aiMessages = messages.filter(msg => msg.sender === 'ai');
      if (aiMessages.length > 0) {
        const hasSummary = conversations.find(c => c.id === currentConversation)?.summary;
        if (!hasSummary) {
          updateConversationSummary(currentConversation, messages);
        }
      }
    }
   }, [messages, currentConversation]);
   
     // 获取或创建Coze会话ID - 简化版本避免潜在错误
     const getCozeConversationId = async (conversationId: string): Promise<string> => {
       try {
         // 检查是否已经有对应的Coze会话ID
         if (cozeConversationIds[conversationId]) {
           console.log('使用已有的Coze会话ID:', cozeConversationIds[conversationId]);
           return cozeConversationIds[conversationId];
         }
         
         // 生成一个模拟的会话ID（避免调用外部API导致的问题）
         const mockCozeId = 'mock_coze_' + conversationId;
         
         // 保存模拟的会话ID映射
         setCozeConversationIds(prev => ({
           ...prev,
           [conversationId]: mockCozeId
         }));
         
         return mockCozeId;
       } catch (error) {
         console.error('获取Coze会话ID失败:', error);
         return 'default_coze_' + conversationId;
       }
     };

  return (
     <ChatContext.Provider value={{
      conversations,
      currentConversation,
      currentModel,
      messages,
      favoriteMessages,
      addMessage,
      createConversation,
      selectConversation,
      getConversationHistory,
      setCurrentModel,
      updateConversationSummary,
      deleteConversation,
      toggleFavorite,
      currentProvider,
      setCurrentProvider,
      getCozeConversationId,
      stopGeneration: () => {
          console.log("暂停AI生成");
          // 在实际应用中，这里应该调用API停止生成
      }
     }}>
       {children}
     </ChatContext.Provider>
  );
};

// 创建自定义Hook
export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};