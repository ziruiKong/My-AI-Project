// IndexedDBService.ts - 使用IndexedDB实现的增强数据存储服务

// 定义存储数据类型
export interface UploadedImage {
  id: string;
  file: File;
  previewUrl: string;
  uploadDate: string;
  description?: string;
  tags?: string[];
  source?: string; // 上传来源页面
}

export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  category: string;
  createDate: string;
  updateDate?: string;
  tags?: string[];
}

// 数据库常量
const DB_NAME = 'CorexDatabase';
const DB_VERSION = 1;
const STORES = {
  IMAGES: 'images',
  KNOWLEDGE: 'knowledge',
  METADATA: 'metadata',
  GRE_QUESTIONS: 'gre_questions'
};

// GRE题库相关接口
export interface GREQuestionOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface GREQuestion {
  id: string;
  type: 'multiple_choice' | 'reading_comprehension';
  difficulty: 'easy' | 'medium' | 'hard';
  content: string;
  options?: GREQuestionOption[];
  correctAnswer?: string;
  explanation?: string;
  passage?: string;
  source?: string;
  tags?: string[];
  createDate: string;
  updateDate?: string;
}

/**
 * 基于IndexedDB的存储服务类
 */
class IndexedDBService {
  private db: IDBDatabase | null = null;
  private initPromise: Promise<void> | null = null;
  private isMigrationDone: boolean = false;

  // 初始化数据库
  async init(): Promise<void> {
    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // 创建图片存储对象
        if (!db.objectStoreNames.contains(STORES.IMAGES)) {
          const store = db.createObjectStore(STORES.IMAGES, { keyPath: 'id' });
          store.createIndex('uploadDate', 'uploadDate', { unique: false });
          store.createIndex('source', 'source', { unique: false });
        }
        
        // 创建知识存储对象
        if (!db.objectStoreNames.contains(STORES.KNOWLEDGE)) {
          const store = db.createObjectStore(STORES.KNOWLEDGE, { keyPath: 'id' });
          store.createIndex('createDate', 'createDate', { unique: false });
          store.createIndex('category', 'category', { unique: false });
        }
        
        // 创建元数据存储对象
        if (!db.objectStoreNames.contains(STORES.METADATA)) {
          const store = db.createObjectStore(STORES.METADATA, { keyPath: 'key' });
        }
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        
        // 检查是否需要从localStorage迁移数据
        this.migrateFromLocalStorage().then(() => {
          resolve();
        }).catch(err => {
          console.error('数据迁移失败:', err);
          resolve();
        });
      };

      request.onerror = (event) => {
        console.error('IndexedDB初始化失败:', (event.target as IDBOpenDBRequest).error);
        reject((event.target as IDBOpenDBRequest).error);
      };
    });

    return this.initPromise;
  }

  // 从localStorage迁移数据
  private async migrateFromLocalStorage(): Promise<void> {
    if (this.isMigrationDone) {
      return;
    }

    try {
      // 检查是否已经迁移过
      const hasMigrated = await this.getMetadata('hasMigrated');
      if (hasMigrated === 'true') {
        this.isMigrationDone = true;
        return;
      }

      console.log('开始从localStorage迁移数据到IndexedDB...');

      // 尝试从localStorage获取数据
      const localStorageTables = {
        'corex_images': STORES.IMAGES,
        'corex_knowledge': STORES.KNOWLEDGE,
        'corex_metadata': STORES.METADATA
      };

      for (const [localKey, storeName] of Object.entries(localStorageTables)) {
        try {
          const localStorageData = localStorage.getItem(localKey);
          if (localStorageData) {
            const items = JSON.parse(localStorageData);
            
            if (Array.isArray(items) && items.length > 0) {
              // 特殊处理元数据
              if (storeName === STORES.METADATA) {
                for (const item of items) {
                  await this.put(storeName, item);
                }
              } else {
                // 批量插入数据
                await this.bulkPut(storeName, items);
              }
              console.log(`成功迁移 ${items.length} 条数据到 ${storeName}`);
            }
          }
        } catch (error) {
          console.error(`迁移 ${localKey} 数据失败:`, error);
        }
      }

      // 标记迁移完成
      await this.setMetadata('hasMigrated', 'true');
      this.isMigrationDone = true;
      
      // 可选：清理localStorage数据
      // this.clearLocalStorageData();
      
      console.log('数据迁移完成');
    } catch (error) {
      console.error('数据迁移过程中发生错误:', error);
    }
  }

  // 清理localStorage数据（可选）
  private clearLocalStorageData(): void {
    try {
      const localStorageKeys = ['corex_images', 'corex_knowledge', 'corex_metadata'];
      localStorageKeys.forEach(key => {
        localStorage.removeItem(key);
      });
      console.log('localStorage数据已清理');
    } catch (error) {
      console.error('清理localStorage数据失败:', error);
    }
  }

  // 获取数据库连接
  private async getDb(): Promise<IDBDatabase> {
    if (!this.db) {
      await this.init();
    }
    
    if (!this.db) {
      throw new Error('无法获取数据库连接');
    }
    
    return this.db;
  }

  // 执行事务操作
  private async transaction<T>(storeName: string, mode: 'readonly' | 'readwrite' | 'versionchange', callback: (store: IDBObjectStore) => Promise<T>): Promise<T> {
    const db = await this.getDb();
    
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], mode);
      const store = transaction.objectStore(storeName);
      
      transaction.oncomplete = () => {
        console.log(`Transaction completed for store: ${storeName}`);
      };
      
      transaction.onerror = () => {
        console.error(`Transaction error for store ${storeName}:`, transaction.error);
        reject(transaction.error);
      };
      
      transaction.onabort = () => {
        console.error(`Transaction aborted for store ${storeName}:`, transaction.error);
        reject(transaction.error);
      };
      
      // 执行回调并解析结果
      Promise.resolve().then(() => callback(store)).then(resolve).catch(reject);
    });
  }

  // 添加单个项目
  async add<T>(storeName: string, item: T): Promise<T> {
    return this.transaction(storeName, 'readwrite', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.add(item);
        
        request.onsuccess = () => {
          resolve(item);
        };
        
        request.onerror = () => {
          console.error(`添加项目到 ${storeName} 失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 更新或添加项目
  async put<T>(storeName: string, item: T): Promise<T> {
    return this.transaction(storeName, 'readwrite', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.put(item);
        
        request.onsuccess = () => {
          resolve(item);
        };
        
        request.onerror = () => {
          console.error(`更新项目到 ${storeName} 失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 批量添加项目
  async bulkPut<T>(storeName: string, items: T[]): Promise<boolean> {
    return this.transaction(storeName, 'readwrite', async (store) => {
      return new Promise((resolve, reject) => {
        try {
          items.forEach(item => {
            store.put(item);
          });
          resolve(true);
        } catch (error) {
          console.error(`批量添加项目到 ${storeName} 失败:`, error);
          reject(error);
        }
      });
    });
  }

  // 获取所有项目
  async getAll<T>(storeName: string, filter?: (item: T) => boolean): Promise<T[]> {
    return this.transaction(storeName, 'readonly', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.getAll();
        
        request.onsuccess = () => {
          let result: T[] = request.result;
          
          // 应用过滤器
          if (filter) {
            result = result.filter(filter);
          }
          
          resolve(result);
        };
        
        request.onerror = () => {
          console.error(`获取 ${storeName} 所有项目失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 根据ID获取项目
  async getById<T>(storeName: string, id: string | number): Promise<T | null> {
    return this.transaction(storeName, 'readonly', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.get(id);
        
        request.onsuccess = () => {
          resolve(request.result);
        };
        
        request.onerror = () => {
          console.error(`获取 ${storeName} 项目失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 根据索引获取项目
  async getByIndex<T>(storeName: string, indexName: string, value: any): Promise<T[]> {
    return this.transaction(storeName, 'readonly', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.index(indexName).getAll(value);
        
        request.onsuccess = () => {
          resolve(request.result);
        };
        
        request.onerror = () => {
          console.error(`根据索引 ${indexName} 获取 ${storeName} 项目失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 删除项目
  async delete(storeName: string, id: string | number): Promise<boolean> {
    return this.transaction(storeName, 'readwrite', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.delete(id);
        
        request.onsuccess = () => {
          resolve(true);
        };
        
        request.onerror = () => {
          console.error(`删除 ${storeName} 项目失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 清空存储
  async clear(storeName: string): Promise<boolean> {
    return this.transaction(storeName, 'readwrite', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.clear();
        
        request.onsuccess = () => {
          resolve(true);
        };
        
        request.onerror = () => {
          console.error(`清空 ${storeName} 失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 获取项目数量
  async count(storeName: string): Promise<number> {
    return this.transaction(storeName, 'readonly', async (store) => {
      return new Promise((resolve, reject) => {
        const request = store.count();
        
        request.onsuccess = () => {
          resolve(request.result);
        };
        
        request.onerror = () => {
          console.error(`获取 ${storeName} 项目数量失败:`, request.error);
          reject(request.error);
        };
      });
    });
  }

  // 设置元数据
  async setMetadata(key: string, value: string): Promise<boolean> {
    try {
      await this.put(STORES.METADATA, {
        key,
        value,
        updatedAt: new Date().toISOString()
      });
      return true;
    } catch (error) {
      console.error(`设置元数据 ${key} 失败:`, error);
      return false;
    }
  }

  // 获取元数据
  async getMetadata(key: string): Promise<string | null> {
    try {
      const item = await this.getById<any>(STORES.METADATA, key);
      return item ? item.value : null;
    } catch (error) {
      console.error(`获取元数据 ${key} 失败:`, error);
      return null;
    }
  }

  // 图片相关方法
  async addImage(image: Omit<UploadedImage, 'id' | 'uploadDate'>): Promise<UploadedImage> {
    try {
      const newImage: UploadedImage = {
        ...image,
        id: this.generateId(),
        uploadDate: new Date().toISOString()
      };
      
      await this.add(STORES.IMAGES, newImage);
      return newImage;
    } catch (error) {
      console.error('添加图片失败:', error);
      throw error;
    }
  }

  async getImages(filter?: (image: UploadedImage) => boolean): Promise<UploadedImage[]> {
    try {
      return await this.getAll<UploadedImage>(STORES.IMAGES, filter);
    } catch (error) {
      console.error('获取图片失败:', error);
      return [];
    }
  }

  async getImageById(id: string): Promise<UploadedImage | null> {
    try {
      return await this.getById<UploadedImage>(STORES.IMAGES, id);
    } catch (error) {
      console.error(`获取ID为 ${id} 的图片失败:`, error);
      return null;
    }
  }

  async updateImage(id: string, updates: Partial<UploadedImage>): Promise<boolean> {
    try {
      const image = await this.getImageById(id);
      if (!image) {
        return false;
      }
      
      const updatedImage = { ...image, ...updates };
      await this.put(STORES.IMAGES, updatedImage);
      return true;
    } catch (error) {
      console.error(`更新ID为 ${id} 的图片失败:`, error);
      return false;
    }
  }

  async deleteImage(id: string): Promise<boolean> {
    try {
      return await this.delete(STORES.IMAGES, id);
    } catch (error) {
      console.error(`删除ID为 ${id} 的图片失败:`, error);
      return false;
    }
  }

  // 知识相关方法
  async addKnowledgeItem(item: Omit<KnowledgeItem, 'id' | 'createDate'>): Promise<KnowledgeItem> {
    try {
      const newItem: KnowledgeItem = {
        ...item,
        id: this.generateId(),
        createDate: new Date().toISOString()
      };
      
      await this.add(STORES.KNOWLEDGE, newItem);
      return newItem;
    } catch (error) {
      console.error('添加知识项失败:', error);
      throw error;
    }
  }

  async getKnowledgeItems(filter?: (item: KnowledgeItem) => boolean): Promise<KnowledgeItem[]> {
    try {
      return await this.getAll<KnowledgeItem>(STORES.KNOWLEDGE, filter);
    } catch (error) {
      console.error('获取知识项失败:', error);
      return [];
    }
  }

  async getKnowledgeItemById(id: string): Promise<KnowledgeItem | null> {
    try {
      return await this.getById<KnowledgeItem>(STORES.KNOWLEDGE, id);
    } catch (error) {
      console.error(`获取ID为 ${id} 的知识项失败:`, error);
      return null;
    }
  }

  async updateKnowledgeItem(id: string, updates: Partial<KnowledgeItem>): Promise<boolean> {
    try {
      const item = await this.getKnowledgeItemById(id);
      if (!item) {
        return false;
      }
      
      const updatedItem = { 
        ...item, 
        ...updates,
        updateDate: new Date().toISOString()
      };
      await this.put(STORES.KNOWLEDGE, updatedItem);
      return true;
    } catch (error) {
      console.error(`更新ID为 ${id} 的知识项失败:`, error);
      return false;
    }
  }

  async deleteKnowledgeItem(id: string): Promise<boolean> {
    try {
      return await this.delete(STORES.KNOWLEDGE, id);
    } catch (error) {
      console.error(`删除ID为 ${id} 的知识项失败:`, error);
      return false;
    }
  }

  // 导出数据库内容（用于备份）
  async exportDatabase(): Promise<string> {
    try {
      const db = {
        version: this.getMetadata('version') || '1.0.0',
        exportDate: new Date().toISOString(),
        [STORES.IMAGES]: await this.getImages(),
        [STORES.KNOWLEDGE]: await this.getKnowledgeItems(),
        [STORES.METADATA]: await this.getAll<any>(STORES.METADATA)
      };
      
      return JSON.stringify(db);
    } catch (error) {
      console.error('导出数据库失败:', error);
      return JSON.stringify({ error: '导出失败' });
    }
  }

  // 导入数据库内容（用于恢复）
  async importDatabase(jsonData: string): Promise<boolean> {
    try {
      const db = JSON.parse(jsonData);
      
      // 先清空现有数据
      await this.clear(STORES.IMAGES);
      await this.clear(STORES.KNOWLEDGE);
      await this.clear(STORES.METADATA);
      await this.clear(STORES.GRE_QUESTIONS);
      
      // 导入新数据
      if (db[STORES.IMAGES] && Array.isArray(db[STORES.IMAGES])) {
        await this.bulkPut(STORES.IMAGES, db[STORES.IMAGES]);
      }
      
      if (db[STORES.KNOWLEDGE] && Array.isArray(db[STORES.KNOWLEDGE])) {
        await this.bulkPut(STORES.KNOWLEDGE, db[STORES.KNOWLEDGE]);
      }
      
      if (db[STORES.METADATA] && Array.isArray(db[STORES.METADATA])) {
        for (const item of db[STORES.METADATA]) {
          await this.put(STORES.METADATA, item);
        }
      }

      // 导入GRE题库数据
      if (db[STORES.GRE_QUESTIONS] && Array.isArray(db[STORES.GRE_QUESTIONS])) {
        await this.bulkPut(STORES.GRE_QUESTIONS, db[STORES.GRE_QUESTIONS]);
      }
      
      return true;
    } catch (error) {
      console.error('导入数据库失败:', error);
      return false;
    }
  }

  // GRE题库相关方法
  async addGREQuestion(question: Omit<GREQuestion, 'id' | 'createDate'>): Promise<GREQuestion> {
    try {
      const newQuestion: GREQuestion = {
        ...question,
        id: this.generateId(),
        createDate: new Date().toISOString()
      };
      
      await this.add(STORES.GRE_QUESTIONS, newQuestion);
      return newQuestion;
    } catch (error) {
      console.error('添加GRE题目失败:', error);
      throw error;
    }
  }

  async getGREQuestions(filter?: (question: GREQuestion) => boolean): Promise<GREQuestion[]> {
    try {
      return await this.getAll<GREQuestion>(STORES.GRE_QUESTIONS, filter);
    } catch (error) {
      console.error('获取GRE题目失败:', error);
      return [];
    }
  }

  async getGREQuestionById(id: string): Promise<GREQuestion | null> {
    try {
      return await this.getById<GREQuestion>(STORES.GRE_QUESTIONS, id);
    } catch (error) {
      console.error(`获取ID为 ${id} 的GRE题目失败:`, error);
      return null;
    }
  }

  async updateGREQuestion(id: string, updates: Partial<GREQuestion>): Promise<boolean> {
    try {
      const question = await this.getGREQuestionById(id);
      if (!question) {
        return false;
      }
      
      const updatedQuestion = { 
        ...question, 
        ...updates,
        updateDate: new Date().toISOString()
      };
      await this.put(STORES.GRE_QUESTIONS, updatedQuestion);
      return true;
    } catch (error) {
      console.error(`更新ID为 ${id} 的GRE题目失败:`, error);
      return false;
    }
  }

  async deleteGREQuestion(id: string): Promise<boolean> {
    try {
      return await this.delete(STORES.GRE_QUESTIONS, id);
    } catch (error) {
      console.error(`删除ID为 ${id} 的GRE题目失败:`, error);
      return false;
    }
  }

  // 生成唯一ID
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
}

export default IndexedDBService;