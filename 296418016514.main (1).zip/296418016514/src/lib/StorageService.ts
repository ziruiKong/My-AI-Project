// StorageService.ts - 增强的数据存储服务，用于管理上传的图片和知识数据

// 定义存储数据类型
export interface UploadedImage {
  id: string;
  file: File;
  previewUrl: string;
  uploadDate: string;
  description?: string;
  tags?: string[];
  source?: string; // 上传来源页面
}

export interface KnowledgeItem {
  id: string;
  title: string;
  content: string;
  category: string;
  createDate: string;
  updateDate?: string;
  tags?: string[];
}

// GRE题库相关接口
export interface GREQuestionOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface GREQuestion {
  id: string;
  type: 'multiple_choice' | 'reading_comprehension';
  difficulty: 'easy' | 'medium' | 'hard';
  content: string;
  options?: GREQuestionOption[];
  correctAnswer?: string;
  explanation?: string;
  passage?: string;
  source?: string;
  tags?: string[];
  createDate: string;
  updateDate?: string;
}

// 数据库表名常量
const DB_TABLES = {
  IMAGES: 'corex_images',
  KNOWLEDGE: 'corex_knowledge',
  METADATA: 'corex_metadata',
  GRE_QUESTIONS: 'corex_gre_questions' // 新增GRE题库表
};

// 导入IndexedDB服务
import IndexedDBService, { UploadedImage as IndexedDBUploadedImage, KnowledgeItem as IndexedDBKnowledgeItem, GREQuestion as IndexedDBGREQuestion, GREQuestionOption as IndexedDBGREQuestionOption } from './IndexedDBService';

// 创建IndexedDB服务的单例实例
const indexedDBService = new IndexedDBService();

/**
 * 增强的存储服务类 - 优先使用IndexedDB，降级到localStorage
 */
class StorageService {
  private useIndexedDB: boolean = true;
  
  // 初始化数据库
  async init(): Promise<void> {
    try {
      // 检查是否强制使用IndexedDB
      const forceIndexedDB = localStorage.getItem('forceIndexedDB');
      
      // 尝试初始化IndexedDB
      await indexedDBService.init();
      console.log('IndexedDB初始化成功，使用IndexedDB存储');
      
      // 设置存储类型为IndexedDB
      await this.setMetadata('storageType', 'IndexedDB');
      
      // 如果之前强制切换过来，清除标记
      if (forceIndexedDB) {
        localStorage.removeItem('forceIndexedDB');
      }
    } catch (error) {
      console.warn('IndexedDB初始化失败，降级使用localStorage:', error);
      this.useIndexedDB = false;
      
                       // 确保所有localStorage表都已创建
          this.ensureTableExists(DB_TABLES.IMAGES);
          this.ensureTableExists(DB_TABLES.KNOWLEDGE);
          this.ensureTableExists(DB_TABLES.METADATA);
          this.ensureTableExists(DB_TABLES.GRE_QUESTIONS); // 添加GRE题库表
          
          // 设置数据库版本
          await this.setMetadata('version', '1.0.0');
          await this.setMetadata('lastInitialized', new Date().toISOString());
          await this.setMetadata('storageType', 'localStorage');
          await this.setMetadata('dbVersion', '2'); // 更新数据库版本
    }
  }
  
  // 确保表存在 (localStorage后备)
  private ensureTableExists(tableName: string): void {
    if (!localStorage.getItem(tableName)) {
      localStorage.setItem(tableName, JSON.stringify([]));
    }
  }
  
  // 获取表数据 (localStorage后备)
  private getTableData<T>(tableName: string): T[] {
    try {
      const data = localStorage.getItem(tableName);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error(`Error loading data from ${tableName}:`, error);
      return [];
    }
  }
  
  // 保存表数据 (localStorage后备)
  private saveTableData<T>(tableName: string, data: T[]): void {
    try {
      localStorage.setItem(tableName, JSON.stringify(data));
    } catch (error) {
      console.error(`Error saving data to ${tableName}:`, error);
      // 处理存储满的情况
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        this.handleStorageQuotaExceeded(tableName);
      }
    }
  }
  
  // 处理存储配额超限 (localStorage后备)
  private handleStorageQuotaExceeded(tableName: string): void {
    console.warn(`Storage quota exceeded for table ${tableName}. Attempting to clear old data.`);
    
    // 获取现有数据
    const data = this.getTableData<any>(tableName);
    
    if (data.length > 0) {
      // 删除最旧的10%的数据
      const itemsToRemove = Math.max(1, Math.floor(data.length * 0.1));
      data.splice(0, itemsToRemove);
      
      // 尝试重新保存
      try {
        localStorage.setItem(tableName, JSON.stringify(data));
      } catch (innerError) {
        console.error('Failed to save data even after cleaning up old items:', innerError);
      }
    }
  }
  
  // 设置元数据
  async setMetadata(key: string, value: string): Promise<void> {
    if (this.useIndexedDB) {
      try {
        await indexedDBService.setMetadata(key, value);
        return;
      } catch (error) {
        console.warn('IndexedDB设置元数据失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const metadata = this.getTableData<any>(DB_TABLES.METADATA);
      const existingIndex = metadata.findIndex((item: any) => item.key === key);
      
      if (existingIndex >= 0) {
        metadata[existingIndex].value = value;
        metadata[existingIndex].updatedAt = new Date().toISOString();
      } else {
        metadata.push({
          key,
          value,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      }
      
      this.saveTableData(DB_TABLES.METADATA, metadata);
    } catch (error) {
      console.error(`Error setting metadata ${key}:`, error);
    }
  }
  
  // 获取元数据
  async getMetadata(key: string): Promise<string | null> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getMetadata(key);
      } catch (error) {
        console.warn('IndexedDB获取元数据失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const metadata = this.getTableData<any>(DB_TABLES.METADATA);
      const item = metadata.find((item: any) => item.key === key);
      return item ? item.value : null;
    } catch (error) {
      console.error(`Error getting metadata ${key}:`, error);
      return null;
    }
  }
  
  // 图片相关方法
  async addImage(image: Omit<UploadedImage, 'id' | 'uploadDate'>): Promise<UploadedImage> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.addImage(image);
      } catch (error) {
        console.warn('IndexedDB添加图片失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const newImage: UploadedImage = {
        ...image,
        id: this.generateId(),
        uploadDate: new Date().toISOString()
      };
      
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      images.push(newImage);
      this.saveTableData(DB_TABLES.IMAGES, images);
      
      return newImage;
    } catch (error) {
      console.error('Error adding image:', error);
      throw error;
    }
  }
  
  async getImages(filter?: (image: UploadedImage) => boolean): Promise<UploadedImage[]> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getImages(filter);
      } catch (error) {
        console.warn('IndexedDB获取图片失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      return filter ? images.filter(filter) : images;
    } catch (error) {
      console.error('Error getting images:', error);
      return [];
    }
  }
  
  async getImageById(id: string): Promise<UploadedImage | null> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getImageById(id);
      } catch (error) {
        console.warn('IndexedDB获取图片失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      return images.find(img => img.id === id) || null;
    } catch (error) {
      console.error(`Error getting image with id ${id}:`, error);
      return null;
    }
  }
  
  async updateImage(id: string, updates: Partial<UploadedImage>): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.updateImage(id, updates);
      } catch (error) {
        console.warn('IndexedDB更新图片失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      const index = images.findIndex(img => img.id === id);
      
      if (index >= 0) {
        images[index] = {
          ...images[index],
          ...updates
        };
        this.saveTableData(DB_TABLES.IMAGES, images);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error updating image with id ${id}:`, error);
      return false;
    }
  }
  
  async deleteImage(id: string): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.deleteImage(id);
      } catch (error) {
        console.warn('IndexedDB删除图片失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      const filteredImages = images.filter(img => img.id !== id);
      
      if (filteredImages.length !== images.length) {
        this.saveTableData(DB_TABLES.IMAGES, filteredImages);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error deleting image with id ${id}:`, error);
      return false;
    }
  }
  
  // 知识相关方法
  async addKnowledgeItem(item: Omit<KnowledgeItem, 'id' | 'createDate'>): Promise<KnowledgeItem> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.addKnowledgeItem(item);
      } catch (error) {
        console.warn('IndexedDB添加知识项失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const newItem: KnowledgeItem = {
        ...item,
        id: this.generateId(),
        createDate: new Date().toISOString()
      };
      
      const knowledge = this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE);
      knowledge.push(newItem);
      this.saveTableData(DB_TABLES.KNOWLEDGE, knowledge);
      
      return newItem;
    } catch (error) {
      console.error('Error adding knowledge item:', error);
      throw error;
    }
  }
  
  async getKnowledgeItems(filter?: (item: KnowledgeItem) => boolean): Promise<KnowledgeItem[]> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getKnowledgeItems(filter);
      } catch (error) {
        console.warn('IndexedDB获取知识项失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const knowledge = this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE);
      return filter ? knowledge.filter(filter) : knowledge;
    } catch (error) {
      console.error('Error getting knowledge items:', error);
      return [];
    }
  }
  
  async getKnowledgeItemById(id: string): Promise<KnowledgeItem | null> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getKnowledgeItemById(id);
      } catch (error) {
        console.warn('IndexedDB获取知识项失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const knowledge = this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE);
      return knowledge.find(item => item.id === id) || null;
    } catch (error) {
      console.error(`Error getting knowledge item with id ${id}:`, error);
      return null;
    }
  }
  
  async updateKnowledgeItem(id: string, updates: Partial<KnowledgeItem>): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.updateKnowledgeItem(id, updates);
      } catch (error) {
        console.warn('IndexedDB更新知识项失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const knowledge = this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE);
      const index = knowledge.findIndex(item => item.id === id);
      
      if (index >= 0) {
        knowledge[index] = {
          ...knowledge[index],
          ...updates,
          updateDate: new Date().toISOString()
        };
        this.saveTableData(DB_TABLES.KNOWLEDGE, knowledge);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error updating knowledge item with id ${id}:`, error);
      return false;
    }
  }
  
  async deleteKnowledgeItem(id: string): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.deleteKnowledgeItem(id);
      } catch (error) {
        console.warn('IndexedDB删除知识项失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const knowledge = this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE);
      const filteredKnowledge = knowledge.filter(item => item.id !== id);
      
      if (filteredKnowledge.length !== knowledge.length) {
        this.saveTableData(DB_TABLES.KNOWLEDGE, filteredKnowledge);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error deleting knowledge item with id ${id}:`, error);
      return false;
    }
  }
  
  // 生成唯一ID
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
  
  // 导出数据库内容（用于备份）
  async exportDatabase(): Promise<string> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.exportDatabase();
      } catch (error) {
        console.warn('IndexedDB导出数据库失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const db = {
        version: await this.getMetadata('version') || '1.0.0',
        exportDate: new Date().toISOString(),
        [DB_TABLES.IMAGES]: this.getTableData<UploadedImage>(DB_TABLES.IMAGES),
        [DB_TABLES.KNOWLEDGE]: this.getTableData<KnowledgeItem>(DB_TABLES.KNOWLEDGE),
        [DB_TABLES.METADATA]: this.getTableData<any>(DB_TABLES.METADATA),
        [DB_TABLES.GRE_QUESTIONS]: this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS)
      };
      
      return JSON.stringify(db);
    } catch (error) {
      console.error('Error exporting database:', error);
      return JSON.stringify({ error: 'Export failed' });
    }
  }
  
  // 导入数据库内容（用于恢复）
  async importDatabase(jsonData: string): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.importDatabase(jsonData);
      } catch (error) {
        console.warn('IndexedDB导入数据库失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const db = JSON.parse(jsonData);
      
      if (db[DB_TABLES.IMAGES]) {
        this.saveTableData(DB_TABLES.IMAGES, db[DB_TABLES.IMAGES]);
      }
      
      if (db[DB_TABLES.KNOWLEDGE]) {
        this.saveTableData(DB_TABLES.KNOWLEDGE, db[DB_TABLES.KNOWLEDGE]);
      }
      
      if (db[DB_TABLES.METADATA]) {
        this.saveTableData(DB_TABLES.METADATA, db[DB_TABLES.METADATA]);
      }

      // 导入GRE题库数据
      if (db[DB_TABLES.GRE_QUESTIONS]) {
        this.saveTableData(DB_TABLES.GRE_QUESTIONS, db[DB_TABLES.GRE_QUESTIONS]);
      }
      
      return true;
    } catch (error) {
      console.error('Error importing database:', error);
      return false;
    }
  }

  // GRE题库相关方法
  async addGREQuestion(question: Omit<GREQuestion, 'id' | 'createDate'>): Promise<GREQuestion> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.addGREQuestion(question);
      } catch (error) {
        console.warn('IndexedDB添加GRE题目失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const newQuestion: GREQuestion = {
        ...question,
        id: this.generateId(),
        createDate: new Date().toISOString()
      };
      
      const questions = this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS);
      questions.push(newQuestion);
      this.saveTableData(DB_TABLES.GRE_QUESTIONS, questions);
      
      return newQuestion;
    } catch (error) {
      console.error('添加GRE题目失败:', error);
      throw error;
    }
  }

  async getGREQuestions(filter?: (question: GREQuestion) => boolean): Promise<GREQuestion[]> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getGREQuestions(filter);
      } catch (error) {
        console.warn('IndexedDB获取GRE题目失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const questions = this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS);
      return filter ? questions.filter(filter) : questions;
    } catch (error) {
      console.error('获取GRE题目失败:', error);
      return [];
    }
  }

  async getGREQuestionById(id: string): Promise<GREQuestion | null> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.getGREQuestionById(id);
      } catch (error) {
        console.warn('IndexedDB获取GRE题目失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const questions = this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS);
      return questions.find(q => q.id === id) || null;
    } catch (error) {
      console.error(`获取ID为 ${id} 的GRE题目失败:`, error);
      return null;
    }
  }

  async updateGREQuestion(id: string, updates: Partial<GREQuestion>): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.updateGREQuestion(id, updates);
      } catch (error) {
        console.warn('IndexedDB更新GRE题目失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const questions = this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS);
      const index = questions.findIndex(q => q.id === id);
      
      if (index >= 0) {
        questions[index] = {
          ...questions[index],
          ...updates,
          updateDate: new Date().toISOString()
        };
        this.saveTableData(DB_TABLES.GRE_QUESTIONS, questions);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`更新ID为 ${id} 的GRE题目失败:`, error);
      return false;
    }
  }

  async deleteGREQuestion(id: string): Promise<boolean> {
    if (this.useIndexedDB) {
      try {
        return await indexedDBService.deleteGREQuestion(id);
      } catch (error) {
        console.warn('IndexedDB删除GRE题目失败，降级使用localStorage:', error);
      }
    }
    
    // 降级到localStorage
    try {
      const questions = this.getTableData<GREQuestion>(DB_TABLES.GRE_QUESTIONS);
      const filteredQuestions = questions.filter(q => q.id !== id);
      
      if (filteredQuestions.length !== questions.length) {
        this.saveTableData(DB_TABLES.GRE_QUESTIONS, filteredQuestions);
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`删除ID为 ${id} 的GRE题目失败:`, error);
      return false;
    }
  }
}

// 导出单例实例
export const storageService = new StorageService();

// 初始化数据库
storageService.init().catch(error => {
  console.error('StorageService初始化失败:', error);
});