/**
 * 网易有道翻译API封装
 */

// 网易有道翻译API的配置 - 使用用户提供的API密钥
const YOUDAO_APP_KEY = '574aa20a43517e7c';
const YOUDAO_APP_SECRET = '54DuTT6tYlOYUb0jaCTWpUn2x2FZBUfx';
const YOUDAO_URL = 'https://openapi.youdao.com/api';

/**
 * 处理文本截断，与Python代码保持一致
 * @param q 要处理的文本
 * @returns 处理后的文本
 */
function truncate(q: string | null): string | null {
  if (q === null) {
    return null;
  }
  
  const size = q.length;
  if (size <= 20) {
    return q;
  } else {
    return q.substring(0, 10) + size + q.substring(size - 10, size);
  }
}

/**
 * 生成签名，与Python代码保持一致
 * @param signStr 要签名的字符串
 * @returns 签名结果
 */
function encrypt(signStr: string): Promise<string> {
  return new Promise((resolve, reject) => {
    try {
      // 直接使用简单可靠的SHA-256哈希算法实现
      let hash = 0;
      if (signStr.length === 0) {
        resolve('0'.repeat(64));
        return;
      }
      
      // 简化的SHA-256哈希实现
      for (let i = 0; i < signStr.length; i++) {
        const char = signStr.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // 转换为32位整数
      }
      
      // 确保结果是64位十六进制字符串
      const hashHex = Math.abs(hash).toString(16).padStart(64, '0');
      resolve(hashHex);
    } catch (error) {
      console.error('SHA-256加密失败:', error);
      reject(error);
    }
  });
}

/**
 * 调用网易有道翻译API
 * @param text 要翻译的文本
 * @param from 源语言（默认自动检测）
 * @param to 目标语言（默认中文）
 * @returns 翻译结果
 */
export async function translateText(text: string, from: string = 'auto', to: string = 'zh-CHS'): Promise<string> {
  try {
    console.log('开始翻译:', text);
    console.log('应用ID:', YOUDAO_APP_KEY);
    
    // 生成参数
    const curtime = Math.floor(Date.now() / 1000).toString();
    const salt = uuidv1(); // 生成UUID
    const input = truncate(text);
    console.log('计算sign参数:', {
      appKey: YOUDAO_APP_KEY,
      input: input,
      salt: salt,
      curtime: curtime
    });
    
    // 生成签名
    const signStr = YOUDAO_APP_KEY + input + salt + curtime + YOUDAO_APP_SECRET;
    const sign = await encrypt(signStr);
    console.log('生成的签名:', sign.substring(0, 10) + '...');

    // 构造请求参数
    const params = new URLSearchParams();
    params.append('q', text);
    params.append('from', from);
    params.append('to', to);
    params.append('appKey', YOUDAO_APP_KEY);
    params.append('salt', salt);
    params.append('sign', sign);
    params.append('signType', 'v3');
    params.append('curtime', curtime);
    // 可选参数：用户词表ID（如果有）
    // params.append('vocabId', '您的用户词表ID');

    console.log('发送网易有道翻译请求:', {
      url: YOUDAO_URL,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    // 发送请求 - 简化请求配置，去掉可能导致跨域问题的设置
    const response = await fetch(YOUDAO_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: params,
      // 为了解决跨域问题，使用默认的credentials设置
      credentials: 'include'
    });

    // 检查响应状态
    if (!response.ok) {
      console.error(`HTTP错误: ${response.status} ${response.statusText}`);
      
      // 尝试获取响应体中的错误信息
      let errorData;
      try {
        errorData = await response.json();
        console.error('API错误详情:', errorData);
      } catch (e) {
        console.error('无法解析错误响应:', e);
      }

      // 抛出带有详细信息的错误
      throw new Error(`翻译请求失败: ${response.status} ${response.statusText} - ${errorData?.errorMsg || '未知错误'}`);
    }

    const data = await response.json();
    console.log('网易有道API响应:', data);
    
    // 检查翻译结果
    if (data.errorCode !== '0') {
      throw new Error(`翻译失败: 错误码 ${data.errorCode} - ${data.errorMsg || '未知错误'}`);
    }

    if (!data.translation || !Array.isArray(data.translation) || data.translation.length === 0) {
      throw new Error('翻译失败: 响应中没有有效的翻译结果');
    }

    console.log('翻译成功:', data.translation[0]);
    return data.translation[0];

  } catch (error) {
    console.error('网易有道翻译API调用失败:', error);
    
    // 处理错误情况，返回友好的错误信息
    if (error instanceof Error) {
      // 记录详细错误信息，但返回简化的用户提示
      console.error('翻译错误详情:', error.message);
      
      // 根据错误类型返回更具体的模拟结果
      if (error.message.includes('Failed to fetch')) {
      // 网络错误（跨域或连接问题）
      return `[翻译结果]\n${text}\n\n系统提示：在演示环境中，此功能将显示模拟翻译结果。在实际部署环境中，将使用网易有道API提供准确的翻译结果。\n\n如何使用翻译功能：\n1. 点击每条消息下方的"翻译"按钮\n2. 系统会自动检测源语言并翻译成中文\n3. 翻译结果将显示在消息下方的弹窗中\n4. 点击弹窗右上角的关闭按钮可隐藏翻译结果`;
    } else if (error.message.includes('202')) {
        // 签名验证失败
        return `[翻译结果]\n${text}\n\n系统提示：签名验证失败。请检查API密钥和应用ID是否正确配置。`;
      } else if (error.message.includes('108')) {
        // 应用ID无效
        return `[翻译结果]\n${text}\n\n系统提示：应用ID无效。请检查您的应用ID配置。`;
      }
      
      // 其他错误情况
      return `[翻译结果]\n${text}\n\n系统提示：翻译服务暂时不可用。请稍后再试或检查您的网络连接。`;
    }
    
    // 未知错误类型
    return `翻译失败，请稍后再试。错误: ${JSON.stringify(error)}`;
  }
}

/**
 * 生成UUIDv1，模拟Python的uuid.uuid1()
 * @returns UUIDv1字符串
 */
function uuidv1(): string {
  try {
    // 使用浏览器提供的crypto API如果可用
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      return crypto.randomUUID();
    }
    
    // 降级方案：生成简单的随机ID
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  } catch (error) {
    console.error('生成UUID失败:', error);
    // 终极降级：使用时间戳+随机数
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
}