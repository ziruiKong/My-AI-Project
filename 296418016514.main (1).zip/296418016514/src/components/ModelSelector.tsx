import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useChat } from "../contexts/chatContext";
import { useTheme } from "../hooks/useTheme";
import { toast } from "sonner";

const ModelSelector: React.FC = () => {
    const {
        currentModel,
        setCurrentModel
    } = useChat();

    const {
        isDark
    } = useTheme();

     const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // 添加点击外部关闭下拉菜单的功能
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    
    // 只有当下拉菜单打开时才添加事件监听器
    if (isDropdownOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => {
        document.removeEventListener('mousedown', handleClickOutside);
      };
    }
  }, [isDropdownOpen]);

  const models = [{
        id: "deepseek-chat",
        name: "Corex-1",
        description: "普通模型，响应迅速",
        color: isDark ? "from-blue-600 to-indigo-600" : "from-blue-500 to-indigo-500",
        icon: "bolt",
        bgColor: isDark ? "bg-blue-900/30" : "bg-blue-100"
    }, {
        id: "deepseek-reasoner",
        name: "Corex-1o",
        description: "深入思考，回答更精准",
        color: isDark ? "from-purple-600 to-pink-600" : "from-purple-500 to-pink-500",
        icon: "brain",
        bgColor: isDark ? "bg-purple-900/30" : "bg-purple-100"
    }, {
        id: "kimi-k2",
        name: "Corex-M1",
        description: "高级全能模型，功能全面",
        color: isDark ? "from-teal-600 to-emerald-600" : "from-teal-500 to-emerald-500",
        icon: "gem",
        bgColor: isDark ? "bg-teal-900/30" : "bg-teal-100"
    }];

    const getCurrentModelInfo = () => {
        return models.find(model => model.id === currentModel) || models[0];
    };

    const selectModel = (modelId: string) => {
        if (modelId !== currentModel) {
            setCurrentModel(modelId);
            const model = models.find(m => m.id === modelId);

            if (model) {
                toast.info(`已切换到 ${model.name}：${model.description}`);
            }
        }

        setIsDropdownOpen(false);
    };

    const currentModelInfo = getCurrentModelInfo();

    return (
         <div className="relative inline-block" ref={containerRef}>
            <motion.button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-full transition-all ${isDark ? "bg-gray-800 hover:bg-gray-700 border border-gray-700" : "bg-white hover:bg-gray-50 border border-gray-200 shadow-sm"}`}
                whileHover={{
                    scale: 1.02
                }}
                whileTap={{
                    scale: 0.98
                }}
                aria-haspopup="true"
                aria-expanded={isDropdownOpen}>
                <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center ${currentModelInfo.bgColor}`}>
                    <i
                        className={`fas fa-${currentModelInfo.icon} text-xs ${isDark ? "text-white" : `text-${currentModelInfo.color.split(" ")[1].split("-")[0]}-600`}`} />
                </div>
                <span
                    className={`text-sm font-medium ${isDark ? "text-gray-200" : "text-gray-800"}`}>
                    {currentModelInfo.name}
                </span>
                <></>
            </motion.button>
            <AnimatePresence>
                {isDropdownOpen && <motion.div
                    initial={{
                        opacity: 0,
                        x: -10,
                        scale: 0.95
                    }}
                    animate={{
                        opacity: 1,
                        x: 0,
                        scale: 1
                    }}
                    exit={{
                        opacity: 0,
                        x: -10,
                        scale: 0.95
                    }}
                    transition={{
                        duration: 0.2
                    }}
                    className={`absolute left-full top-0 ml-1 w-48 rounded-lg shadow-lg z-50 overflow-hidden ${isDark ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-200"}`}
                    style={{
                        zIndex: 9999
                    }}>
                    {models.map(model => <motion.button
                        key={model.id}
                        onClick={() => selectModel(model.id)}
                        className={`flex items-center gap-3 w-full text-left px-4 py-3 transition-colors ${currentModel === model.id ? isDark ? "bg-indigo-900/30 text-indigo-300" : "bg-indigo-50 text-indigo-700" : isDark ? "hover:bg-gray-700" : "hover:bg-gray-50"}`}
                        whileHover={{
                            x: 4
                        }}
                        whileTap={{
                            scale: 0.98
                        }}>
                        <div
                            className={`w-6 h-6 rounded-full flex items-center justify-center ${model.bgColor}`}>
                            <i
                                className={`fas fa-${model.icon} text-xs ${isDark ? "text-white" : `text-${model.color.split(" ")[1].split("-")[0]}-600`}`} />
                        </div>
                        <div>
                            <p className={`font-medium ${isDark ? "text-gray-200" : "text-gray-800"}`}>{model.name}</p>
                            <></>
                        </div>
                    </motion.button>)}
                </motion.div>}
            </AnimatePresence>
        </div>
    );
};

export default ModelSelector;