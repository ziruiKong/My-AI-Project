import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import { Link } from "react-router-dom";

interface NavigationBarProps {
    currentPage?: string;
}

const NavigationBar: React.FC<NavigationBarProps> = (
    {
        currentPage = ""
    }
) => {
    const {
        isDark,
        toggleTheme
    } = useTheme();

    const navItems = [{
        path: "/dashboard",
        label: "仪表盘",
        icon: "home"
    }, {
        path: "/favorites",
        label: "我的收藏",
        icon: "star"
    }, {
        path: window.location.pathname.includes("/runtime") ? "/runtime/q" : "/q",
        label: "COREX Q",
        icon: "question-circle"
    }, {
        path: "/api",
        label: "COREX API",
        icon: "code"
    }, {
        path: "/database",
        label: "数据库",
        icon: "database"
    }, {
        path: "/log",
        label: "工作日志",
        icon: "file-alt"
    }, {
        path: "/about",
        label: "关于我们",
        icon: "info-circle"
    }];

    return (
        <motion.nav
            className="glassmorphism sticky top-0 z-50 p-1 md:p-2 mb-4 transition-all duration-300"
            id="mainNav"
            initial={{
                opacity: 0,
                y: -20
            }}
            animate={{
                opacity: 1,
                y: 0
            }}
            transition={{
                duration: 0.5
            }}
            whileScroll={{
                paddingTop: 2,
                paddingBottom: 2,
                boxShadow: "0 4px 30px rgba(0, 0, 0, 0.1)"
            }}
            style={{
                background: isDark ? "rgba(15, 23, 42, 0.8)" : "rgba(255, 255, 255, 0.7)",
                backdropFilter: "blur(20px)",
                borderBottom: isDark ? "1px solid rgba(79, 70, 229, 0.1)" : "1px solid rgba(226, 232, 240, 0.5)",
                borderRadius: "0px",
                backgroundColor: "transparent"
            }}>
            <div className="container mx-auto flex items-center justify-between">
                <motion.div
                    className="flex items-center gap-2"
                    initial={{
                        opacity: 0,
                        x: -20
                    }}
                    animate={{
                        opacity: 1,
                        x: 0
                    }}
                    transition={{
                        duration: 0.5
                    }}>
                    <motion.div
                        className="flex items-center"
                        whileHover={{
                            scale: 1.02
                        }}
                        transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 10
                        }}>
                        {}
                        <div
                            className="w-24 h-24 mr-2 -mt-6 -mb-6 relative z-10"
                            style={{
                                backgroundColor: "transparent",
                                borderColor: "transparent"
                            }}>
                            <svg viewBox="0 0 120 40" className="w-full h-full">
                                <rect x="0" y="0" width="20" height="40" rx="2" fill="url(#logoGradient)" />
                                <rect x="25" y="0" width="20" height="40" rx="2" fill="url(#logoGradient)" />
                                <rect x="50" y="0" width="20" height="15" rx="2" fill="url(#logoGradient)" />
                                <rect x="50" y="25" width="30" height="15" rx="2" fill="url(#logoGradient)" />
                                <rect x="85" y="0" width="35" height="40" rx="2" fill="url(#logoGradient)" />
                                <defs>
                                    <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                                        <stop offset="0%" stopColor="#4f46e5" className="dark:stop-color-indigo-400" />
                                        <stop offset="50%" stopColor="#8b5cf6" className="dark:stop-color-purple-400" />
                                        <stop offset="100%" stopColor="#d946ef" className="dark:stop-color-pink-400" />
                                    </linearGradient>
                                </defs>
                            </svg>
                        </div>
                        <></>
                    </motion.div>
                </motion.div>
                <></>
                {}
                <div className="hidden md:flex items-center gap-1.5">
                    {navItems.map(item => <motion.div
                        key={item.path}
                        whileHover={{
                            scale: 1.03
                        }}
                        whileTap={{
                            scale: 0.97
                        }}
                        transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 15
                        }}>
                        <Link
                            to={item.path}
                            className={`relative px-4 py-2.5 rounded-xl text-sm font-medium transition-all flex items-center gap-2 overflow-hidden border ${item.path === currentPage ? isDark ? "bg-gradient-to-r from-indigo-900/40 to-purple-900/40 text-indigo-300 border-indigo-800/50 shadow-lg shadow-indigo-900/20" : "bg-gradient-to-r from-indigo-50 to-purple-50 text-indigo-700 border-indigo-200 shadow-md" : isDark ? "bg-transparent text-gray-300 hover:bg-gray-800 hover:text-indigo-300 border-transparent hover:border-indigo-800/30 hover:shadow-md" : "bg-transparent text-gray-700 hover:bg-gray-50 hover:text-indigo-600 border-transparent hover:border-indigo-200 hover:shadow-md"}`}>
                            <></>
                            <span
                                className="transition-transform duration-300"
                                style={{
                                    fontWeight: "bold"
                                }}>
                                {item.label}
                            </span>
                            {item.path === currentPage && <motion.div
                                layoutId="activeNavItem"
                                className="absolute inset-0 rounded-xl opacity-30 z-0"
                                style={{
                                    background: "linear-gradient(90deg, rgba(79,70,229,0.5) 0%, rgba(124,58,237,0.5) 100%)",
                                    filter: "blur(1px)",
                                    backgroundColor: "transparent",
                                    backgroundImage: "none"
                                }}
                                transition={{
                                    type: "spring",
                                    stiffness: 300,
                                    damping: 30
                                }} />}
                        </Link>
                    </motion.div>)}
                </div>
                <div className="flex items-center gap-3">
                    <></>
                    <motion.button
                        className="md:hidden p-1.5 rounded-full focus:outline-none"
                        id="mobileMenuButton"
                        aria-label="导航菜单"
                        whileTap={{
                            scale: 0.9
                        }}>
                        <i
                            className={`fas fa-bars text-lg ${isDark ? "text-gray-200" : "text-gray-700"}`} />
                    </motion.button>
                </div>
                <motion.div
                    className={`mobile-menu md:hidden absolute top-full left-0 right-0 mt-1 mx-4 rounded-xl z-40 shadow-lg ${isDark ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-200"}`}
                    id="mobileMenu"
                    initial={{
                        opacity: 0,
                        y: -10,
                        scale: 0.95
                    }}
                    animate={{
                        opacity: 1,
                        y: 0,
                        scale: 1
                    }}
                    transition={{
                        type: "spring",
                        stiffness: 300,
                        damping: 20
                    }}>
                    <div className="py-3 px-4">
                        {navItems.map((item, index) => <Link
                            key={index}
                            to={item.path}
                            className={`flex items-center gap-3 py-3 px-4 rounded-lg transition-all ${item.path === currentPage ? isDark ? "bg-indigo-900/30 text-indigo-300" : "bg-indigo-100 text-indigo-700" : isDark ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-100"}`}>
                            <i className={`fas fa-${item.icon} text-indigo-500 w-5 text-center`} />
                            <span>{item.label}</span>
                        </Link>)}
                    </div>
                    <div
                        className={`p-2 border-t ${isDark ? "border-gray-700" : "border-gray-100"}`}>
                        <button
                            onClick={toggleTheme}
                            className={`w-full text-left flex items-center justify-center gap-2 py-3 px-4 rounded-lg transition-all ${isDark ? "text-gray-300 hover:bg-gray-700" : "text-gray-700 hover:bg-gray-100"}`}>
                            <i
                                className={isDark ? "fas fa-sun text-yellow-400" : "fas fa-moon text-indigo-600"} />
                            <span>{isDark ? "切换到亮色模式" : "切换到深色模式"}</span>
                        </button>
                    </div>
                </motion.div>
            </div>
        </motion.nav>
    );
};

export default NavigationBar;