import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";

interface SpotifyPlayerProps {
  spotifyEmbedUrl: string;
  width?: string;
  height?: string;
  className?: string;
  onLoad?: () => void;
  autoPlay?: boolean;
}

const SpotifyPlayer: React.FC<SpotifyPlayerProps> = ({
  spotifyEmbedUrl,
  width = "100%",
  height = "152",
  className = "",
  onLoad,
  autoPlay = false
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current) {
      const handleLoad = () => {
        setIsLoaded(true);
        console.log("Spotify播放器已加载完成");
        if (onLoad) {
          onLoad();
        }
      };

      const handleError = () => {
        console.error("Spotify播放器加载失败");
        setHasError(true);
      };

      const iframe = iframeRef.current;
      iframe.addEventListener("load", handleLoad);
      iframe.addEventListener("error", handleError);

      // 清理函数
      return () => {
        iframe.removeEventListener("load", handleLoad);
        iframe.removeEventListener("error", handleError);
      };
    }
  }, [onLoad]);

  const containerVariants = {
    hidden: {
      opacity: 0,
      scale: 0.95
    },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  const overlayVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.3
      }
    }
  };

  return (
    <motion.div
      className={`relative rounded-xl overflow-hidden shadow-lg ${className}`}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {hasError && (
        <motion.div
          className="absolute inset-0 flex items-center justify-center bg-black/50 text-white"
          variants={overlayVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="text-center p-4">
            <p>Spotify播放器加载失败</p>
          </div>
        </motion.div>
      )}

      {!isLoaded && !hasError && (
        <motion.div
          className="absolute inset-0 flex items-center justify-center bg-black/30 text-white"
          variants={overlayVariants}
          initial="visible"
          animate={isLoaded ? "hidden" : "visible"}
        >
          <div className="text-center p-4">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-2"></div>
            <p>正在加载Spotify播放器...</p>
          </div>
        </motion.div>
      )}

       {/* 构建带自动播放参数的URL */}
      <iframe
        ref={iframeRef as React.RefObject<HTMLIFrameElement>}
        style={{ borderRadius: "12px" }}
        src={autoPlay && !spotifyEmbedUrl.includes('autoplay=') 
          ? `${spotifyEmbedUrl}${spotifyEmbedUrl.includes('?') ? '&' : '?'}autoplay=true` 
          : spotifyEmbedUrl}
        width={width}
        height={height}
        frameBorder="0"
        allowFullScreen
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
        loading="lazy"
      ></iframe>
    </motion.div>
  );
};

export default SpotifyPlayer;