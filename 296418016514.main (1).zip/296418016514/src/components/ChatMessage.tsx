import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useChat } from "../contexts/chatContext";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { CodeBlock, CodeBlockProps } from "./CodeBlock";
import { translateText } from "../lib/neteaseYoudaoAPI";
import { Link } from "react-router-dom";
import { TypewriterEffect } from "./TypewriterEffect";

interface Message {
    id: string;
    content: string;
    sender: "user" | "ai";
    timestamp: Date;
    type?: "text" | "image" | "file";
    fileInfo?: {
        name: string;
        size: number;
        type: string;
        url?: string;
    };
    isFavorite?: boolean;
    model?: "deepseek-chat" | "deepseek-reasoner";
    isStreaming?: boolean; // 是否正在流式传输
}

interface ChatMessageProps {
    message: Message;
    isDark: boolean;
    useTypewriter?: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = (
    {
        message,
        isDark,
        useTypewriter = true
    }
) => {
    const {
        toggleFavorite
    } = useChat();

    const isUser = message.sender === "user";
    const [showTranslation, setShowTranslation] = useState(false);
    const [translatedText, setTranslatedText] = useState<string | null>(null);

    const handleCopy = async () => {
        if (message.content) {
            try {
                await navigator.clipboard.writeText(message.content);
                toast.success("消息已复制到剪贴板");
            } catch (err) {
                toast.error("复制失败，请手动复制");
            }
        }
    };

    const handleFavorite = () => {
        toggleFavorite(message.id);
        toast.success(message.isFavorite ? "已取消收藏" : "已添加到收藏夹");
    };

    const handleImageDownload = () => {
        if (message.type === "image" && message.fileInfo?.url) {
            try {
                const link = document.createElement("a");
                link.href = message.fileInfo.url;
                const fileName = message.fileInfo.name || `downloaded-image-${Date.now()}.jpg`;
                link.download = fileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                toast.success(`图片 "${fileName}" 下载成功`);
            } catch (error) {
                console.error("下载图片失败:", error);
                toast.error("下载图片失败，请稍后重试");
            }
        }
    };

    const renderImageContent = () => {
        if (message.type === "image" && message.fileInfo?.url) {
            return (
                <motion.div
                    className="mt-2 rounded-lg overflow-hidden border border-gray-200 relative"
                    whileHover={{
                        scale: 1.02
                    }}
                    transition={{
                        type: "spring",
                        stiffness: 300,
                        damping: 20
                    }}>
                    <motion.img
                        src={message.fileInfo.url}
                        alt={message.fileInfo.name || "上传的图片"}
                        className="w-full h-auto max-h-80 object-contain"
                        initial={{
                            opacity: 0.8,
                            scale: 0.95
                        }}
                        animate={{
                            opacity: 1,
                            scale: 1
                        }}
                        transition={{
                            duration: 0.3
                        }} />
                    <motion.button
                        className="absolute top-2 right-2 bg-black/50 text-white p-1.5 rounded-full hover:bg-black/70 transition-colors"
                        whileHover={{
                            scale: 1.1
                        }}
                        whileTap={{
                            scale: 0.9
                        }}
                        onClick={handleImageDownload}
                        aria-label="下载图片"
                        style={{
                            borderRadius: "64px",
                            backgroundColor: "transparent"
                        }}>
                        <i className="fas fa-download text-sm"></i>
                    </motion.button>
                    {message.fileInfo.name && <p className="text-xs p-2 bg-gray-100 truncate">
                        {message.fileInfo.name}
                    </p>}
                </motion.div>
            );
        }

        return null;
    };

    const renderFileContent = () => {
        if (message.type === "file" && message.fileInfo) {
            const formatFileSize = (bytes: number) => {
                if (bytes < 1024)
                    return bytes + " B";
                else if (bytes < 1048576)
                    return (bytes / 1024).toFixed(1) + " KB";
                else
                    return (bytes / 1048576).toFixed(1) + " MB";
            };

            return (
                <motion.div
                    className="mt-2 p-3 rounded-lg border border-gray-200 bg-gray-50"
                    whileHover={{
                        scale: 1.02
                    }}
                    transition={{
                        type: "spring",
                        stiffness: 300,
                        damping: 20
                    }}>
                    <div className="flex items-center gap-3">
                        <div className="p-3 rounded-lg bg-gray-200">
                            <i className="fa-solid fa-file text-blue-500" size={24} />
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{message.fileInfo.name}</p>
                            <p className="text-xs text-gray-500">
                                {formatFileSize(message.fileInfo.size)}
                            </p>
                        </div>
                    </div>
                </motion.div>
            );
        }

        return null;
    };

    const containerVariants = {
        hidden: {
            opacity: 0,
            y: 10
        },

        visible: {
            opacity: 1,
            y: 0,

            transition: {
                duration: 0.3,
                ease: "easeOut"
            }
        }
    };

    const avatarVariants = {
        hidden: {
            scale: 0.8,
            opacity: 0
        },

        visible: {
            scale: 1,
            opacity: 1,

            transition: {
                duration: 0.3,
                ease: "easeOut"
            }
        },

        hover: {
            scale: 1.05,

            transition: {
                duration: 0.2,
                ease: "easeInOut"
            }
        }
    };

    const bubbleVariants = {
        hidden: {
            scale: 0.95,
            opacity: 0
        },

        visible: {
            scale: 1,
            opacity: 1,

            transition: {
                duration: 0.4,
                delay: 0.1,
                ease: "easeOut"
            }
        }
    };

    const mockUser = {
        name: "用户",
        avatar: ""
    };

    const aiAvatar = "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=modern%20robot%20ai%20assistant%20blue%20color%20technology%20theme&sign=8bbcdc325aa167378f88c0792d22d6c7";

    return (
        <motion.div
            initial={{
                opacity: 0,
                y: 10
            }}
            animate={{
                opacity: 1,
                y: 0
            }}
            transition={{
                duration: 0.2
            }}
            className={`flex ${isUser ? "justify-end" : "justify-start"} items-start gap-3 mb-4 chat-bubble message-enter`}
            data-message-id={message.id}
            style={{
                borderRadius: "16px"
            }}>
            <></>
            <div
                className="max-w-[85vw] sm:max-w-3xl relative"
                style={{
                    borderColor: "#D6DAE4"
                }}>
                {}
                {!isUser && message.timestamp && message.processingTime && <div className="text-xs text-gray-500 mb-1 flex items-center opacity-70">
                    <i className="fas fa-clock mr-1" size={12} />用时{message.processingTime}秒
                                                                                 </div>}
                <div
                    className={`px-4 py-4 rounded-2xl shadow-md transition-all duration-300 hover:shadow-lg ${isUser ? "bg-gradient-to-br from-white to-gray-50 border border-gray-100" : "bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-100"}`}
                    style={{
                        boxShadow: "rgba(0, 0, 0, 0.15) 0px 0px 30px 0px",
                        transition: "all 0.3s ease",
                        position: "relative"
                    }}
                    onMouseEnter={e => {
                        e.currentTarget.style.transform = "translateY(-1px)";
                        e.currentTarget.style.boxShadow = "0 6px 25px rgba(0, 0, 0, 0.12)";
                    }}
                    onMouseLeave={e => {
                        e.currentTarget.style.transform = "translateY(0)";
                        e.currentTarget.style.boxShadow = "0 4px 20px rgba(0, 0, 0, 0.08)";
                    }}>
                    {message.sender === "ai" ? (
                      useTypewriter ? (
                        <TypewriterEffect 
                          text={message.content} 
                          speed={30} 
                          isDark={isDark}
                          useTypewriter={true}
                        />
                      ) : (
                        <ReactMarkdown
                          className="prose max-w-none prose-indigo dark:prose-invert"
                          components={{
                            code: CodeBlock
                          }}>
                          {message.content}
                        </ReactMarkdown>
                      )
                    ) : (
                      <p className="whitespace-pre-wrap">{message.content}</p>
                    )}
                    <AnimatePresence>
                        {renderImageContent()}
                        {renderFileContent()}
                    </AnimatePresence>
                    {}
                    <div className="mt-3 flex gap-2 opacity-100">
                        <button
                            onClick={handleCopy}
                            className="text-xs text-gray-500 hover:text-indigo-600 transition-colors p-1.5 rounded-full hover:bg-gray-100"
                            aria-label="复制消息">
                            <i className="fa-regular fa-copy mr-1" />复制
                                                                                                                                                    </button>
                     <button
                        onClick={handleFavorite}
                        className={`text-xs ${message.isFavorite ? "text-yellow-500" : "text-gray-500 hover:text-yellow-500"} transition-colors p-1.5 rounded-full hover:bg-gray-100`}
                        aria-label={message.isFavorite ? "取消收藏" : "收藏消息"}>
                        <i
                            className={message.isFavorite ? "fa-solid fa-star mr-1" : "fa-regular fa-star mr-1"} />
                        {message.isFavorite ? "已收藏" : "收藏"}
                    </button>
                    <Link
                        to="/favorites"
                        className="text-xs text-gray-500 hover:text-indigo-600 transition-colors p-1.5 rounded-full hover:bg-gray-100"
                        aria-label="查看收藏夹">
                        <i className="fa-solid fa-bookmark mr-1" />
                        收藏夹
                    </Link>
                        <button
                            onClick={() => {
                                if (message.content) {
                                    const quotedText = `> ${message.content.replace(/\n/g, "\n> ")}\n\n`;

                                    try {
                                        const textarea = document.querySelector<HTMLTextAreaElement>("textarea[placeholder^='输入您的问题']");

                                        if (textarea) {
                                            const start = textarea.selectionStart;
                                            const end = textarea.selectionEnd;
                                            const newValue = textarea.value.substring(0, start) + quotedText + textarea.value.substring(end);
                                            textarea.value = newValue;

                                            textarea.dispatchEvent(new Event("input", {
                                                bubbles: true
                                            }));

                                            textarea.focus();
                                            textarea.selectionStart = textarea.selectionEnd = start + quotedText.length;
                                        }

                                        toast.success("已引用消息内容");
                                    } catch (error) {
                                        console.error("引用消息失败:", error);
                                        toast.error("引用失败，请手动复制内容");
                                    }
                                }
                            }}
                            className="text-xs text-gray-500 hover:text-blue-600 transition-colors"
                            aria-label="引用消息">
                            <i className="fa-regular fa-comment-dots mr-1" />引用
                                                                                 </button>
                        <button
                            onClick={async () => {
                                if (!message.content)
                                    return;

                                setShowTranslation(true);
                                setTranslatedText(null);

                                try {
                                    const translatedText = await translateText(message.content, "auto", "zh-CHS");
                                    setTranslatedText(translatedText);
                                } catch (error) {
                                    console.error("翻译失败:", error);

                                    if (error instanceof Error) {
                                        if (error.message.includes("Failed to fetch")) {
                                            setTranslatedText("翻译服务暂时不可用。在实际部署环境中，此功能将正常工作，使用网易有道API提供准确的翻译结果。");
                                        } else {
                                            setTranslatedText(`翻译失败: ${error.message}`);
                                        }
                                    } else {
                                        setTranslatedText("翻译失败，请稍后再试");
                                    }
                                }
                            }}
                            className="text-xs text-gray-500 hover:text-green-600 transition-colors p-1.5 rounded-full hover:bg-gray-100"
                            aria-label="翻译消息">
                            <i className="fa-solid fa-language mr-1" />翻译
                                                                                 </button>
                    </div>
                    {}
                    {showTranslation && <motion.div
                        className={`mt-3 p-4 rounded-xl text-sm ${isDark ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-100"} shadow-md`}
                        initial={{
                            opacity: 0,
                            y: -10
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        exit={{
                            opacity: 0,
                            y: -10
                        }}>
                        <div className="flex items-start justify-between">
                            <h4 className="font-medium mb-1">翻译结果</h4>
                            <button
                                onClick={() => setShowTranslation(false)}
                                className="text-xs text-gray-400 hover:text-gray-300">
                                <i className="fas fa-times" />
                            </button>
                        </div>
                        <p className={`${isDark ? "text-gray-300" : "text-gray-700"}`}>
                            {translatedText || "正在翻译..."}
                        </p>
                    </motion.div>}
                </div>
                {}
                {message.sender === "ai" && <div
                    className="mt-1 flex items-center gap-1 flex-wrap"
                    style={{
                        margin: "8px"
                    }}>
                    <span
                        className={`text-xs px-2 py-0.5 rounded-full ${message.model === "deepseek-reasoner" ? isDark ? "bg-purple-100/20 text-purple-400" : "bg-purple-100 text-purple-700" : message.model === "kimi-k2" ? isDark ? "bg-teal-100/20 text-teal-400" : "bg-teal-100 text-teal-700" : isDark ? "bg-indigo-100/20 text-indigo-400" : "bg-indigo-100 text-indigo-700"}`}
                    style={{
                        fontWeight: "bold"
                    }}>
                        {message.model === "deepseek-reasoner" ? "Corex-1o" : message.model === "kimi-k2" ? "Corex-M1" : "Corex-1"}
                    </span>
                </div>}
            </div>
        </motion.div>
    );
};