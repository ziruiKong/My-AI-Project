import React, { useState, useRef } from 'react';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';

// 定义代码块属性类型
export interface CodeBlockProps {
  children: React.ReactNode;
  className?: string;
}

// 代码块组件
export const CodeBlock: React.FC<CodeBlockProps> = ({ children, className }) => {
  const [isCopied, setIsCopied] = useState(false);
  
  // 提取语言类型
  const language = className?.replace('language-', '') || 'text';
  
  // 处理复制功能
  const handleCopy = async () => {
    try {
      const code = String(children);
      await navigator.clipboard.writeText(code);
      setIsCopied(true);
      toast.success('代码已复制到剪贴板');
      
      // 2秒后重置复制状态
      setTimeout(() => {
        setIsCopied(false);
      }, 2000);
    } catch (err) {
      console.error('复制失败:', err);
      toast.error('复制失败，请手动复制');
    }
  };
  
  // 处理下载代码文件
  const handleDownload = async () => {
    try {
      const code = String(children);
      // 创建Blob对象
      const blob = new Blob([code], { type: 'text/plain' });
      // 创建URL对象
      const url = URL.createObjectURL(blob);
      // 创建a标签
      const a = document.createElement('a');
      // 设置下载属性
      a.href = url;
      // 根据语言类型设置文件名
      const fileExtension = getFileExtension(language);
      a.download = `code.${fileExtension}`;
      // 添加到页面并触发下载
      document.body.appendChild(a);
      a.click();
      // 清理
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      // 显示成功提示
      toast.success('代码文件已下载');
    } catch (err) {
      console.error('下载失败:', err);
      toast.error('下载失败，请手动复制');
    }
  };
  
  // 根据语言获取文件扩展名
  const getFileExtension = (lang: string): string => {
    const extensionMap: Record<string, string> = {
      'javascript': 'js',
      'js': 'js',
      'typescript': 'ts',
      'ts': 'ts',
      'python': 'py',
      'java': 'java',
      'csharp': 'cs',
      'cpp': 'cpp',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'xml': 'xml',
      'sql': 'sql',
      'bash': 'sh',
      'shell': 'sh',
      'markdown': 'md',
      'md': 'md',
      'yaml': 'yaml',
      'yml': 'yml',
      'php': 'php',
      'ruby': 'rb',
      'go': 'go',
      'rust': 'rs',
      'swift': 'swift',
      'kotlin': 'kt',
      'scala': 'scala',
      'r': 'r',
      'matlab': 'm',
      'latex': 'tex',
      'dockerfile': 'dockerfile',
      'nginx': 'conf',
      'apache': 'conf',
      'properties': 'properties'
    };
    
    return extensionMap[lang.toLowerCase()] || 'txt';
  };
  
  // 处理查看代码详情
  const handleViewDetails = () => {
    // 在实际应用中，这里可以打开一个新的代码详情页
    // 现在我们先实现一个简单的提示
    const code = String(children);
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.write(`
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>代码详情</title>
          <script src="https://cdn.tailwindcss.com"></script>
          <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
          <style>
            body {
              font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
              background-color: #f8fafc;
            }
            .dark {
              background-color: #0f172a;
              color: #f8fafc;
            }
            code {
              font-family: 'Consolas', 'Monaco', monospace;
              line-height: 1.6;
            }
          </style>
        </head>
        <body class="p-4">
          <div class="max-w-5xl mx-auto">
            <div class="flex justify-between items-center mb-4">
              <h1 class="text-xl font-bold">代码详情 - ${language}</h1>
              <button id="copyButton" class="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                <i class="fa fa-copy mr-1"></i> 复制代码
              </button>
            </div>
            <div class="bg-gray-100 dark:bg-gray-800 p-4 rounded-md overflow-x-auto">
              <pre><code>${escapeHtml(code)}</code></pre>
            </div>
          </div>
          <script>
            // 实现复制功能
            document.getElementById('copyButton').addEventListener('click', async () => {
              const code = \`${escapeJs(code)}\`;
              try {
                await navigator.clipboard.writeText(code);
                alert('代码已复制到剪贴板');
              } catch (err) {
                console.error('复制失败:', err);
                alert('复制失败，请手动复制');
              }
            });
            
            // 检查系统主题并应用
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
              document.body.classList.add('dark');
            }
          </script>
        </body>
        </html>
      `);
      newWindow.document.close();
    }
  };
  
  // 处理代码预览 - 跳转到独立页面
  const handlePreview = () => {
    const code = String(children);
    const encodedCode = encodeURIComponent(code);
    window.open(`/code-runtime?code=${encodedCode}&language=${language}`, '_blank');
  };
  
  return (
    <div className="code-block my-4">
      {/* 代码头部 - 显示语言和复制按钮 */}
      <div className="code-header">
        <span>{language}</span>
        <div className="flex gap-2">
          <button 
            className="copy-button" 
            onClick={handleCopy}
            title={isCopied ? "已复制" : "复制代码"}
          >
            {isCopied ? (
              <><i className="fa fa-check mr-1"></i> 已复制</>
            ) : (
              <><i className="fa fa-copy mr-1"></i> 复制</>
            )}
          </button>
          <button 
            className="copy-button" 
            onClick={handleDownload}
            title="下载代码文件"
          >
            <i className="fa fa-download mr-1"></i> 下载
          </button>
          <button 
            className="copy-button" 
            onClick={handlePreview}
            title="预览和运行代码"
          >
            <i className="fa fa-external-link-alt mr-1"></i> 运行
          </button>
          <button 
            className="copy-button" 
            onClick={handleViewDetails}
            title="查看代码详情"
          >
            <i className="fa fa-external-link mr-1"></i> 详情
          </button>
        </div>
      </div>
      
      {/* 代码内容 */}
      <div className="code-content bg-gray-100 dark:bg-gray-800">
        <code className={`font-mono text-sm ${className}`}>
          {children}
        </code>
      </div>
      
      {/* 代码底部 - 显示操作提示 */}
      <div className="code-footer">
        <span>点击"运行"预览和执行代码，点击"复制"复制代码内容</span>
        <span>行数: {String(children).split('\\n').length}</span>
      </div>
      
      {/* 代码预览和运行模态框已移除，改为跳转到独立页面 */}
    </div>
  );
};

// 辅助函数：转义HTML特殊字符
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// 辅助函数：转义JavaScript特殊字符
function escapeJs(text: string): string {
  return text
    .replace(/`/g, "\\`")
    .replace(/\\/g, "\\\\")
    .replace(/\$/g, "\\$");
}