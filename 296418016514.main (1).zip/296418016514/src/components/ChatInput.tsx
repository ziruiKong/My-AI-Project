import { useRef, useState } from "react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import ModelSelector from "./ModelSelector";

interface ChatInputProps {
    inputValue: string;
    setInputValue: (value: string) => void;
    handleSendMessage: () => void;
    handleKeyPress: (e: React.KeyboardEvent) => void;
    isDark: boolean;
    onFileUpload: (file: File, type: "image" | "file") => void;
    isUploading: boolean;
    isDeepThinking: boolean;
    setIsDeepThinking: (value: boolean) => void;
    uploadedImages: Array<{
        file: File;
        previewUrl: string;
    }>;
    formatAsJson: boolean;
    setFormatAsJson: (value: boolean) => void;
    onSearch: (query: string) => void;
    onImageUrlSubmit: (url: string) => void;
    onGenerateImage: (prompt: string) => void;
    onInputModeChange: (mode: "normal" | "imageUrl" | "generateImage") => void;
    currentInputMode: "normal" | "imageUrl" | "generateImage";
    onAudioTranscribe: (file: File) => void;
    isProcessing: boolean;
    imageQuery?: string;
    setImageQuery?: (query: string) => void;
    stopGeneration: () => void;
    useTypewriterEffect?: boolean;
    setUseTypewriterEffect?: (value: boolean) => void;
}

const ChatInput: React.FC<ChatInputProps> = (
    {
        inputValue,
        setInputValue,
        handleSendMessage,
        handleKeyPress,
        isDark,
        onFileUpload,
        isUploading,
        isDeepThinking,
        setIsDeepThinking,
        formatAsJson,
        setFormatAsJson,
        onSearch,
        onImageUrlSubmit,
        onGenerateImage,
        onInputModeChange,
        currentInputMode,
        onAudioTranscribe,
        stopGeneration,
        isProcessing,
        uploadedImages,
        imageQuery,
        setImageQuery,
        useTypewriterEffect = false,
        setUseTypewriterEffect
    }
) => {
    const [isSearchEnabled, setIsSearchEnabled] = useState(false);
    const [isSearchFocused, setIsSearchFocused] = useState(false);

    const handleSearch = () => {
        if (inputValue.trim() && !isUploading) {
            setIsSearchEnabled(true);
            onSearch(inputValue.trim());
        }
    };

    const fileInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);

    const handleFileSelect = () => {
        if (!isUploading)
            fileInputRef.current?.click();
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files?.[0]) {
            const file = e.target.files[0];

            if (file.type.startsWith("image/")) {
                onFileUpload(file, "image");
            } else if (file.size > 10 * 1024 * 1024) {
                toast.error("文件大小不能超过10MB");
            } else {
                onFileUpload(file, "file");
            }
        }
    };

    const handleAudioTranscribe = () => {
        if (isUploading)
            return;

        const audioInput = document.createElement("input");
        audioInput.type = "file";
        audioInput.accept = "audio/*";
        audioInput.style.display = "none";

        audioInput.addEventListener("change", e => {
            if (e.target instanceof HTMLInputElement && e.target.files && e.target.files[0]) {
                const audioFile = e.target.files[0];

                if (audioFile.size > 10 * 1024 * 1024) {
                    toast.error("音频文件大小不能超过10MB");
                    return;
                }

                onAudioTranscribe(audioFile);
            }
        });

        document.body.appendChild(audioInput);
        audioInput.click();

        setTimeout(() => {
            document.body.removeChild(audioInput);
        }, 100);
    };

    const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setInputValue(e.target.value);
        e.target.style.height = "auto";
        e.target.style.height = Math.min(e.target.scrollHeight, 200) + "px";
    };

    const isSendDisabled = !inputValue.trim() || isUploading;
    const inputBgClass = isDark ? "bg-gray-800 border-gray-700 text-white placeholder-gray-400" : "bg-white border-gray-300 text-gray-800 placeholder-gray-500";
    const buttonBgClass = isDark ? "bg-indigo-600 hover:bg-indigo-700" : "bg-indigo-600 hover:bg-indigo-700";

    return (
        <div className="mt-6">
            {}
            <div className="relative">
                {}
                {}
                <div
                    className="absolute inset-0 rounded-xl -z-10 bg-white/60 dark:bg-gray-800/60 backdrop-blur-lg opacity-70"></div>
                {}
                <div
                    className="rounded-xl border border-white/50 dark:border-gray-700/50 bg-white/30 dark:bg-gray-800/30 overflow-hidden shadow-lg backdrop-blur-md relative z-10">
                    {}
                    <div className="p-4">
                        <div className="flex items-center gap-3">
                            {}
                            <ModelSelector />
                            {}
                            <div className="flex-1 flex justify-end gap-2">
                                <></>
                                <></>
                                <motion.button
                                    whileHover={{
                                        scale: 1.05,
                                        boxShadow: "0 4px 12px rgba(79, 70, 229, 0.2)"
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}
                                    className={`px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all duration-300 ${isDark ? "bg-gray-800 text-gray-200 hover:bg-gray-700 border border-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"} ${formatAsJson ? isDark ? "border-indigo-500" : "border-indigo-400" : ""}`}
                                    onClick={() => setFormatAsJson(!formatAsJson)}
                                    aria-label={formatAsJson ? "禁用代码模式" : "启用代码模式"}>
                                    <i
                                        className={`fas fa-code text-xs ${formatAsJson ? "text-indigo-500" : ""}`} />
                                    <span>代码模式</span>
                                </motion.button>
                                {setUseTypewriterEffect && <motion.button
                                    whileHover={{
                                        scale: 1.05,
                                        boxShadow: "0 4px 12px rgba(79, 70, 229, 0.2)"
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}
                                    className={`px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all duration-300 ${useTypewriterEffect ? isDark ? "bg-indigo-900/30 text-indigo-400 border border-indigo-700" : "bg-indigo-100 text-indigo-700 border border-indigo-200" : isDark ? "bg-gray-800 text-gray-200 hover:bg-gray-700 border border-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"}`}
                                    onClick={() => setUseTypewriterEffect(!useTypewriterEffect)}
                                    aria-label={useTypewriterEffect ? "关闭打字机效果" : "开启打字机效果"}>
                                    <i
                                        className={`fas fa-keyboard text-xs ${useTypewriterEffect ? "text-indigo-400" : ""}`} />
                                    <span>打字机效果</span>
                                </motion.button>}
                                <motion.button
                                    whileHover={{
                                        scale: 1.05,
                                        boxShadow: "0 4px 12px rgba(79, 70, 229, 0.2)"
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}
                                    className={`px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all duration-300 ${currentInputMode === "generateImage" ? isDark ? "bg-indigo-600 text-white border border-indigo-500" : "bg-indigo-500 text-white border border-indigo-400" : isDark ? "bg-gray-800 text-gray-200 hover:bg-gray-700 border border-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"}`}
                                    onClick={() => onInputModeChange(currentInputMode === "generateImage" ? "normal" : "generateImage")}
                                    aria-label={currentInputMode === "generateImage" ? "取消图片生成" : "图片生成"}>
                                    <i className="fas fa-image text-xs" />
                                    <span>图片生成</span>
                                </motion.button>
                                <></>
                            </div>
                        </div>
                    </div>
                    {}
                    <div className="p-4 pt-0 border-t border-gray-100 dark:border-gray-700">
                        <div className="flex items-center">
                            {}
                            <div className="flex items-center gap-2 mr-2">
                                <motion.button
                                    whileHover={{
                                        scale: 1.1
                                    }}
                                    whileTap={{
                                        scale: 0.9
                                    }}
                                    className="w-8 h-8 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-300"
                                    onClick={handleFileSelect}
                                    disabled={isUploading}
                                    aria-label="上传文件">
                                    <i className="fas fa-paperclip text-sm" />
                                </motion.button>
                                <motion.button
                                    whileHover={{
                                        scale: 1.1
                                    }}
                                    whileTap={{
                                        scale: 0.9
                                    }}
                                    className="w-8 h-8 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center justify-center text-gray-500 dark:text-gray-300"
                                    onClick={handleAudioTranscribe}
                                    disabled={isUploading}
                                    aria-label="音频识别">
                                    <i className="fas fa-microphone text-sm" />
                                </motion.button>
                                <></>
                            </div>
                            {}
                            <textarea
                                ref={textareaRef}
                                value={inputValue}
                                onChange={handleInput}
                                onKeyPress={handleKeyPress}
                                className={`flex-1 p-2 focus:outline-none resize-none ${inputBgClass} text-sm relative z-10`}
                                rows={3}
                                disabled={isUploading}
                                style={{
                                    minHeight: "80px",
                                    maxHeight: "150px",
                                    transition: "height 0.3s ease",
                                    boxShadow: "0 0 15px rgba(139, 92, 246, 0.3), 0 0 25px rgba(139, 92, 246, 0.15)",
                                    borderRadius: "16px",
                                    border: "1px solid rgba(139, 92, 246, 0.3)",
                                    backgroundColor: "transparent"
                                }} />
                            {}
                            <div className="flex items-center gap-2 ml-2">
                                <motion.button
                                    whileHover={{
                                        scale: 1.1,
                                        boxShadow: "0 4px 12px rgba(79, 70, 229, 0.3)"
                                    }}
                                    whileTap={{
                                        scale: 0.9
                                    }}
                                    className="w-8 h-8 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400"
                                    onClick={handleSearch}
                                    disabled={isUploading}
                                    aria-label="搜索网络">
                                    <i className="fas fa-search-globe text-sm"></i>
                                </motion.button>
                                <></>
                                {}
                                <motion.button
                                    whileHover={{
                                        scale: 1.05
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}
                                    onClick={() => {
                                        if (isSendDisabled)
                                            return;

                                        if (isProcessing) {
                                            stopGeneration();
                                            toast.info("已暂停生成，点击继续");
                                        } else {
                                            handleSendMessage();
                                        }
                                    }}
                                    disabled={isSendDisabled && !isProcessing}
                                    className={`w-10 h-10 rounded-full ${isSendDisabled ? "bg-gray-200 dark:bg-gray-700" : "bg-indigo-600 hover:bg-indigo-700"} text-white flex items-center justify-center shadow-md border border-white/20 transition-all duration-300`}
                                    aria-label="发送消息">
                                    {isProcessing ? <i className="fas fa-spinner fa-spin text-sm"></i> : <i className="fas fa-paper-plane text-sm"></i>}
                                </motion.button>
                            </div>
                        </div>
                    </div>
                    {}
                    {uploadedImages.length > 0 && <div className="px-4 pb-4 border-t border-gray-100 dark:border-gray-700">
                        <div className="flex flex-wrap gap-2 p-2">
                            {uploadedImages.map((image, index) => <div key={index} className="relative group">
                                <img
                                    src={image.previewUrl}
                                    alt={`上传的图片 ${index + 1}`}
                                    className="w-20 h-20 object-cover rounded-md" />
                                <button
                                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={e => {
                                        e.stopPropagation();
                                        const newImages = [...uploadedImages];
                                        newImages.splice(index, 1);
                                        console.log(`移除图片 ${index}`);
                                    }}
                                    aria-label="移除图片">×
                                                                                                                                                                                                                                                                                                                                        </button>
                            </div>)}
                        </div>
                    </div>}
                </div>
            </div>
            {}
            <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileChange}
                disabled={isUploading}
                accept="image/*, .pdf, .doc, .docx, .txt, .mp3, .wav, .ogg" />
        </div>
    );
};

export default ChatInput;