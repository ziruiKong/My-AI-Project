import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { useChat } from "../contexts/chatContext";

interface Conversation {
    id: string;
    title: string;
    timestamp: string;
    summary?: string;
    firstMessage?: string;
}

interface ChatSidebarProps {
    conversations: Conversation[];
    currentConversation: string | null;
    onConversationSelect: (id: string) => void;
    onNewConversation: () => void;
    isDark: boolean;
    isMobile: boolean;
    onClose: () => void;
    onDeleteConversation: (id: string) => void;
    firstQuestion?: string;
}

export const ChatSidebar: React.FC<ChatSidebarProps> = (
    {
        conversations,
        currentConversation,
        onConversationSelect,
        onNewConversation,
        isDark,
        isMobile,
        onClose,
        onDeleteConversation,
        firstQuestion
    }
) => {
    const containerVariants = {
        hidden: {
            opacity: 0
        },

        visible: {
            opacity: 1,

            transition: {
                staggerChildren: 0.1
            }
        }
    };

    const {
        favoriteMessages
    } = useChat();

    const [searchQuery, setSearchQuery] = useState("");

    const [contextMenu, setContextMenu] = useState<{
        x: number;
        y: number;
        conversationId: string;
    } | null>(null);

    const filteredConversations = searchQuery.trim() === "" ? conversations : conversations.filter(
        conversation => conversation.title.toLowerCase().includes(searchQuery.toLowerCase()) || conversation.summary && conversation.summary.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const [showFavorites, setShowFavorites] = useState(false);
    const contextMenuRef = useRef<HTMLDivElement>(null);
    const [showDeleteAllConfirm, setShowDeleteAllConfirm] = useState(false);
    const confirmModalRef = useRef<HTMLDivElement>(null);

    const handleContextMenu = (e: React.MouseEvent, conversationId: string) => {
        e.preventDefault();

        setContextMenu({
            x: e.clientX,
            y: e.clientY,
            conversationId
        });
    };

    const closeContextMenu = () => {
        setContextMenu(null);
    };

    const handleDeleteConversation = (conversationId: string) => {
        onDeleteConversation(conversationId);
        closeContextMenu();
    };

    const handleDeleteAllConversations = () => {
        localStorage.removeItem("conversations");
        setShowDeleteAllConfirm(false);
        onNewConversation();

        setTimeout(() => {
            window.location.reload();
        }, 500);
    };

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (confirmModalRef.current && !confirmModalRef.current.contains(e.target as Node)) {
                setShowDeleteAllConfirm(false);
            }
        };

        if (showDeleteAllConfirm) {
            document.addEventListener("click", handleClickOutside);

            return () => {
                document.removeEventListener("click", handleClickOutside);
            };
        }
    }, [showDeleteAllConfirm]);

    const DeleteAllConversationsButton: React.FC<{
        conversations: Conversation[];
        onDeleteAll: () => void;
    }> = (
        {
            conversations,
            onDeleteAll
        }
    ) => {
        return <></>;
    };

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (contextMenuRef.current && !contextMenuRef.current.contains(e.target as Node)) {
                closeContextMenu();
            }
        };

        if (contextMenu) {
            document.addEventListener("click", handleClickOutside);

            return () => {
                document.removeEventListener("click", handleClickOutside);
            };
        }
    }, [contextMenu]);

    const formatTimestamp = (date: Date): string => {
        const now = new Date();
        const messageDate = new Date(date);
        const isToday = messageDate.toDateString() === now.toDateString();

        if (isToday) {
            return messageDate.toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit"
            });
        } else {
            return messageDate.toLocaleDateString([], {
                month: "2-digit",
                day: "2-digit"
            });
        }
    };

    return (
        <>
            <motion.div
                initial={{
                    x: isMobile ? -300 : 0,
                    opacity: isMobile ? 0 : 1
                }}
                animate={{
                    x: 0,
                    opacity: 1
                }}
                exit={{
                    x: -300,
                    opacity: 0
                }}
                transition={{
                    type: "spring",
                    stiffness: 300,
                    damping: 30
                }}
                className={`${isMobile ? "fixed inset-y-0 left-0 z-50 w-[85%]" : "h-full"} flex flex-col glassmorphism sidebar overflow-hidden`}
                style={{
                    boxShadow: "rgba(0, 0, 0, 0.15) 0px 0px 30px 0px",
                    borderColor: "#D6DAE4",
                    backgroundColor: "#FFFFFF"
                }}>
                {}
                <></>
                {}
                <div className="p-3">
                    <div
                        className="relative rounded-lg bg-gray-100"
                        style={{
                            borderRadius: "29px"
                        }}>
                        <i
                            className="fa-solid fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                            size={16} />
                        <input
                            type="text"
                            placeholder="搜索对话"
                            className="w-full pl-9 pr-8 py-2 bg-transparent border-none focus:outline-none focus:ring-1 focus:ring-indigo-500 text-gray-800 placeholder-gray-400"
                            value={searchQuery}
                            onChange={e => setSearchQuery(e.target.value)} />
                        {searchQuery && <motion.button
                            whileHover={{
                                scale: 1.1
                            }}
                            whileTap={{
                                scale: 0.9
                            }}
                            className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 text-gray-500"
                            onClick={() => setSearchQuery("")}>
                            <i className="fa-solid fa-xmark text-xs" />
                        </motion.button>}
                    </div>
                </div>
                {}
                <div className="px-3 py-1">
                    <motion.button
                        onClick={onNewConversation}
                        className="w-full flex items-center gap-2 px-3 py-2.5 text-left rounded-lg transition-all bg-gray-100 hover:bg-gray-200"
                        whileHover={{
                            x: 2
                        }}
                        whileTap={{
                            scale: 0.98
                        }}
                        style={{
                            backgroundColor: "#FFFFFF",
                            boxShadow: "rgba(0, 0, 0, 0.15) 0px 2px 6px 0px"
                        }}>
                        <div
                            className="w-7 h-7 rounded-md flex items-center justify-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
                            <i className="fa-solid fa-plus" size={14} />
                        </div>
                        <span
                            className="text-sm"
                            style={{
                                fontWeight: "bold"
                            }}>新对话</span>
                    </motion.button>
                </div>
                {}
                <div className="mb-8 mt-4">
                    <></>
                    <div className="space-y-2 px-3">
                        <></>
                        {}
                        <div
                            className="h-[300px] overflow-y-auto pr-1 rounded-xl bg-white/80 dark:bg-gray-800/80 backdrop-blur-md border border-white/50 dark:border-gray-700/50 shadow-lg relative"
                            style={{
                                scrollbarWidth: "none",
                                "-ms-overflow-style": "none",
                                borderColor: "#D6DAE4",
                                borderWidth: "1px"
                            }}>
                            {}
                            <style jsx>{`
                              &::-webkit-scrollbar {
                                display: none;
                              }
                            `}</style>
                            {}
                            <div
                                className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md flex justify-between items-center">
                                <h3
                                    className="font-medium text-gray-700 dark:text-gray-300"
                                    style={{
                                        fontSize: "12px"
                                    }}>
                                    {searchQuery ? `搜索结果 (${filteredConversations.length})` : `对话 (${filteredConversations.length})`}
                                </h3>
                                {filteredConversations.length > 0 && <DeleteAllConversationsButton conversations={conversations} onDeleteAll={handleDeleteAllConversations} />}
                            </div>
                            {filteredConversations.length > 0 ? <div className="p-2 space-y-2">
                                {filteredConversations.map(conversation => <motion.div
                                    key={conversation.id}
                                    initial={{
                                        opacity: 0,
                                        y: 10
                                    }}
                                    animate={{
                                        opacity: 1,
                                        y: 0
                                    }}
                                    transition={{
                                        delay: Math.min(conversation.id.charCodeAt(0) * 0.01, 0.5),
                                        duration: 0.3
                                    }}>
                                    <motion.button
                                        whileHover={{
                                            scale: 1.02,
                                            backgroundColor: isDark ? "rgba(255, 255, 255, 0.08)" : "rgba(99, 102, 241, 0.05)",
                                            boxShadow: isDark ? "0 2px 10px rgba(0, 0, 0, 0.1)" : "0 2px 10px rgba(0, 0, 0, 0.05)"
                                        }}
                                        whileTap={{
                                            scale: 0.98
                                        }}
                                        onClick={() => onConversationSelect(conversation.id)}
                                        onContextMenu={e => handleContextMenu(e, conversation.id)}
                                        className={`w-full text-left p-3 rounded-lg transition-all flex items-center gap-3 ${currentConversation === conversation.id ? `bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border-l-4 border-indigo-500 text-indigo-700 dark:text-indigo-300` : "hover:bg-gray-50 dark:hover:bg-gray-700/50"}`}>
                                        {}
                                        <></>
                                        {}
                                        <div className="flex-1 min-w-0">
                                            <div className="flex items-start justify-between mb-1">
                                                <p
                                                    className="text-sm font-medium truncate"
                                                    style={{
                                                        fontWeight: "bold"
                                                    }}>{conversation.firstMessage || conversation.title}</p>
                                                <span className="text-xs text-gray-400 whitespace-nowrap ml-2">{conversation.timestamp}</span>
                                            </div>
                                            {conversation.summary && <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">
                                                {conversation.summary}
                                            </p>}
                                        </div>
                                        {}
                                        {currentConversation !== conversation.id && <></>}
                                    </motion.button>
                                </motion.div>)}
                            </div> : <motion.div
                                initial={{
                                    opacity: 0,
                                    y: 20
                                }}
                                animate={{
                                    opacity: 1,
                                    y: 0
                                }}
                                className="p-8 flex flex-col items-center justify-center h-full text-center">
                                <motion.div
                                    className="w-16 h-16 rounded-full flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 mb-4"
                                    animate={{
                                        scale: [1, 1.05, 1]
                                    }}
                                    transition={{
                                        duration: 2,
                                        repeat: Infinity,
                                        ease: "easeInOut"
                                    }}>
                                    <i className="fas fa-search text-xl"></i>
                                </motion.div>
                                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">没有找到匹配的对话</h3>
                                <p className="text-gray-500 dark:text-gray-400 max-w-sm mb-4">
                                    {searchQuery ? `没有找到与 "${searchQuery}" 相关的对话。尝试使用不同的关键词搜索。` : "您还没有创建任何对话。点击上方的'新对话'按钮开始聊天。"}
                                </p>
                                {!searchQuery && <motion.button
                                    onClick={onNewConversation}
                                    className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                                    whileHover={{
                                        scale: 1.05
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}>
                                    <i className="fas fa-plus mr-2"></i>新对话
                                                                                                                                                                                                                                                                                                                                                                            </motion.button>}
                            </motion.div>}
                        </div>
                        {}
                        {showDeleteAllConfirm && <motion.div
                            ref={confirmModalRef}
                            initial={{
                                opacity: 0,
                                scale: 0.9
                            }}
                            animate={{
                                opacity: 1,
                                scale: 1
                            }}
                            exit={{
                                opacity: 0,
                                scale: 0.9
                            }}
                            className="fixed inset-0 flex items-center justify-center z-50 bg-black/50 backdrop-blur-sm"
                            onClick={e => e.stopPropagation()}>
                            <motion.div
                                className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 max-w-md w-full mx-4"
                                initial={{
                                    y: 20
                                }}
                                animate={{
                                    y: 0
                                }}
                                transition={{
                                    type: "spring",
                                    stiffness: 300,
                                    damping: 30
                                }}>
                                <div className="flex justify-center mb-4">
                                    <motion.div
                                        className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center text-red-600 dark:text-red-400"
                                        animate={{
                                            scale: [1, 1.1, 1]
                                        }}
                                        transition={{
                                            duration: 1,
                                            repeat: Infinity,
                                            repeatType: "reverse"
                                        }}>
                                        <i className="fas fa-exclamation-triangle text-2xl"></i>
                                    </motion.div>
                                </div>
                                <h3 className="text-xl font-semibold text-center mb-2">确认删除所有对话？</h3>
                                <p className="text-gray-600 dark:text-gray-300 text-center mb-6">此操作将无法撤销，所有对话历史将被永久删除。
                                                                                                                                                                                                                                                                                                                                                                        </p>
                                <div className="flex gap-3">
                                    <motion.button
                                        onClick={() => setShowDeleteAllConfirm(false)}
                                        className="flex-1 py-2.5 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-medium"
                                        whileHover={{
                                            scale: 1.02
                                        }}
                                        whileTap={{
                                            scale: 0.98
                                        }}>取消
                                                                                                                                                                                                                                                                                                                                                                                                                </motion.button>
                                    <motion.button
                                        onClick={handleDeleteAllConversations}
                                        className="flex-1 py-2.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-medium"
                                        whileHover={{
                                            scale: 1.02,
                                            boxShadow: "0 0 15px rgba(239, 68, 68, 0.5)"
                                        }}
                                        whileTap={{
                                            scale: 0.98
                                        }}>确认删除
                                                                                                                                                                                                                                                                                                                                                                                                                </motion.button>
                                </div>
                            </motion.div>
                        </motion.div>}
                    </div>
                </div>
                {}
                <div>
                    <></>
                    <div className="space-y-2 px-3">
                        <></>
                        {}
                        <motion.div
                            className="space-y-3 px-3 pb-3"
                            variants={containerVariants}
                            initial="hidden"
                            animate="visible"
                            transition={{
                                staggerChildren: 0.1
                            }}>
                            {}
                            <></>
                            {}
                            <motion.button
                                whileHover={{
                                    x: 5,
                                    backgroundColor: "#F5F3FF",
                                    boxShadow: "0 10px 25px -5px rgba(139, 92, 246, 0.2)"
                                }}
                                whileTap={{
                                    scale: 0.98
                                }}
                                className="w-full flex items-center p-3 rounded-lg bg-white shadow-md hover:shadow-lg transition-all duration-300 border border-purple-100 group">
                                <motion.div
                                    className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center text-white mr-3"
                                    whileHover={{
                                        scale: 1.1,
                                        rotate: -5
                                    }}
                                    style={{
                                        boxShadow: "rgba(0, 0, 0, 0.15) 0px 0px 30px 0px"
                                    }}>
                                    <i className="fas fa-code text-lg"></i>
                                </motion.div>
                                <div className="flex-1 text-left">
                                    <h3
                                        className="font-semibold text-purple-700"
                                        style={{
                                            fontSize: "14px"
                                        }}>智能体</h3>
                                    <p className="text-xs text-gray-500">解决各类编程难题</p>
                                </div>
                                <motion.div
                                    className="text-purple-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    initial={{
                                        x: -10
                                    }}
                                    whileHover={{
                                        x: 0
                                    }}>
                                    <i className="fas fa-arrow-right"></i>
                                </motion.div>
                            </motion.button>
                            {}
                            <></>
                        </motion.div>
                        {}
                        <></>
                    </div>
                </div>
                {}
                <div className="mt-auto p-3 border-t border-gray-200">
                    <p
                        className="text-xs text-center text-gray-500"
                        style={{
                            fontWeight: "normal",
                            fontStyle: "normal",
                            fontSynthesisStyle: "auto",
                            fontFamily: "DOUYINSANSBOLD-GB"
                        }}>© 2025 COREX AI</p>
                </div>
            </motion.div>
            {}
            {contextMenu && <motion.div
                ref={contextMenuRef}
                initial={{
                    opacity: 0,
                    scale: 0.9
                }}
                animate={{
                    opacity: 1,
                    scale: 1
                }}
                exit={{
                    opacity: 0,
                    scale: 0.9
                }}
                className="fixed z-50 rounded-lg shadow-lg overflow-hidden bg-white border border-gray-200 w-48"
                style={{
                    left: contextMenu.x,
                    top: contextMenu.y
                }}>
                <motion.button
                    onClick={() => {
                        const conversationIndex = conversations.findIndex(c => c.id === contextMenu.conversationId);

                        if (conversationIndex > 0) {
                            const updatedConversations = [...conversations];
                            const conversation = updatedConversations.splice(conversationIndex, 1)[0];
                            updatedConversations.unshift(conversation);
                            localStorage.setItem("conversations", JSON.stringify(updatedConversations));
                            window.location.reload();
                        }

                        closeContextMenu();
                    }}
                    className="w-full text-left px-4 py-2 flex items-center gap-2 hover:bg-gray-200 transition-colors text-gray-800"
                    whileHover={{
                        x: 2
                    }}
                    whileTap={{
                        scale: 0.98
                    }}>
                    <i className="fa-solid fa-arrow-up text-green-500" size={16} />
                    <span>置顶对话</span>
                </motion.button>
                <motion.button
                    onClick={() => handleDeleteConversation(contextMenu.conversationId)}
                    className="w-full text-left px-4 py-2 flex items-center gap-2 hover:bg-gray-200 transition-colors text-gray-800"
                    whileHover={{
                        x: 2
                    }}
                    whileTap={{
                        scale: 0.98
                    }}>
                    <i className="fa-solid fa-trash text-red-500" size={16} />
                    <span>删除对话</span>
                </motion.button>
                <motion.button
                    onClick={() => {
                        onConversationSelect(contextMenu.conversationId);
                        closeContextMenu();
                    }}
                    className="w-full text-left px-4 py-2 flex items-center gap-2 hover:bg-gray-200 transition-colors text-gray-800"
                    whileHover={{
                        x: 2
                    }}
                    whileTap={{
                        scale: 0.98
                    }}>
                    <i className="fa-solid fa-pen text-blue-500" size={16} />
                    <span>重命名对话</span>
                </motion.button>
            </motion.div>}
        </>
    );
};