import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

interface SearchResult {
  id: string;
  title: string;
  url: string;
  snippet: string;
  date?: string;
  source?: string;
  icon?: string; // 可能来自百度API的网站图标
  type?: string; // 资源类型：web, video, image等
  content?: string; // 网页内容
}

interface SearchResultsProps {
  results: SearchResult[];
  isDark: boolean;
  onClose: () => void;
  isSearching: boolean;
}

export const SearchResults: React.FC<SearchResultsProps> = ({ 
  results, 
  isDark, 
  onClose,
  isSearching
}) => {
  const [activeTab, setActiveTab] = useState('all');
  const [viewMode, setViewMode] = useState<'summary' | 'embed'>('summary');
  const [selectedResult, setSelectedResult] = useState<SearchResult | null>(null);
  
  // 容器变体
  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.4,
        staggerChildren: 0.1
      }
    }
  };
  
  // 单个结果变体
  const resultVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.3 }
    },
    hover: { 
      x: 4,
      boxShadow: isDark 
        ? "0 4px 12px rgba(0, 0, 0, 0.3)" 
        : "0 4px 12px rgba(0, 0, 0, 0.1)",
      transition: { duration: 0.2 }
    }
  };

  // 骨架屏变体
  const skeletonVariants = {
    animate: {
      backgroundPosition: ["-200% 0", "200% 0"],
      transition: {
        duration: 1.5,
        repeat: Infinity,
        ease: "linear"
      }
    }
  };
  
  // 过滤结果
  const filteredResults = activeTab === 'all' 
    ? results 
    : results.filter(result => result.type === activeTab);
  
  // 处理嵌入查看
  const handleEmbedView = (result: SearchResult) => {
    setSelectedResult(result);
    setViewMode('embed');
  };
  
  // 返回摘要视图
  const handleBackToSummary = () => {
    setViewMode('summary');
    setSelectedResult(null);
  };
  
  // 尝试修复URL格式
  const fixUrl = (url: string): string => {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return `https://${url}`;
    }
    return url;
  };
  
  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={`fixed inset-0 bg-black/40 backdrop-blur-md z-50 flex items-center justify-center p-4`}
      onClick={onClose}
    >
      <motion.div
        className={`w-full max-w-5xl max-h-[90vh] rounded-xl overflow-hidden ${
          isDark ? 'bg-gray-800 text-gray-100' : 'bg-white text-gray-900'
        } shadow-2xl flex flex-col`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* 头部 */}
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-gray-700' : 'border-gray-200'}`}>
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900/30 dark:to-blue-900/30`}>
              <i className="fa-solid fa-search text-purple-600 dark:text-purple-400" size={20} />
            </div>
            <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-600 dark:from-purple-400 dark:to-blue-400">
              {viewMode === 'embed' && selectedResult ? selectedResult.title : '搜索结果'}
            </h3>
          </div>
          
          {viewMode === 'embed' && (
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleBackToSummary}
              className={`px-3 py-1.5 rounded-lg text-sm mr-2 ${
                isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'
              }`}
            >
              <i className="fa-solid fa-arrow-left mr-1" /> 返回结果
            </motion.button>
          )}
          
          <motion.button
            whileHover={{ scale: 1.1, rotate: 10 }}
            whileTap={{ scale: 0.9 }}
            onClick={onClose}
            className={`p-2 rounded-full ${isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-100'}`}
          >
            <i className="fa-solid fa-times" size={20} />
          </motion.button>
        </div>
        
        <AnimatePresence mode="wait">
          {viewMode === 'summary' ? (
            // 摘要视图
            <>
              {/* 标签页 */}
              {!isSearching && results.length > 0 && (
                <div className={`p-2 border-b ${isDark ? 'border-gray-700' : 'border-gray-200'} flex flex-wrap gap-1 overflow-x-auto`}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setActiveTab('all')}
                    className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                      activeTab === 'all' 
                        ? 'bg-blue-600 text-white' 
                        : `${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'}`
                    } transition-colors duration-200`}
                  >
                    全部结果
                  </motion.button>
                  {['web', 'image', 'video'].filter(type => 
                    results.some(result => result.type === type)
                  ).map(type => (
                    <motion.button
                      key={type}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setActiveTab(type)}
                      className={`px-3 py-1.5 rounded-full text-sm whitespace-nowrap ${
                        activeTab === type 
                          ? 'bg-blue-600 text-white' 
                          : `${isDark ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'}`
                      } transition-colors duration-200`}
                    >
                      {type === 'web' ? '网页' : type === 'image' ? '图片' : '视频'}
                    </motion.button>
                  ))}
                </div>
              )}
              
              {/* 结果内容 */}
              <div className="overflow-y-auto flex-1 max-h-[calc(90vh-112px)]">
                {isSearching ? (
                  // 加载状态 - 带爬虫动画的骨架屏
                  <div className="p-4 space-y-4">
                    <div className="flex items-center justify-center mb-4">
                      <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mr-3"></div>
                      <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                        正在使用网络爬虫搜索相关信息...
                      </p>
                    </div>
                    {[1, 2, 3].map((index) => (
                      <motion.div 
                        key={`skeleton-${index}`}
                        className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-100'}`}
                        variants={skeletonVariants}
                        animate="animate"
                        style={{
                          background: isDark 
                            ? 'linear-gradient(90deg, #1f2937 25%, #374151 50%, #1f2937 75%)'
                            : 'linear-gradient(90deg, #f3f4f6 25%, #e5e7eb 50%, #f3f4f6 75%)',
                          backgroundSize: '200% 100%'
                        }}
                      >
                        <div className="flex items-center mb-2">
                          <div className="h-4 rounded w-3/4"></div>
                          <div className="h-3 rounded w-16 ml-2 bg-indigo-500/20"></div>
                        </div>
                        <div className="flex items-center mb-2">
                          <div className="h-3 rounded w-10 bg-green-500/20 mr-2"></div>
                          <div className="h-3 rounded w-1/2"></div>
                        </div>
                        <div className="h-3 rounded w-full mb-2"></div>
                        <div className="h-3 rounded w-5/6"></div>
                      </motion.div>
                    ))}
                    <div className="text-center text-xs text-gray-500 mt-4">
                      正在从多个来源抓取信息，请耐心等待...
                    </div>
                  </div>
                ) : filteredResults.length > 0 ? (
                  // 搜索结果列表
                  <div className="p-4 space-y-4">
                    {filteredResults.map((result) => (
                      <motion.div
                        key={result.id}
                        variants={resultVariants}
                        whileHover="hover"
                        className={`p-4 rounded-lg transition-all ${
                          isDark ? 'bg-gray-700 hover:bg-gray-700/80' : 'bg-gray-50 hover:bg-gray-100'
                        } border ${isDark ? 'border-gray-600' : 'border-gray-200'}`}
                      >
                        <div className="flex items-start justify-between">
                          <h4 className="font-semibold text-blue-500 hover:underline cursor-pointer flex items-center gap-2">
                            {result.icon ? (
                              <img 
                                src={result.icon} 
                                alt="站点图标" 
                                className="w-4 h-4 object-contain" 
                              />
                            ) : (
                              <i className="fa-solid fa-globe text-xs" />
                            )}
                            {result.title}
                          </h4>
                          {result.date && (
                            <span className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                              {result.date}
                            </span>
                          )}
                        </div>
                        
                        <p className={`mt-1 text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'} line-clamp-2`}>
                          {result.snippet}
                        </p>
                        
                        {/* 显示网页内容 */}
                        {result.content && (
                          <motion.div 
                            className={`mt-2 p-3 rounded-md text-sm ${
                              isDark ? 'bg-gray-800 text-gray-300' : 'bg-gray-50 text-gray-700'
                            } overflow-hidden`}
                            initial={{ height: 60 }}
                            animate={{ height: 60 }}
                            whileHover={{ height: 'auto' }}
                            transition={{ duration: 0.3 }}
                          >
                            <p className={`line-clamp-3 ${
                              isDark ? 'text-gray-400' : 'text-gray-600'
                            }`}>
                              {result.content}
                            </p>
                            {result.content.length > 150 && (
                              <div className="mt-2 text-right">
                                <span className={`text-xs ${
                                  isDark ? 'text-indigo-400' : 'text-indigo-600'
                                } cursor-pointer hover:underline`}>
                                  悬停查看更多内容...
                                </span>
                              </div>
                            )}
                          </motion.div>
                        )}
                        
                        <div className="mt-2 flex items-center justify-between flex-wrap gap-2">
                          <div className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'} flex items-center gap-1`}>
                            <i className="fa-solid fa-link text-xs" />
                            <span className="truncate max-w-[200px]">{result.url}</span>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {result.source && (
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                isDark 
                                  ? 'bg-gray-600 text-gray-300' 
                                  : 'bg-gray-200 text-gray-700'
                              }`}>
                                {result.source}
                              </span>
                            )}
                            
                            {result.type && result.type !== 'web' && (
                              <span className={`text-xs px-2 py-0.5 rounded-full ${
                                isDark 
                                  ? 'bg-gray-600/70 text-gray-300' 
                                  : 'bg-gray-200/70 text-gray-700'
                              }`}>
                                {result.type === 'video' ? '视频' : 
                                 result.type === 'image' ? '图片' : 
                                 result.type === 'aladdin' ? '阿拉丁' : result.type}
                              </span>
                            )}
                            
                            {/* 嵌入查看按钮 */}
                            <motion.button
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                              onClick={() => handleEmbedView(result)}
                              className={`text-xs px-3 py-1 rounded-full ${
                                isDark 
                                  ? 'bg-blue-700/50 text-blue-300 hover:bg-blue-700' 
                                  : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                              } transition-colors duration-200 flex items-center gap-1`}
                            >
                              <i className="fa-solid fa-expand-alt text-xs" />
                              嵌入查看
                            </motion.button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  // 无结果状态
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center p-10 text-center"
                  >
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}>
                      <i className="fa-solid fa-search text-2xl text-gray-500" />
                    </div>
                    <h4 className="text-lg font-medium mb-2">未找到搜索结果</h4>
                    <p className={`max-w-md ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      尝试使用不同的关键词或检查拼写后重新搜索。
                    </p>
                  </motion.div>
                )}
              </div>
              
              {/* 底部 */}
              {!isSearching && results.length > 0 && (
                <div className={`p-3 border-t ${isDark ? 'border-gray-700 bg-gray-800/90' : 'border-gray-200 bg-white/90'} text-center`}>
                  <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                    共找到 {results.length} 条结果
                  </p>
                </div>
              )}
            </>
          ) : (
            // 嵌入视图
            selectedResult && (
              <motion.div
                key="embed-view"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="flex-1 flex flex-col"
              >
                {/* 嵌入的网页内容 */}
                <div className="flex-1 relative">
                  <iframe
                    src={fixUrl(selectedResult.url)}
                    title={selectedResult.title}
                    className="w-full h-full border-0"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-modals"
                  />
                  
                  {/* 浏览器安全提示 */}
                  <div className={`absolute top-0 left-0 right-0 p-2 text-xs text-center ${
                    isDark ? 'bg-gray-900/80 text-yellow-300' : 'bg-yellow-50 text-yellow-800'
                  } backdrop-blur-sm`}>
                    <i className="fa-solid fa-shield-alt mr-1" />
                    注意：由于浏览器安全限制，部分网站可能无法正常显示。建议在新标签页中打开查看完整内容。
                  </div>
                </div>
                
                {/* 嵌入视图底部工具栏 */}
                <div className={`p-3 border-t ${isDark ? 'border-gray-700 bg-gray-800/90' : 'border-gray-200 bg-white/90'} flex items-center justify-between`}>
                  <div className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'} truncate max-w-[50%]`}>
                    <i className="fa-solid fa-link text-xs mr-1" />
                    {selectedResult.url}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* 在新标签页中打开 */}
                    <motion.a
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      href={fixUrl(selectedResult.url)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`px-3 py-1.5 rounded-lg text-sm flex items-center gap-1 ${
                        isDark 
                          ? 'bg-gray-700 hover:bg-gray-600' 
                          : 'bg-gray-100 hover:bg-gray-200'
                      }`}
                    >
                      <i className="fa-solid fa-external-link-alt text-xs" />
                      在新标签页打开
                    </motion.a>
                    
                    {/* 返回结果列表 */}
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleBackToSummary}
                      className={`px-3 py-1.5 rounded-lg text-sm flex items-center gap-1 ${
                        isDark 
                          ? 'bg-blue-700 hover:bg-blue-600' 
                          : 'bg-blue-600 hover:bg-blue-700'
                      } text-white`}
                    >
                      <i className="fa-solid fa-arrow-left mr-1" />
                      返回结果
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
};