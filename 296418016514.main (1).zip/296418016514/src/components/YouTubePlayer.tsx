import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface YouTubePlayerProps {
    videoId: string;
    title: string;
    width?: number;
    height?: number;
    className?: string;
}

const YouTubePlayer: React.FC<YouTubePlayerProps> = (
    {
        videoId,
        title,
        width = 560,
        height = 315,
        className = ""
    }
) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);

    const handleLoad = () => {
        setIsLoaded(true);
        console.log("YouTube播放器已加载完成");
    };

    const handlePlayPause = () => {
        setIsPlaying(!isPlaying);
    };

    useEffect(() => {
        return () => {
            console.log("YouTube播放器组件已卸载");
        };
    }, []);

    const containerVariants = {
        hidden: {
            opacity: 0,
            scale: 0.95
        },

        visible: {
            opacity: 1,
            scale: 1,

            transition: {
                duration: 0.5
            }
        }
    };

    const overlayVariants = {
        hidden: {
            opacity: 0
        },

        visible: {
            opacity: 1,

            transition: {
                duration: 0.3
            }
        }
    };

    return (
        <motion.div
            className={`relative rounded-xl overflow-hidden shadow-lg ${className}`}
            variants={containerVariants}
            initial="hidden"
            animate="visible">
            {}
            <div className="aspect-video relative">
                <iframe
                    width={width}
                    height={height}
                    src={`https://www.youtube.com/embed/${videoId}?si=zc__XKQimZg9Plum&enablejsapi=1&rel=0`}
                    title={title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allowFullScreen
                    onLoad={handleLoad}
                    className="w-full h-full object-cover" />
                {}
                <motion.div
                    className={`absolute inset-0 flex items-center justify-center bg-black/50 ${isLoaded ? "hidden" : "flex"}`}
                    variants={overlayVariants}
                    initial="visible"
                    animate={isLoaded ? "hidden" : "visible"}>
                    <div className="text-white text-center p-4">
                        <div
                            className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-2"></div>
                        <p>正在加载视频...</p>
                    </div>
                </motion.div>
            </div>
            {}
            <></>
        </motion.div>
    );
};

export default YouTubePlayer;