import { useEffect, useRef, useState } from 'react';
import { useTheme } from '../hooks/useTheme';

interface Particle {
  x: number;
  y: number;
  radius: number;
  color: string;
  velocityX: number;
  velocityY: number;
}

interface DynamicParticlesProps {
  className?: string;
  particleCount?: number;
  particleSizeRange?: [number, number];
  speedRange?: [number, number];
  lineDistance?: number;
  useGradientBackground?: boolean;
}

export const DynamicParticles: React.FC<DynamicParticlesProps> = ({
  className = '',
  particleCount = 50,
  particleSizeRange = [1, 3],
  speedRange = [0.1, 0.5],
  lineDistance = 100,
  useGradientBackground = false
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const particlesRef = useRef<Particle[]>([]);
  const { isDark } = useTheme();
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isMouseOver, setIsMouseOver] = useState(false);

  // 初始化粒子
  const initParticles = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const { width, height } = canvasSize;
    const particles: Particle[] = [];
    
    // 根据主题选择颜色
    const colors = useGradientBackground 
      ? ['#a855f7', '#8b5cf6', '#6366f1', '#4f46e5', '#c084fc']
      : isDark 
        ? ['#a855f7', '#8b5cf6', '#6366f1', '#4f46e5', '#c084fc']
        : ['#9333ea', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95'];
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * (particleSizeRange[1] - particleSizeRange[0]) + particleSizeRange[0],
        color: colors[Math.floor(Math.random() * colors.length)],
        velocityX: (Math.random() - 0.5) * speedRange[1],
        velocityY: (Math.random() - 0.5) * speedRange[1]
      });
    }
    
    particlesRef.current = particles;
  };

  // 绘制粒子和连接线
  const drawParticles = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const { width, height } = canvasSize;
    
    // 清空画布
    ctx.clearRect(0, 0, width, height);
    
    // 如果需要渐变背景
    if (useGradientBackground) {
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      gradient.addColorStop(0, '#f0fc29');
      gradient.addColorStop(0.5, '#302b63');
      gradient.addColorStop(1, '#24243e');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);
    }
    
    // 绘制每个粒子
    particlesRef.current.forEach((particle, index) => {
      // 更新粒子位置
      particle.x += particle.velocityX;
      particle.y += particle.velocityY;
      
      // 边界检测
      if (particle.x < 0 || particle.x > width) particle.velocityX *= -1;
      if (particle.y < 0 || particle.y > height) particle.velocityY *= -1;
      
      // 鼠标交互 - 如果鼠标在画布上
      if (isMouseOver) {
        const dx = particle.x - mousePos.x;
        const dy = particle.y - mousePos.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        // 排斥效果
        if (distance < 80) {
          const force = (80 - distance) / 80;
          particle.x += (dx / distance) * force * 2;
          particle.y += (dy / distance) * force * 2;
        }
      }
      
      // 绘制粒子
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
      ctx.fillStyle = particle.color;
      ctx.fill();
      
      // 绘制连接线
      for (let j = index + 1; j < particlesRef.current.length; j++) {
        const otherParticle = particlesRef.current[j];
        const dx = particle.x - otherParticle.x;
        const dy = particle.y - otherParticle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < lineDistance) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(${hexToRgb(particle.color)}, ${1 - distance / lineDistance})`;
          ctx.lineWidth = 0.5;
          ctx.moveTo(particle.x, particle.y);
          ctx.lineTo(otherParticle.x, otherParticle.y);
          ctx.stroke();
        }
      }
    });
    
    // 请求下一帧动画
    animationRef.current = requestAnimationFrame(drawParticles);
  };

  // 辅助函数：将十六进制颜色转换为RGB
  const hexToRgb = (hex: string): string => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result 
      ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
      : '128, 128, 128';
  };

  // 设置画布大小
  const resizeCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const container = canvas.parentElement;
    if (!container) return;
    
    const { width, height } = container.getBoundingClientRect();
    canvas.width = width;
    canvas.height = height;
    setCanvasSize({ width, height });
  };

  // 处理鼠标移动
  const handleMouseMove = (e: MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    });
  };

  // 处理鼠标进入和离开
  const handleMouseEnter = () => {
    setIsMouseOver(true);
  };

  const handleMouseLeave = () => {
    setIsMouseOver(false);
  };

  // 组件挂载和卸载时的处理
  useEffect(() => {
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // 初始化粒子
    setTimeout(() => {
      initParticles();
      drawParticles();
    }, 100);
    
    // 添加鼠标事件监听
    const canvas = canvasRef.current;
    if (canvas) {
      canvas.addEventListener('mousemove', handleMouseMove);
      canvas.addEventListener('mouseenter', handleMouseEnter);
      canvas.addEventListener('mouseleave', handleMouseLeave);
    }
    
    // 清理函数
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      
      // 移除鼠标事件监听
      if (canvas) {
        canvas.removeEventListener('mousemove', handleMouseMove);
        canvas.removeEventListener('mouseenter', handleMouseEnter);
        canvas.removeEventListener('mouseleave', handleMouseLeave);
      }
    };
  }, [useGradientBackground]);

  // 主题变化时重新初始化粒子
  useEffect(() => {
    if (!useGradientBackground) {
      initParticles();
    }
  }, [isDark, useGradientBackground]);

  return (
    <canvas
      ref={canvasRef}
      className={`absolute inset-0 z-0 ${className}`}
      style={{ 
        display: 'block', 
        cursor: isMouseOver ? 'crosshair' : 'default',
        pointerEvents: 'auto' // 允许鼠标事件
      }}
    />
  );
};

export default DynamicParticles;