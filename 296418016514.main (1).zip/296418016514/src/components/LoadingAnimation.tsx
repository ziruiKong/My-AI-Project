import { motion } from 'framer-motion';

interface LoadingAnimationProps {
  isDark: boolean;
  isProcessingImage?: boolean;
  currentModel?: 'deepseek-chat' | 'deepseek-reasoner';
}

export const LoadingAnimation: React.FC<LoadingAnimationProps> = ({ isDark, isProcessingImage = false, currentModel = 'deepseek-chat' }) => {
  // 创建点动画的变体
  const dotVariants = {
    initial: { 
      y: 0,
    },
    animate: (index: number) => ({
      y: [0, -5, 0],
      transition: {
        duration: 0.6,
        ease: "easeInOut",
        repeat: Infinity,
        delay: index * 0.2
      }
    })
  };

  // 选择适当的文本
  const getLoadingText = () => {
    if (isProcessingImage) {
      return "正在分析图像...";
    }
    
     if (currentModel === 'deepseek-reasoner') {
      return "正在深入思考...";
    } else if (currentModel === 'deepseek-chat') {
      return "快速响应中...";
    }
    
    return "正在回复...";
  };

  return (
    <div className="flex items-center gap-2 py-2">
      {/* 简单的点动画 */}
      <div className="flex gap-1.5">
        {[1, 2, 3].map((index) => (
          <motion.div
            key={`dot-${index}`}
            custom={index}
            className={`w-1.5 h-1.5 rounded-full ${
              isDark ? 'bg-gray-500' : 'bg-gray-400'
            }`}
            variants={dotVariants}
            initial="initial"
            animate="animate"
          />
        ))}
      </div>
      
      {/* 主文本 */}
      <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
        {getLoadingText()}
      </span>
    </div>
  );
};