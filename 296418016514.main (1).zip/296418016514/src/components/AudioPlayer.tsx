import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";

interface AudioPlayerProps {
    src: string;
    autoPlay?: boolean;
    volume?: number;
    loop?: boolean;
    onPlayStateChange?: (isPlaying: boolean) => void;
    className?: string;
    fallbackSrc?: string;
}

const AudioPlayer: React.FC<AudioPlayerProps> = (
    {
        src,
        autoPlay = false,
        volume = 0.5,
        loop = true,
        onPlayStateChange,
        className = "",
        fallbackSrc = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    }
) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [hasUserInteracted, setHasUserInteracted] = useState(false);
    const [hasError, setHasError] = useState<boolean>(false);
    const [currentSrc, setCurrentSrc] = useState<string>(src);
    const kugouMusicRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const checkKugouLibrary = () => {
            if (typeof window !== "undefined" && (window as any).KugouPlayer) {
                console.log("酷狗音乐库已加载，可以使用");
                initializeKugouPlayer();
            } else {
                console.log("酷狗音乐库未加载，使用备用音频实现");
                initializeFallbackAudio();
            }
        };

        const initializeFallbackAudio = () => {
            try {
                const audioElement = document.createElement("audio");
                audioElement.src = currentSrc;
                audioElement.volume = volume;
                audioElement.loop = loop;
                document.body.appendChild(audioElement);
                kugouMusicRef.current = audioElement;

                audioElement.addEventListener("canplay", () => {
                    console.log("音频已准备就绪，可以播放");
                });

                audioElement.addEventListener("play", () => {
                    setIsPlaying(true);

                    if (onPlayStateChange) {
                        onPlayStateChange(true);
                    }
                });

                audioElement.addEventListener("pause", () => {
                    setIsPlaying(false);

                    if (onPlayStateChange) {
                        onPlayStateChange(false);
                    }
                });

                audioElement.addEventListener("error", error => {
                    console.error("音频加载或播放错误:", error);

                    if (currentSrc === src && fallbackSrc && src !== fallbackSrc) {
                        console.log("尝试使用备用音频URL");
                        setCurrentSrc(fallbackSrc);
                    } else {
                        setHasError(true);
                        toast.error("无法加载音频文件，请检查网络连接或稍后再试");
                    }
                });

                return () => {
                    if (audioElement && document.body.contains(audioElement)) {
                        audioElement.pause();
                        document.body.removeChild(audioElement);
                    }
                };
            } catch (error) {
                console.error("初始化备用音频失败:", error);
                setHasError(true);
            }
        };

        const initializeKugouPlayer = () => {
            try {
                if (typeof window !== "undefined") {
                    const kugou = (window as any).KugouPlayer;

                    if (kugou && kugou.create) {
                        const player = kugou.create({
                            element: "audio-player",
                            src: currentSrc,
                            autoPlay: autoPlay,
                            volume: volume,
                            loop: loop,

                            onPlay: () => {
                                setIsPlaying(true);

                                if (onPlayStateChange) {
                                    onPlayStateChange(true);
                                }
                            },

                            onPause: () => {
                                setIsPlaying(false);

                                if (onPlayStateChange) {
                                    onPlayStateChange(false);
                                }
                            },

                            onError: (error: any) => {
                                console.error("酷狗音乐播放错误:", error);
                                setHasError(true);
                                toast.error("酷狗音乐播放失败，使用备用音频");
                                initializeFallbackAudio();
                            }
                        });

                        kugouMusicRef.current = player;
                    } else {
                        console.error("酷狗音乐库缺少必要的API");
                        initializeFallbackAudio();
                    }
                }
            } catch (error) {
                console.error("初始化酷狗播放器失败:", error);
                setHasError(true);
                initializeFallbackAudio();
            }
        };

        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", checkKugouLibrary);

            return () => {
                document.removeEventListener("DOMContentLoaded", checkKugouLibrary);
            };
        } else {
            checkKugouLibrary();
        }
    }, [currentSrc, volume, loop, autoPlay, onPlayStateChange, src, fallbackSrc]);

    useEffect(() => {
        if (kugouMusicRef.current && kugouMusicRef.current instanceof HTMLAudioElement) {
            kugouMusicRef.current.src = currentSrc;

            if (isPlaying) {
                kugouMusicRef.current.play().catch(error => {
                    console.error("尝试恢复播放失败:", error);
                });
            }
        } else if (kugouMusicRef.current && typeof kugouMusicRef.current.setSrc === "function") {
            kugouMusicRef.current.setSrc(currentSrc);

            if (isPlaying) {
                kugouMusicRef.current.play();
            }
        }
    }, [currentSrc]);

     useEffect(() => {
        const handleUserInteraction = () => {
            if (!hasUserInteracted) {
                setHasUserInteracted(true);

                // 不再在用户首次交互时自动播放，除非明确设置了autoPlay
                if (autoPlay) {
                    try {
                        toggleMusic().catch(error => {
                            console.error("自动播放音频失败:", error);
                            toast.info("点击播放按钮开始播放背景音乐");
                        });
                    } catch (error) {
                        console.error("自动播放音频失败:", error);
                        toast.info("点击播放按钮开始播放背景音乐");
                    }
                }

                document.removeEventListener("click", handleUserInteraction);
                document.removeEventListener("keydown", handleUserInteraction);
            }
        };

        document.addEventListener("click", handleUserInteraction);
        document.addEventListener("keydown", handleUserInteraction);

        return () => {
            document.removeEventListener("click", handleUserInteraction);
            document.removeEventListener("keydown", handleUserInteraction);
        };
    }, [hasUserInteracted, autoPlay]);

     const toggleMusic = () => {
        try {
            if (kugouMusicRef.current && kugouMusicRef.current instanceof HTMLAudioElement) {
                if (isPlaying) {
                    kugouMusicRef.current.pause();
                 } else {
                    kugouMusicRef.current.play().catch(error => {
                      console.error("播放音频失败:", error);
                    });
                }
            } else if (kugouMusicRef.current) {
                if (typeof kugouMusicRef.current.toggle === "function") {
                    kugouMusicRef.current.toggle();
                } else if (typeof kugouMusicRef.current.play === "function" && typeof kugouMusicRef.current.pause === "function") {
                    if (isPlaying) {
                        kugouMusicRef.current.pause();
                    } else {
                         kugouMusicRef.current.play().catch(error => console.error("播放音频失败:", error));
                    }
                }
            } else {
                throw new Error("播放器未初始化");
            }
        } catch (error) {
            console.error("播放/暂停音频失败:", error);

            if (currentSrc === src && fallbackSrc && src !== fallbackSrc) {
                setCurrentSrc(fallbackSrc);

                setTimeout(() => {
                    toggleMusic();
                }, 100);
            } else {
                toast.error("无法播放音频，请稍后再试");
            }
        }
    };

    if (hasError) {
        return null;
    }

    return (
        <>
            {}
            <></>
        </>
    );
};

export default AudioPlayer;