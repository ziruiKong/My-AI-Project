import { useState, useEffect } from 'react';

interface TypewriterEffectProps {
  text: string;
  speed?: number;
  isDark: boolean;
  useTypewriter?: boolean;
}

export const TypewriterEffect: React.FC<TypewriterEffectProps> = ({ 
  text, 
  speed = 50,
  isDark,
  useTypewriter = true
}) => {
  const [displayText, setDisplayText] = useState<string>(useTypewriter ? '' : text);
  const [isComplete, setIsComplete] = useState<boolean>(!useTypewriter);

  useEffect(() => {
    // 如果不使用打字机效果，直接显示完整文本
    if (!useTypewriter) {
      setDisplayText(text);
      setIsComplete(true);
      return;
    }

    // 重置状态
    setDisplayText('');
    setIsComplete(false);

    // 如果文本为空，直接完成
    if (!text) {
      setIsComplete(true);
      return;
    }

    let index = 0;
    
    // 创建打字机效果
    const interval = setInterval(() => {
      if (index < text.length) {
        setDisplayText(text.substring(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setIsComplete(true);
      }
    }, speed);

    // 清理函数
    return () => clearInterval(interval);
  }, [text, speed, useTypewriter]);

  return (
    <div className="relative">
      <span className="inline-block">{displayText}</span>
      {!isComplete && (
        <span className={`inline-block w-1 h-4 ml-0.5 animate-pulse ${isDark ? 'bg-gray-400' : 'bg-gray-600'}`}></span>
      )}
    </div>
  );
};