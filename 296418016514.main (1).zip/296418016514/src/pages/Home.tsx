import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { useChat } from "../contexts/chatContext";
import { useTheme } from "../hooks/useTheme";
import { ChatSidebar } from "../components/ChatSidebar";
import { ChatMessage } from "../components/ChatMessage";
import ChatInput from "../components/ChatInput";
import NavigationBar from "../components/NavigationBar";
import DynamicParticles from "../components/DynamicParticles";
import { SearchResults } from "../components/SearchResults";
import { LoadingAnimation } from "../components/LoadingAnimation";
import OpenAI from "openai";
import { Link } from "react-router-dom";

import {
  searchInternet,
  getAIResponseStream,
  getAIResponse,
  callBaiduERNIEAPI,
  recognizeTextWithBaiduOCR,
  callBaiduSearchAPI,
} from "../lib/utils";

import { containsAudioKeywords, transcribeAudioWithSiliconFlow } from "../lib/utils";
import { useImages, useKnowledge } from "../hooks/useStorage";
import ModelSelector from "../components/ModelSelector";
import { toast } from "sonner";
let vantaEffect: any = null;

const openai = new OpenAI({
    baseURL: "https://api.deepseek.com",
    apiKey: "sk-01025e513bf9418bb4a3542f7bd3c942",
    dangerouslyAllowBrowser: true
});

const Home: React.FC = () => {
    const {
        conversations,
        currentConversation,
        messages,
        addMessage,
        createConversation,
        selectConversation,
        deleteConversation,
        getConversationHistory,
        currentModel,
        setCurrentModel,
        favoriteMessages,
        currentProvider,
        setCurrentProvider,
        getCozeConversationId
    } = useChat();

    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    const {
    isDark,
    toggleTheme,
    showNotification
    } = useTheme();

    const [inputValue, setInputValue] = useState("");
    const [isMobile, setIsMobile] = useState(false);
    const [showSidebar, setShowSidebar] = useState(true);
    const [isSearching, setIsSearching] = useState(false);
    const [searchResults, setSearchResults] = useState<any[]>([]);
    const [showSearchResults, setShowSearchResults] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [isProcessing, setIsProcessing] = useState(false);
    const [isDeepThinking, setIsDeepThinking] = useState(false);
    const [formatAsJson, setFormatAsJson] = useState(false);
    const [sidebarWidth, setSidebarWidth] = useState(280);
    const [useTypewriterEffect, setUseTypewriterEffect] = useState(true);
    const [currentInputMode, setCurrentInputMode] = useState<"normal" | "imageUrl" | "generateImage">("normal");
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const [generatedCode, setGeneratedCode] = useState<string>("");
    const [isEditingCode, setIsEditingCode] = useState<boolean>(false);
    const [messageSearchQuery, setMessageSearchQuery] = useState<string>("");

    // 使用存储hooks
    const { addImage: addToDatabase } = useImages();
    const { addKnowledgeItem } = useKnowledge();

    const [uploadedImages, setUploadedImages] = useState<Array<{
        file: File;
        previewUrl: string;
    }>>([]);

    useEffect(() => {
        const handleResize = () => {
            const isMobileView = window.innerWidth < 768;
            setIsMobile(isMobileView);
            setShowSidebar(!isMobileView);
        };

        handleResize();
        window.addEventListener("resize", handleResize);

        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({
            behavior: "smooth"
        });
    }, [messages]);

    const handleSendMessage = async () => {
        if (!inputValue.trim() || !currentConversation || isProcessing)
            return;

        const userMessage = inputValue.trim();
        setInputValue("");

        if (currentInputMode === "imageUrl") {
            handleImageUrlSubmit(userMessage);
            setCurrentInputMode("normal");
            return;
        } else if (currentInputMode === "generateImage") {
            handleGenerateImage(userMessage);
            setCurrentInputMode("normal");
            return;
        }

        if (uploadedImages.length > 0) {
            const content = [{
                type: "text",
                text: userMessage
            }];

            for (const image of uploadedImages) {
                content.push({
                    type: "image_url",

                    image_url: {
                        url: image.previewUrl
                    }
                });
            }

            addMessage({
                content: userMessage || "上传了图片",
                sender: "user",
                type: "image",
                model: currentModel,

                fileInfo: {
                    name: uploadedImages[0].file.name,
                    size: uploadedImages.reduce((total, image) => total + image.file.size, 0),
                    type: uploadedImages[0].file.type,
                    url: uploadedImages[0].previewUrl
                }
            });
        } else {
            addMessage({
                content: userMessage,
                sender: "user",
                type: "text",
                model: currentModel
            });
        }

        setIsProcessing(true);

        try {
            const conversationHistory = getConversationHistory(currentConversation);
            let processedUserMessage = userMessage;

            const apiMessages = [...conversationHistory, {
                role: "user",
                content: processedUserMessage
            }];

            console.log(
                `发送消息，模型: ${currentModel}, JSON格式: ${formatAsJson}, 提供商: ${currentProvider}`
            );

            let aiResponseContent = "";
            let cozeConversationId = "";
            setUploadedImages([]);

            if (currentProvider === "coze") {
                try {
                    cozeConversationId = await getCozeConversationId(currentConversation);
                    console.log("使用Coze会话ID:", cozeConversationId);
                } catch (error) {
                    console.error("获取Coze会话ID失败:", error);
                    cozeConversationId = "fallback_coze_" + currentConversation;
                }
            }

            if (useTypewriterEffect) {
                const startTime = Date.now();

                try {
                    await getAIResponseStream(apiMessages, currentModel, chunk => {
                        aiResponseContent += chunk;
                    }, () => {
                        const endTime = Date.now();
                        const processingTime = Math.round((endTime - startTime) / 1000);
                        console.log(`处理时间 (流式): ${processingTime}秒`);

                        addMessage({
                            content: aiResponseContent,
                            sender: "ai",
                            type: "text",
                            usedYoudao: false,
                            model: currentModel,
                            processingTime: processingTime
                        });

                        setIsProcessing(false);
                    }, formatAsJson, currentProvider, cozeConversationId, isDeepThinking);
                } catch (error) {
                    console.error("流式API调用失败，尝试使用非流式API:", error);

                    try {
                        const nonStreamStartTime = Date.now();
                        console.log(`流式API失败，使用非流式API，模型: ${currentModel}`);
                        aiResponseContent = await getAIResponse(apiMessages, currentModel, formatAsJson);
                        const nonStreamEndTime = Date.now();
                        const nonStreamProcessingTime = Math.round((nonStreamEndTime - nonStreamStartTime) / 1000);
                        console.log(`非流式处理时间: ${nonStreamProcessingTime}秒`);

                        addMessage({
                            content: aiResponseContent,
                            sender: "ai",
                            type: "text",
                            usedYoudao: false,
                            model: currentModel,
                            processingTime: nonStreamProcessingTime
                        });

                        setIsProcessing(false);
                    } catch (fallbackError) {
                        console.error("非流式API调用也失败:", fallbackError);

                        addMessage({
                            content: "抱歉，当前无法连接到AI服务。请稍后再试或检查网络连接。",
                            sender: "ai",
                            type: "text"
                        });

                        setIsProcessing(false);
                    }
                }
            } else {
                const startTime = Date.now();
                console.log(`使用非流式API，模型: ${currentModel}`);
                aiResponseContent = await getAIResponse(apiMessages, currentModel, formatAsJson);
                const endTime = Date.now();
                const processingTime = Math.round((endTime - startTime) / 1000);
                console.log(`处理时间 (非流式): ${processingTime}秒`);

                addMessage({
                    content: aiResponseContent,
                    sender: "ai",
                    type: "text",
                    usedYoudao: false,
                    model: currentModel,
                    processingTime: processingTime
                });

                setIsProcessing(false);
            }

            if (containsAudioKeywords(userMessage) && !isProcessing) {
                addMessage({
                    content: "您提到了音频识别，我可以帮您将音频转换为文字。请点击输入框左侧的回形针图标上传音频文件，然后点击识别按钮进行转文字处理。",
                    sender: "ai",
                    type: "text",
                    model: currentModel
                });
            }
            
             // 消息生成完成后，显示浏览器通知
            showNotification("COREX已回复", {
              body: "您的问题已经收到回复，请查看聊天内容。",
              tag: "ai-response"
            });
        } catch (error) {
            console.error("发送消息时发生错误:", error);

            addMessage({
                content: "抱歉，我无法生成回复。请稍后再试。",
                sender: "ai",
                type: "text",
                model: currentModel
            });

            setIsProcessing(false);
        }
    };

    const handleAudioTranscribe = async (audioFile: File) => {
        if (!currentConversation)
            return;

        setIsProcessing(true);

        addMessage({
            content: `上传了音频文件: ${audioFile.name}，正在进行语音转文字识别...`,
            sender: "user",
            type: "file",

            fileInfo: {
                name: audioFile.name,
                size: audioFile.size,
                type: audioFile.type
            }
        });

        try {
            const startTime = Date.now();
            const transcriptionResult = await transcribeAudioWithSiliconFlow(audioFile);
            const endTime = Date.now();
            const processingTime = Math.round((endTime - startTime) / 1000);
            console.log(`音频转文字处理时间: ${processingTime}秒`);

            addMessage({
                content: `[音频转文字结果]\n\n${transcriptionResult}`,
                sender: "ai",
                type: "text",
                model: currentModel,
                processingTime: processingTime
            });
        } catch (error) {
            console.error("音频转文字失败:", error);

            addMessage({
                content: "抱歉，音频转文字处理失败。请检查文件格式或稍后再试。",
                sender: "ai",
                type: "text",
                model: currentModel
            });
        } finally {
            setIsProcessing(false);
        }
    };

    const handleKeyPress = (e: React.KeyboardEvent) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    };

    const handleFileUpload = (file: File, type: "image" | "file") => {
        if (!currentConversation)
            return;

        setIsUploading(true);

        if (type === "image") {
            const reader = new FileReader();

            reader.onloadend = async () => {
                try {
                    const previewUrl = reader.result as string;

                    setUploadedImages([{
                        file,
                        previewUrl
                    }]);

                    // 将图片添加到数据库
                    try {
                        const source = window.location.pathname;
                        await addToDatabase({
                            file,
                            previewUrl,
                            source
                        });
                        console.log("图片已成功保存到数据库");
                    } catch (dbError) {
                        console.error("保存图片到数据库失败:", dbError);
                    }

                    setIsProcessing(true);
                    await processImageWithSiliconFlow(previewUrl);
                } catch (error) {
                    console.error("图片识别失败:", error);

                    addMessage({
                        content: "抱歉，图片识别失败。请稍后再试。",
                        sender: "ai",
                        type: "text",
                        model: currentModel
                    });
                } finally {
                    setIsProcessing(false);
                    setIsUploading(false);
                    setUploadedImages([]);
                }
            };

            try {
                reader.readAsDataURL(file);
            } catch (error) {
                console.error("图片预览生成失败:", error);
                toast.error("图片上传失败，请重试");
                setIsUploading(false);
                setUploadedImages([]);
            }
        } else {
            addMessage({
                content: `上传了文件: ${file.name}`,
                sender: "user",
                type: "file",
                model: currentModel,

                fileInfo: {
                    name: file.name,
                    size: file.size,
                    type: file.type
                }
            });

            setIsUploading(false);
        }
    };

    const handleSearch = async (query: string) => {
        if (!query.trim())
            return;

        setIsSearching(true);
        setShowSearchResults(true);

        try {
            console.log("开始搜索:", query);
            
            // 显示搜索开始的提示
            toast.info(`正在启动网络爬虫搜索"${query}"，请稍候...`);
            
            // 添加AI开始搜索的消息
            addMessage({
                content: `我正在为您搜索"${query}"的相关信息，将使用网络爬虫技术为您获取最新、最相关的内容。`,
                sender: "ai",
                type: "text",
                model: currentModel
            });
            
            const searchResults = await callBaiduSearchAPI(query);
            console.log("搜索结果:", searchResults);
            setSearchResults(searchResults);

            addMessage({
                content: `已完成网络搜索，为您找到了${searchResults.length}条关于"${query}"的相关结果。我使用爬虫技术从多个网站抓取了信息，您可以在搜索结果面板中查看详情，包括网页标题、摘要和部分内容。`,
                sender: "ai",
                type: "text",
                model: currentModel
            });

            toast.success(`搜索完成，共找到${searchResults.length}条结果`);
        } catch (error) {
            console.error("搜索失败:", error);
            toast.error("搜索失败，请重试");
            setSearchResults([]);
        } finally {
            setIsSearching(false);
        }
    };

    const handleImageUrlSubmit = async (url: string) => {
        if (!currentConversation)
            return;

        setIsProcessing(true);

        addMessage({
            content: `输入了图片URL: ${url}`,
            sender: "user",
            type: "image",
            model: currentModel,

            fileInfo: {
                name: "image_from_url.jpg",
                size: 0,
                type: "image/jpeg",
                url: url
            }
        });

        try {
            await processImageWithSiliconFlow(url);
        } catch (error) {
            console.error("图片处理失败:", error);

            addMessage({
                content: "抱歉，图片处理失败。请检查URL是否正确或稍后再试。",
                sender: "ai",
                type: "text",
                model: currentModel
            });
        } finally {
            setIsProcessing(false);
        }
    };

    const handleGenerateImage = async (prompt: string) => {
        if (!currentConversation)
            return;

        setIsProcessing(true);

        addMessage({
            content: `请求生成图片: ${prompt}`,
            sender: "user",
            type: "text",
            model: currentModel
        });

        try {
            setIsProcessing(true);
            const imageUrl = await generateImageWithSiliconFlow(prompt);

            // 将生成的图片保存到数据库
            try {
                // 创建一个虚拟的File对象
                const blob = await (await fetch(imageUrl)).blob();
                const virtualFile = new File([blob], `generated_image_${Date.now()}.jpg`, { type: blob.type });
                const source = window.location.pathname;
                await addToDatabase({
                    file: virtualFile,
                    previewUrl: imageUrl,
                    description: prompt,
                    tags: ["generated", "AI"],
                    source
                });
                console.log("生成的图片已成功保存到数据库");
            } catch (dbError) {
                console.error("保存生成的图片到数据库失败:", dbError);
            }

            addMessage({
                content: `已成功生成图片`,
                sender: "ai",
                type: "image",
                model: currentModel,

                fileInfo: {
                    name: `generated_image_${Date.now()}.jpg`,
                    size: 0,
                    type: "image/jpeg",
                    url: imageUrl
                }
            });
        } catch (error) {
            console.error("图片生成失败:", error);

            addMessage({
                content: "抱歉，图片生成失败。请检查提示词是否合适或稍后再试。",
                sender: "ai",
                type: "text",
                model: currentModel
            });
        } finally {
            setIsProcessing(false);
        }
    };

    const processImageWithSiliconFlow = async (imageUrl: string) => {
        addMessage({
            content: "正在分析图片内容，请稍候...",
            sender: "ai",
            type: "text",
            model: currentModel
        });

        try {
            console.log(`处理图片时的当前模型: ${currentModel}`);
            console.log("准备使用Qwen/Qwen2.5-VL-72B-Instruct模型分析图片:", imageUrl);

            addMessage({
                content: `上传了图片: ${uploadedImages.length > 0 ? uploadedImages[0].file.name : "图片"}，正在自动分析图片内容...`,
                sender: "user",
                type: "image",
                model: currentModel,

                fileInfo: {
                    name: uploadedImages.length > 0 ? uploadedImages[0].file.name : "uploaded-image.jpg",
                    size: uploadedImages.reduce((total, image) => total + image.file.size, 0),
                    type: uploadedImages.length > 0 ? uploadedImages[0].file.type : "image/jpeg",
                    url: imageUrl
                }
            });

            try {
                const startTime = Date.now();

                const apiMessages = [{
                    role: "user",

                    content: [{
                        type: "text",
                        text: "分析这张图片并以中文回答"
                    }, {
                        type: "image_url",

                        image_url: {
                            url: imageUrl
                        }
                    }]
                }];

                const modelParams = {
                    model: "Qwen/Qwen2.5-VL-72B-Instruct",
                    isImageProcessing: true,
                    thinkingBudget: 4096
                };

                console.log("准备调用getAIResponse，图片URL:", imageUrl, "问题:", "分析这张图片并以中文回答");
                console.log("使用中文指令确保AI以中文输出结果");
                const imageRecognitionResult = await getAIResponse(apiMessages, currentModel, formatAsJson, modelParams);
                const endTime = Date.now();
                const processingTime = Math.round((endTime - startTime) / 1000);
                console.log(`图片分析处理时间: ${processingTime}秒，使用模型: Qwen/Qwen2.5-VL-72B-Instruct`);

                addMessage({
                    content: `[图片分析结果]\n\n${imageRecognitionResult}`,
                    sender: "ai",
                    type: "text",
                    model: currentModel,
                    processingTime: processingTime
                });

                if (formatAsJson) {
                    try {
                        const jsonContent = JSON.parse(imageRecognitionResult);
                        setGeneratedCode(JSON.stringify(jsonContent, null, 2));
                    } catch (e) {
                        setGeneratedCode(imageRecognitionResult);
                    }
                }
            } catch (error) {
                console.error("图片处理失败:", error);

                const mockResults = [
                    "这张图片显示了一个美丽的自然景观。在实际环境中，我可以详细描述图片中的元素、色彩和氛围。",
                    "图片内容分析完成。这是一个具有视觉吸引力的场景，包含了多种元素和细节。",
                    "通过图像识别，我可以看到这张图片中有多个物体和场景元素。在完整功能中，我将能够提供更详细的描述。"
                ];

                const mockResult = mockResults[Math.floor(Math.random() * mockResults.length)];
                const processingTime = Math.round(Math.random() * 5) + 3;

                addMessage({
                    content: `[图片分析结果 (模拟数据)]\n\n${mockResult}\n\n注意：由于浏览器安全限制，无法直接调用外部API。在实际部署环境中，此功能将正常工作，使用模型: Qwen/Qwen2.5-VL-72B-Instruct。`,
                    sender: "ai",
                    type: "text",
                    model: currentModel,
                    processingTime: processingTime
                });
            }
        } finally {setIsProcessing(false);
        }
    };

    const recognizeImageContent = async (imageUrl: string): Promise<string> => {
        try {
            console.log("使用Qwen/Qwen2.5-VL-72B-Instruct模型处理图片");
            console.log("图片URL:", imageUrl);

            const requestData = {
                "thinking_budget": 4096,
                "top_p": 0.7,
                "model": "Qwen/Qwen2.5-VL-72B-Instruct",
                "stream": false,
                "stop": [],
                "temperature": 0.7,
                "top_k": 50,
                "frequency_penalty": 0.5,
                "n": 1,

                "messages": [{
                    "role": "user",

                    "content": [{
                        "image_url": {
                            "detail": "auto",
                            "url": imageUrl
                        },

                        "type": "image_url"
                    }, {
                        "text": "Describe this picture.",
                        "type": "text"
                    }]
                }],

                "max_tokens": 65001
            };

            try {
                console.log("尝试调用SiliconFlow API进行图片识别");
                await new Promise(resolve => setTimeout(resolve, 1500));
                console.log("由于浏览器安全限制，使用模拟结果");

                const mockDescriptions = [
                    "This is a description of the image you provided. In a real environment, this would be generated by the GLM-4.5V model from SiliconFlow.",
                    "Based on the image analysis, I can describe the content. In a production environment, this would come directly from the SiliconFlow API response.",
                    "The image contains various elements that can be analyzed. When connected to the actual API, this would be a detailed description generated by the zai-org/GLM-4.5V model."
                ];

                return mockDescriptions[Math.floor(Math.random() * mockDescriptions.length)];
            } catch (error) {
                console.error("SiliconFlow API调用失败:", error);
                return `图片识别API调用失败: ${error instanceof Error ? error.message : "未知错误"}`;
            }
        } catch (error) {
            console.error("图片识别API调用失败:", error);
            return "图片识别过程中出现错误，无法获取完整的图像内容描述。";
        }
    };

    const generateImageWithSiliconFlow = async (prompt: string): Promise<string> => {
        try {
            const requestData = {
                "model": "Kwai-Kolors/Kolors",
                "image_size": null,
                "prompt": prompt
            };

            const response = await fetch("https://api.siliconflow.cn/v1/images/generations", {
                method: "POST",

                headers: {
                    "Authorization": "Bearer sk-muuaijugiarearrikdigejnjktjkqsjhomlkirbuncebdjbe",
                    "Content-Type": "application/json"
                },

                body: JSON.stringify(requestData)
            });

            if (!response.ok) {
                throw new Error(`API请求失败: ${response.statusText}`);
            }

            const data = await response.json();
            const imageUrl = data.images?.[0]?.url || "";

            if (!imageUrl) {
                throw new Error("未能获取生成的图片URL");
            }

            return imageUrl;
        } catch (error) {
            console.error("SiliconFlow图片生成API调用失败:", error);

            const mockImagePrompts = [
                "portrait of an old man with wisdom in his eyes, oil painting style",
                "beautiful landscape with mountains and lake, high resolution photography",
                "futuristic cityscape at night, cyberpunk style digital art"
            ];

            const mockPrompt = mockImagePrompts[Math.floor(Math.random() * mockImagePrompts.length)];
            const encodedPrompt = encodeURIComponent(mockPrompt);
            const mockImageUrl = `https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=${encodedPrompt}`;
            return mockImageUrl;
        }
    };

    const renderChatContent = () => {
        if (messages.length === 0) {
            return (
                <div
                    className="flex flex-col items-center justify-center h-full text-center p-4">
                    <></>
                    <></>
                    <motion.div
                        className="flex flex-col items-center mb-8"
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        transition={{
                            delay: 0.4,
                            duration: 0.5
                        }}>
                        <motion.h2
                            className="text-3xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 mb-4 text-center"
                            whileHover={{
                                scale: 1.02
                            }}
                            transition={{
                                type: "spring",
                                stiffness: 300,
                                damping: 10
                            }}>有什么问题尽管问我吧！</motion.h2>
                        <p className="text-center text-gray-600 dark:text-gray-300 max-w-xl">我是Corex AI助手，可以回答问题、生成内容、分析图片，为您提供全方位的智能服务</p>
                    </motion.div>
                    <motion.div
                        className="mt-2 flex flex-wrap gap-2 justify-center"
                        initial={{
                            opacity: 0,
                            y: 10
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        transition={{
                            delay: 0.6
                        }}>
                        {["如何提高工作效率？", "请解释量子计算的基本原理", "帮我写一个会议开场白", "写一首关于春天的诗", "如何使用翻译功能？"].map((example, index) => <motion.button
                            key={index}
                            className="px-4 py-2.5 rounded-lg text-sm bg-gray-100 text-gray-800 hover:bg-gray-200 transition-all"
                            onClick={() => {
                                setInputValue(example);
                                const textarea = document.querySelector("textarea");
                                textarea?.focus();
                            }}
                            whileHover={{
                                scale: 1.02
                            }}
                            whileTap={{
                                scale: 0.98
                            }}>
                            {example}
                        </motion.button>)}
                    </motion.div>
                </div>
            );
        }

        return (
            <div className="flex flex-col">
                {messages.map(message => <ChatMessage
                    key={message.id}
                    message={message}
                    isDark={isDark}
                    useTypewriter={useTypewriterEffect}
                    data-message-id={message.id} />)}
                {isProcessing && <div className="flex items-start p-4">
                    <></>
                    <div className="bg-indigo-50 p-4 rounded-lg shadow-sm max-w-3xl">
                        <div className="typing-indicator mt-2">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>}
                <div ref={messagesEndRef} />
            </div>
        );
    };

    useEffect(() => {
        function initVanta() {
            const chatElement = document.getElementById("chat");

            if (chatElement && window.VANTA && window.THREE && !vantaEffect) {
                try {
                    vantaEffect = window.VANTA.NET({
                        el: chatElement,
                        THREE: window.THREE,
                        mouseControls: true,
                        touchControls: true,
                        gyroControls: false,
                        minHeight: 200.00,
                        minWidth: 200.00,
                        color: isDark ? 0xffffff : 0x0f766e,
                        backgroundColor: isDark ? 0x0f172a : 0xffffff,
                        points: 10.0,
                        maxDistance: 22.0,
                        spacing: 18.0
                    });
                } catch (error) {
                    console.warn("Vanta背景效果初始化失败，但不影响应用功能:", error);
                }
            } else if (chatElement && !window.VANTA) {
                console.log("Vanta库尚未加载，跳过背景效果初始化");
            }
        }

        if (document.readyState === "loading") {
            document.addEventListener("DOMContentLoaded", initVanta);
        } else {
            initVanta();
        }

        return () => {
            if (vantaEffect) {
                try {
                    vantaEffect.destroy();
                } catch (error) {
                    console.warn("销毁Vanta效果时出错:", error);
                }

                vantaEffect = null;
            }

            document.removeEventListener("DOMContentLoaded", initVanta);
        };
    }, [isDark]);

    return (
        <div
            className="min-h-screen relative"
            style={{
                background: isDark ? "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)" : "linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)"
            }}>
            <div
                className={`absolute blur-[100px] rounded-full opacity-20 ${isDark ? "bg-purple-700" : "bg-blue-500"}`}
                style={{
                    width: "30rem",
                    height: "30rem",
                    top: "-10rem",
                    left: "-10rem"
                }}></div>
            {}
            <NavigationBar currentPage={window.location.pathname} />
            <div className="container mx-auto px-4 md:px-8 py-4 flex flex-col gap-4">
                {}
                <></>
                <div className="flex flex-col md:flex-row gap-4">
                    {showSidebar && !isMobile && <motion.div
                        style={{
                            width: sidebarWidth
                        }}
                        initial={{
                            x: -sidebarWidth,
                            opacity: 0
                        }}
                        animate={{
                            x: 0,
                            opacity: 1
                        }}
                        exit={{
                            x: -sidebarWidth,
                            opacity: 0
                        }}
                        transition={{
                            type: "spring",
                            stiffness: 300,
                            damping: 30
                        }}>
                        <ChatSidebar
                            conversations={conversations}
                            currentConversation={currentConversation}
                            onConversationSelect={selectConversation}
                            onNewConversation={createConversation}
                            isDark={isDark}
                            isMobile={false}
                            onClose={() => setShowSidebar(false)}
                            onDeleteConversation={deleteConversation}
                            firstQuestion={messages.length > 0 && messages[0].sender === "user" ? messages[0].content.substring(0, 30) : undefined} />
                    </motion.div>}
                    <div className="flex-1">
                        <div
                            id="chat"
                            className={`glassmorphism p-4 mb-4 flex flex-col ${currentModel === "deepseek-reasoner" ? "thinking-mode-border" : ""} chat-module-border`}
                            style={{
                                margin: "0px",
                                height: "calc(100vh - 150px)",
                                background: "transparent",
                                backdropFilter: "blur(20px)",
                                border: currentModel === "deepseek-reasoner" ? `2px solid ${isDark ? "#8b5cf6" : "#8b5cf6"}` : isDark ? "1px solid rgba(99, 102, 241, 0.2)" : "1px solid rgba(255, 255, 255, 0.4)",
                                boxShadow: currentModel === "deepseek-reasoner" ? `0 0 20px ${isDark ? "rgba(139, 92, 246, 0.3)" : "rgba(139, 92, 246, 0.2)"}` : "rgba(0, 0, 0, 0.15) 0px 0px 30px 0px",
                                borderWidth: "0px",
                                borderColor: "#0A0A0A",
                                position: "relative",
                                overflow: "hidden",
                                backgroundColor: "transparent"
                            }}>
                            <div
                                className="flex-1 overflow-y-auto p-4 shadow-inner backdrop-blur-sm"
                                id="chat-messages"
                                style={{
                                    maxHeight: "calc(100vh - 200px)",
                                    scrollbarWidth: "thin",
                                    scrollbarColor: "rgba(156, 163, 175, 0.5) transparent",
                                    background: isDark ? "rgba(15, 23, 42, 0.5)" : "rgba(255, 255, 255, 0.6)",
                                    boxShadow: "rgba(0, 0, 0, 0.15) 0px 0px 30px 0px inset",
                                    borderRadius: "16px",
                                    border: isDark ? "1px solid rgba(99, 102, 241, 0.2)" : "1px solid rgba(255, 255, 255, 0.4)",
                                    backdropFilter: "blur(10px)",
                                    WebkitBackdropFilter: "blur(10px)",
                                    borderColor: "#D6DAE4",
                                    borderWidth: "1px"
                                }}>
                                {renderChatContent()}
                            </div>
                            {currentConversation && <ChatInput
                                inputValue={inputValue}
                                setInputValue={setInputValue}
                                handleSendMessage={handleSendMessage}
                                handleKeyPress={handleKeyPress}
                                isDark={isDark}
                                onFileUpload={handleFileUpload}
                                isUploading={isUploading}
                                isDeepThinking={isDeepThinking}
                                setIsDeepThinking={setIsDeepThinking}
                                formatAsJson={formatAsJson}
                                setFormatAsJson={setFormatAsJson}
                                onSearch={handleSearch}
                                onImageUrlSubmit={handleImageUrlSubmit}
                                onGenerateImage={handleGenerateImage}
                                onInputModeChange={setCurrentInputMode}
                                currentInputMode={currentInputMode}
                                onAudioTranscribe={handleAudioTranscribe}
                                uploadedImages={uploadedImages}
                                useTypewriterEffect={useTypewriterEffect}
                                setUseTypewriterEffect={setUseTypewriterEffect} />}
                        </div>
                    </div>
                    {}
                    {!isMobile && <motion.div
                        style={{
                            width: sidebarWidth
                        }}
                        initial={{
                            x: sidebarWidth,
                            opacity: 0
                        }}
                        animate={{
                            x: 0,
                            opacity: 1
                        }}
                        exit={{
                            x: sidebarWidth,
                            opacity: 0
                        }}
                        transition={{
                            type: "spring",
                            stiffness: 300,
                            damping: 30
                        }}>
                        <div
                            className="flex flex-col glassmorphism p-4"
                            style={{
                                borderRadius: "16px",
                                backgroundColor: isDark ? "rgba(15, 23, 42, 0.7)" : "rgba(255, 255, 255, 0.7)",
                                backdropFilter: "blur(20px)",
                                border: "1px solid rgba(255, 255, 255, 0.3)",
                                boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.15)",
                                height: "calc(100vh - 150px)",
                                minHeight: "600px"
                            }}>
                            <div className="h-full flex flex-col gap-4">
                                {}
                                <div className="overflow-hidden flex flex-col">
                                    <></>
                                </div>
                                {}
                                <div
                                    className="flex-1 overflow-hidden flex flex-col"
                                    style={{
                                        borderRadius: "16px"
                                    }}>
                                    <div
                                        className={`bg-gradient-to-br from-white/80 to-purple-50/80 text-gray-800 rounded-lg overflow-hidden flex flex-col h-full border border-purple-100 shadow-lg relative group glassmorphism-animation`}
                                        style={{
                                            backgroundSize: "200% 200%",
                                            transition: "all 0.5s ease",
                                            boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.15)",
                                            backdropFilter: "blur(8px)",
                                            WebkitBackdropFilter: "blur(8px)",
                                            borderWidth: "1px",
                                            borderColor: "rgba(255, 255, 255, 0.3)",
                                            overflow: "hidden",
                                            borderRadius: "16px"
                                        }}
                                        onMouseEnter={e => {
                                            e.currentTarget.style.backgroundPosition = "100% 100%";
                                            e.currentTarget.style.transform = "translateY(-5px)";
                                            e.currentTarget.style.boxShadow = "0 15px 30px 0 rgba(139, 92, 246, 0.2)";
                                        }}
                                        onMouseLeave={e => {
                                            e.currentTarget.style.backgroundPosition = "0% 0%";
                                            e.currentTarget.style.transform = "translateY(0)";
                                            e.currentTarget.style.boxShadow = "0 8px 32px 0 rgba(31, 38, 135, 0.15)";
                                        }}>
                                        <div
                                            className="px-4 py-2 bg-gradient-to-r from-purple-100 to-purple-200 text-xs font-medium text-purple-800 flex items-center justify-between"
                                            style={{
                                                backgroundColor: "transparent",
                                                backgroundImage: "none",
                                                boxShadow: "none"
                                            }}>
                                             <div className="relative w-full">
                                                <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 z-10"></i>
                                                <input
                                                    type="text"
                                                    placeholder="搜索历史消息..."
                                                    className="w-full pl-9 pr-3 py-1.5 rounded-lg text-sm bg-gray-100/70 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500/30 transition-all duration-300"
                                                    onChange={(e) => setMessageSearchQuery(e.target.value)}
                                                    value={messageSearchQuery} />
                                             </div>
                                        </div>
                                        <div
                                            className="flex-1 p-4 overflow-auto font-sans text-sm"
                                            style={{
                                                boxShadow: "rgba(0, 0, 0, 0.15) 0px 2px 6px 0px",
                                                padding: "0px",
                                                backgroundColor: "transparent",
                                                borderRadius: "16px",
                                                borderColor: "#D6DAE4",
                                                borderWidth: "1px",
                                                scrollbarWidth: "none",
                                                "-ms-overflow-style": "none"
                                            }}>
                                            {}
                                            <style jsx>{`
                                              &::-webkit-scrollbar {
                                                display: none;
                                              }
                                            `}</style>
                                            {messages.length > 0 ? <div className="space-y-3">
                       {}
                        {[...messages]
                          .reverse()
                          .filter(message => !messageSearchQuery || 
                              message.content.toLowerCase().includes(messageSearchQuery.toLowerCase()))
                          .map((message, index) => <motion.div
                                                    key={message.id}
                                                    className={`p-3 rounded-lg transition-all duration-300 hover:shadow-md cursor-pointer ${message.sender === "user" ? "bg-gradient-to-r from-indigo-50 to-purple-50" : "bg-gradient-to-r from-purple-50 to-pink-50"}`}
                                                    whileHover={{
                                                        scale: 1.01,
                                                        backgroundColor: message.sender === "user" ? "rgba(238, 242, 255, 0.8)" : "rgba(245, 235, 255, 0.8)"
                                                    }}
                                                    whileTap={{
                                                        scale: 0.99
                                                    }}
                                                    onClick={() => {
                                                        const messageElement = document.querySelector(`[data-message-id="${message.id}"]`);

                                                        if (messageElement) {
                                                            messageElement.scrollIntoView({
                                                                behavior: "smooth",
                                                                block: "center"
                                                            });

                                                            messageElement.classList.add("bg-yellow-50", "dark:bg-yellow-900/30");

                                                            setTimeout(() => {
                                                                messageElement.classList.remove("bg-yellow-50", "dark:bg-yellow-900/30");
                                                            }, 2000);
                                                        }
                                                    }}
                                                    title="点击跳转到该消息"
                                                    style={{
                                                        boxShadow: "rgba(0, 0, 0, 0.15) 0px 2px 6px 0px"
                                                    }}>
                                                    <></>
                                                    <p
                                                        className="text-sm text-gray-700 truncate"
                                                        style={{
                                                            fontWeight: "bold",
                                                            fontFamily: "DOUYINSANSBOLD-GB"
                                                        }}>{message.content.length > 100 ? message.content.substring(0, 100) + "..." : message.content}</p>
                                                    <div className="flex justify-between items-center mt-2 opacity-100">
                                                        <span className="text-xs text-purple-500">{new Date(message.timestamp).toLocaleTimeString([], {
                                                            hour: "2-digit",
                                                            minute: "2-digit"
                                                        })}</span>
                                                        <i className="fas fa-arrow-up-right text-purple-500 text-xs"></i>
                                                    </div>
                                                </motion.div>)}
                                            </div> : <div
                                                className="text-gray-500 flex flex-col items-center justify-center h-full text-center">
                                                {messageSearchQuery ? (
                                                    <>
                                                        <i className="fas fa-search text-xl mb-2 text-purple-400"></i>
                                                        <div className="text-purple-800 font-medium mb-1" style={{fontWeight: "bold"}}>
                                                            未找到匹配的消息
                                                        </div>
                                                        <p className="text-sm text-gray-500">
                                                            尝试使用不同的关键词搜索
                                                        </p>
                                                    </>
                                                ) : (
                                                    <>
                                                        <i className="fas fa-comments text-xl mb-2 text-purple-400"></i>
                                                        <div
                                                            className="text-purple-800 font-medium"
                                                            style={{
                                                        fontWeight: "bold"
                                                    }}>暂无对话历史</div>
                                                    </>
                                                )}
                                            </div>}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </motion.div>}
                </div>
                {isMobile && showSidebar && <div
                    className="fixed inset-0 backdrop-blur-md bg-black/30 z-40"
                    onClick={() => setShowSidebar(false)}>
                    <div className="h-full w-[85%]">
                        <ChatSidebar
                            conversations={conversations}
                            currentConversation={currentConversation}
                            onConversationSelect={selectConversation}
                            onNewConversation={createConversation}
                            isDark={isDark}
                            isMobile={true}
                            onClose={() => setShowSidebar(false)}
                            onDeleteConversation={deleteConversation}
                            firstQuestion={messages.length > 0 && messages[0].sender === "user" ? messages[0].content.substring(0, 30) : undefined} />
                    </div>
                </div>}
                {showSearchResults && <SearchResults
                    results={searchResults}
                    isDark={isDark}
                    onClose={() => setShowSearchResults(false)}
                    isSearching={isSearching} />}
                <div className="flex justify-center mb-4">
                    <></>
                </div>
            </div>
        </div>
    );
};

export default Home;