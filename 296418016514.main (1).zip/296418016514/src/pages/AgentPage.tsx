import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";

const AgentPage: React.FC = () => {
  const { isDark } = useTheme();
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/q/agent" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col items-center justify-center px-4 py-12">
        <motion.div
          className="max-w-5xl mx-auto text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* 页面标题 */}
          <motion.div 
            className="mb-16"
            variants={itemVariants}
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white mb-6">
              <i className="fas fa-robot text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">智能交易代理</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              7×24小时监控市场，自动执行交易策略，智能风险管理
            </p>
          </motion.div>
          
          {/* 代理能力 */}
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
            variants={containerVariants}
          >
            {[
              {
                title: "自动交易执行",
                description: "根据预设策略自动执行买卖指令，减少人工干预和情绪影响",
                icon: "autoprefixer"
              },
              {
                title: "市场监控",
                description: "7×24小时监控全球金融市场，及时捕捉投资机会和风险预警",
                icon: "globe"
              },
              {
                title: "风险控制",
                description: "实时监控投资组合风险指标，自动触发止损和风险对冲措施",
                icon: "lock"
              },
              {
                title: "自适应学习",
                description: "通过强化学习不断优化交易决策，适应市场环境变化",
                icon: "chart-line"
              }
            ].map((capability, index) => (
              <motion.div
                key={index}
                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                variants={itemVariants}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(79, 70, 229, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center mb-4 text-white">
                  <i className={`fas fa-${capability.icon} text-xl`}></i>
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">{capability.title}</h3>
                <p className="text-gray-300">{capability.description}</p>
              </motion.div>
            ))}
          </motion.div>
          
          {/* 行动按钮 */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            variants={itemVariants}
          >
            <motion.button
              className="px-8 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium text-lg flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-play"></i>
              部署智能代理
            </motion.button>
            
            <motion.button
              className="px-8 py-3 rounded-lg bg-white/10 border border-white/20 text-white font-medium text-lg flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, backgroundColor: "rgba(255, 255, 255, 0.15)" }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-cog"></i>
              代理设置
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
      
      {/* 返回按钮 */}
      <div className="p-6 relative z-10">
        <Link to="/q" className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors">
          <i className="fas fa-arrow-left"></i>
          <span>返回COREX Q主页</span>
        </Link>
      </div>
      
      {/* 页脚 */}
       <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | COREX Q</p>
      </footer>
    </div>
  );
};

export default AgentPage;