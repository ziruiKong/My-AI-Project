import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";

const StrategyPage: React.FC = () => {
  const { isDark } = useTheme();
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  // 策略库数据
  const strategies = [
    {
      id: "prism-1-ufrm",
      name: "Prism.1-UFRM",
      description: "普适性量化交易策略，融合AI Alpha与风险管理",
      performance: "年化收益 16.5%",
      risk: "最大回撤 26.6%",
      category: "量化策略",
      color: "from-indigo-500 to-purple-600",
      icon: "chart-line"
    },
    {
      id: "momentum-50",
      name: "Momentum-50",
      description: "基于动量因子的高频交易策略",
      performance: "年化收益 22.3%",
      risk: "最大回撤 32.1%",
      category: "高频策略",
      color: "from-green-500 to-teal-600",
      icon: "bolt"
    },
    {
      id: "value-invest",
      name: "Value-Invest",
      description: "结合价值投资理念的中长期量化策略",
      performance: "年化收益 14.8%",
      risk: "最大回撤 18.2%",
      category: "价值策略",
      color: "from-amber-500 to-orange-600",
      icon: "chart-pie"
    },
    {
      id: "risk-parity",
      name: "Risk-Parity",
      description: "基于风险平价的资产配置策略",
      performance: "年化收益 12.5%",
      risk: "最大回撤 14.7%",
      category: "配置策略",
      color: "from-blue-500 to-indigo-600",
      icon: "shield-alt"
    }
  ];
  
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/q/strategy" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-12">
        <motion.div
          className="max-w-6xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* 页面标题 */}
          <motion.div 
            className="mb-16 text-center"
            variants={itemVariants}
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-chess text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">策略库</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              探索COREX Q旗下的量化投资策略，为您的投资决策提供专业支持
            </p>
          </motion.div>
          
          {/* 策略库列表 */}
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
            variants={containerVariants}
          >
            {strategies.map((strategy, index) => (
              <motion.div
                key={strategy.id}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
                variants={itemVariants}
              >
                <Link 
                  to={strategy.id === "prism-1-ufrm" 
                    ? `${window.location.pathname.includes('/runtime') ? "/runtime/q/quant-strategy" : "/q/quant-strategy"}` 
                    : `#${strategy.id}`}
                  className="block p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg transition-all duration-300"
                  style={{ textDecoration: 'none' }}
                >
                  <div className="flex justify-between items-start">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${strategy.color} flex items-center justify-center mb-4 text-white`}>
                      <i className={`fas fa-${strategy.icon} text-xl`}></i>
                    </div>
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-gray-300">
                      {strategy.category}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-white">{strategy.name}</h3>
                  <p className="text-gray-300 mb-4">{strategy.description}</p>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-xs text-gray-400">年化收益</p>
                      <p className="font-semibold text-white">{strategy.performance}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">最大回撤</p>
                      <p className="font-semibold text-white">{strategy.risk}</p>
                    </div>
                    <motion.div
                      whileHover={{ x: 5 }}
                      className="flex items-center text-indigo-400"
                    >
                      <span className="mr-1">查看详情</span>
                      <i className="fas fa-arrow-right text-sm"></i>
                    </motion.div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
      
      {/* 返回按钮 */}
      <div className="p-6 relative z-10">
        <Link to="/q" className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors">
          <i className="fas fa-arrow-left"></i>
          <span>返回COREX Q主页</span>
        </Link>
      </div>
      
      {/* 页脚 */}
       <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | COREX Q</p>
      </footer>
    </div>
  );
};

export default StrategyPage;