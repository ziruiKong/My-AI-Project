import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useGREQuestions } from "../hooks/useStorage";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { GREQuestion, GREQuestionOption } from "../lib/StorageService";

const GREQuestionEditorPage: React.FC = () => {
  const { isDark } = useTheme();
  const { addGREQuestion, updateGREQuestion, getGREQuestionById } = useGREQuestions();
  const navigate = useNavigate();
  const { id } = useParams();
  
  const [questionType, setQuestionType] = useState<'multiple_choice' | 'reading_comprehension'>('multiple_choice');
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [content, setContent] = useState('');
  const [passage, setPassage] = useState('');
  const [explanation, setExplanation] = useState('');
  const [tags, setTags] = useState('');
  const [options, setOptions] = useState<GREQuestionOption[]>([
    { id: 'a', text: '', isCorrect: false },
    { id: 'b', text: '', isCorrect: false },
    { id: 'c', text: '', isCorrect: false },
    { id: 'd', text: '', isCorrect: false }
  ]);
  const [isEditing, setIsEditing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // 如果是编辑模式，加载现有题目数据
  useEffect(() => {
    if (id) {
      const loadQuestion = async () => {
        try {
          setIsEditing(true);
          const question = await getGREQuestionById(id);
          if (question) {
            setQuestionType(question.type);
            setDifficulty(question.difficulty);
            setContent(question.content);
            setPassage(question.passage || '');
            setExplanation(question.explanation || '');
            setTags(question.tags?.join(', ') || '');
            setOptions(question.options || [
              { id: 'a', text: '', isCorrect: false },
              { id: 'b', text: '', isCorrect: false },
              { id: 'c', text: '', isCorrect: false },
              { id: 'd', text: '', isCorrect: false }
            ]);
          } else {
            toast.error("未找到题目");
            navigate('/gre-question-bank');
          }
        } catch (error) {
          console.error('加载题目失败:', error);
          toast.error("加载题目失败");
          navigate('/gre-question-bank');
        }
      };
      
      loadQuestion();
    }
  }, [id, getGREQuestionById, navigate]);
  
  // 处理选项文本变化
  const handleOptionTextChange = (index: number, text: string) => {
    const newOptions = [...options];
    newOptions[index].text = text;
    setOptions(newOptions);
  };
  
  // 处理正确选项变化
  const handleCorrectOptionChange = (index: number) => {
    const newOptions = [...options];
    // 单选，所以先取消所有正确选项
    newOptions.forEach(option => {
      option.isCorrect = false;
    });
    newOptions[index].isCorrect = true;
    setOptions(newOptions);
  };
  
  // 添加新选项
  const handleAddOption = () => {
    const newId = String.fromCharCode(97 + options.length); // a, b, c, d...
    setOptions([...options, { id: newId, text: '', isCorrect: false }]);
  };
  
  // 移除选项
  const handleRemoveOption = (index: number) => {
    if (options.length > 2) {
      const newOptions = [...options];
      newOptions.splice(index, 1);
      setOptions(newOptions);
    } else {
      toast.warning("至少需要保留2个选项");
    }
  };
  
  // 处理表单提交
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 验证表单
    if (!content.trim()) {
      toast.warning("请输入题目内容");
      return;
    }
    
    if (questionType === 'multiple_choice') {
      // 验证选择题选项
      const hasEmptyOption = options.some(option => !option.text.trim());
      if (hasEmptyOption) {
        toast.warning("请填写所有选项");
        return;
      }
      
      const hasCorrectOption = options.some(option => option.isCorrect);
      if (!hasCorrectOption) {
        toast.warning("请选择正确选项");
        return;
      }
    }
    
    setIsSubmitting(true);
    
    try {
      // 处理标签
      const tagsArray = tags.split(',').map(tag => tag.trim()).filter(tag => tag);
      
      const questionData: Omit<GREQuestion, 'id' | 'createDate'> = {
        type: questionType,
        difficulty,
        content,
        options: questionType === 'multiple_choice' ? options : undefined,
        correctAnswer: questionType === 'multiple_choice' ? options.find(o => o.isCorrect)?.id : undefined,
        explanation,
        passage: questionType === 'reading_comprehension' ? passage : undefined,
        tags: tagsArray.length > 0 ? tagsArray : undefined
      };
      
      if (isEditing && id) {
        // 更新现有题目
        const success = await updateGREQuestion(id, questionData);
        if (success) {
          toast.success("题目更新成功");
          navigate('/gre-question-bank');
        } else {
          toast.error("题目更新失败");
        }
      } else {
        // 添加新题目
        await addGREQuestion(questionData);
        toast.success("题目添加成功");
        navigate('/gre-question-bank');
      }
    } catch (error) {
      console.error('保存题目失败:', error);
      toast.error("保存题目失败，请稍后再试");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // 处理取消
  const handleCancel = () => {
    if (window.confirm("确定要放弃编辑吗？未保存的更改将会丢失。")) {
      navigate('/gre-question-bank');
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/gre-question-bank" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-8">
        <motion.div
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* 页面标题 */}
          <div className="mb-8 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-pencil-alt text-3xl"></i>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4 text-white">
              {isEditing ? "编辑GRE题目" : "添加GRE题目"}
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              {isEditing ? "修改现有题目的内容和设置" : "创建新的GRE考试题目"}
            </p>
          </div>
          
          {/* 表单 */}
          <motion.div
            className="rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg p-6 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <form onSubmit={handleSubmit}>
              {/* 题目类型 */}
              <div className="mb-6">
                <label className="block text-gray-300 mb-2 font-medium">题目类型</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="questionType"
                      value="multiple_choice"
                      checked={questionType === 'multiple_choice'}
                      onChange={() => setQuestionType('multiple_choice')}
                      className="text-indigo-500 focus:ring-indigo-500"
                    />
                    <span>选择题</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="questionType"
                      value="reading_comprehension"
                      checked={questionType === 'reading_comprehension'}
                      onChange={() => setQuestionType('reading_comprehension')}
                      className="text-indigo-500 focus:ring-indigo-500"
                    />
                    <span>阅读题</span>
                  </label>
                </div>
              </div>
              
              {/* 难度 */}
              <div className="mb-6">
                <label className="block text-gray-300 mb-2 font-medium">难度</label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as any)}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="easy">简单</option>
                  <option value="medium">中等</option>
                  <option value="hard">困难</option>
                </select>
              </div>
              
              {/* 阅读文章（仅阅读题显示） */}
              {questionType === 'reading_comprehension' && (
                <div className="mb-6">
                  <label className="block text-gray-300 mb-2 font-medium">阅读文章</label>
                  <textarea
                    value={passage}
                    onChange={(e) => setPassage(e.target.value)}
                    placeholder="输入阅读文章内容..."
                    className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[150px]"
                  />
                </div>
              )}
              
              {/* 题目内容 */}
              <div className="mb-6">
                <label className="block text-gray-300 mb-2 font-medium">题目内容</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="输入题目内容..."
                  className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                  required
                />
              </div>
              
              {/* 选项（仅选择题显示） */}
              {questionType === 'multiple_choice' && (
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <label className="block text-gray-300 font-medium">选项</label>
                    <motion.button
                      type="button"
                      onClick={handleAddOption}
                      className="px-3 py-1 text-sm rounded-lg bg-indigo-600/30 text-indigo-300 hover:bg-indigo-600/50 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <i className="fas fa-plus mr-1"></i> 添加选项
                    </motion.button>
                  </div>
                  
                  <div className="space-y-3">
                    {options.map((option, index) => (
                      <div key={option.id} className="flex items-center gap-3">
                        <div className="relative">
                          <input
                            type="radio"
                            name="correctOption"
                            checked={option.isCorrect}
                            onChange={() => handleCorrectOptionChange(index)}
                            className="w-5 h-5 text-indigo-500 focus:ring-indigo-500"
                          />
                          <span className="absolute -left-8 top-1/2 transform -translate-y-1/2 text-gray-400">
                            {option.id.toUpperCase()}
                          </span>
                        </div>
                        <div className="flex-grow">
                          <input
                            type="text"
                            value={option.text}
                            onChange={(e) => handleOptionTextChange(index, e.target.value)}
                            placeholder={`选项 ${option.id.toUpperCase()}`}
                            className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            required
                          />
                        </div>
                        {options.length > 2 && (
                          <motion.button
                            type="button"
                            onClick={() => handleRemoveOption(index)}
                            className="w-8 h-8 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center hover:bg-red-600/40 transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                          >
                            <i className="fas fa-times"></i>
                          </motion.button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* 解析 */}
              <div className="mb-6">
                <label className="block text-gray-300 mb-2 font-medium">解析</label>
                <textarea
                  value={explanation}
                  onChange={(e) => setExplanation(e.target.value)}
                  placeholder="输入题目解析..."
                  className="w-full px-4 py-3 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[100px]"
                />
              </div>
              
              {/* 标签 */}
              <div className="mb-8">
                <label className="block text-gray-300 mb-2 font-medium">标签</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="输入标签，用逗号分隔（如：vocabulary, sentence_completion）"
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <p className="text-gray-400 text-sm mt-1">标签用于分类和搜索题目</p>
              </div>
              
              {/* 操作按钮 */}
              <div className="flex flex-wrap justify-center gap-4">
                <motion.button
                  type="button"
                  onClick={handleCancel}
                  className="px-6 py-3 rounded-lg bg-white/10 border border-white/20 text-white font-medium flex items-center justify-center gap-2"
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  disabled={isSubmitting}
                >
                  <i className="fas fa-times"></i>
                  取消
                </motion.button>
                
                <motion.button
                  type="submit"
                  className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium flex items-center justify-center gap-2"
                  whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
                  whileTap={{ scale: 0.97 }}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <i className="fas fa-spinner fa-spin"></i>
                      保存中...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save"></i>
                      {isEditing ? "更新题目" : "保存题目"}
                    </>
                  )}
                </motion.button>
              </div>
            </form>
          </motion.div>
          
          {/* 返回按钮 */}
          <div className="mt-8 p-4 text-center">
            <Link 
              to="/gre-question-bank" 
              className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <i className="fas fa-arrow-left"></i>
              <span>返回题库</span>
            </Link>
          </div>
        </motion.div>
      </div>
      
      {/* 页脚 */}
      <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | GRE题库系统</p>
      </footer>
    </div>
  );
};

export default GREQuestionEditorPage;