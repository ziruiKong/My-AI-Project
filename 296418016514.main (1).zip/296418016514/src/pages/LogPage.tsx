import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";

// 定义日志条目类型
interface LogEntry {
  id: string;
  date: string;
  title: string;
  description: string;
  category: "feature" | "bugfix" | "refactor" | "update";
  details: string;
  codeSnippet?: string;
  filesChanged?: string[];
}

const LogPage: React.FC = () => {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [expandedEntry, setExpandedEntry] = useState<string | null>(null);

   // 整合全部版本历史记录
  const logEntries: LogEntry[] = [
      {
     id: "460",
     date: "2025-09-15",
     title: "为COREX Q页面模块添加点击跳转功能",
     description: "让COREX Q页面的三个模块（策略、研究、智能体）可以点击并跳转到单独页面，增加互动效果",
     category: "feature",
      details: "对COREX Q页面进行了以下增强：1. 将三个静态模块（策略、研究、智能体）转换为可点击的链接；2. 为每个模块添加了指向独立页面的路由（/q/strategy、/q/research、/q/agent）；3. 在每个模块底部添加了'了解更多'文本和箭头动画，增强视觉引导；4. 在App.tsx中添加了新路由配置；5. 添加了whileTap动画效果，提升点击交互体验；6. 保留了原有的毛玻璃质感和视觉效果。",
      codeSnippet: `// 策略模块 - 可点击版本
<motion.a
  href="/q/strategy"
  className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-indigo-500/10 transition-all duration-500"
  variants={{
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.8 } }
  }}
  whileHover={{ 
    y: -5,
    boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
    backdropFilter: "blur(20px)"
  }}
  whileTap={{
    scale: 0.98
  }}
  style={{ textDecoration: 'none' }}
>
  {/* 装饰背景和内容 */}
  <div className="relative z-10">
    <h3 className="text-2xl font-bold mb-3 text-white">策略</h3>
    <p className="text-gray-300">基于深度学习的量化模型，分析海量市场数据，提供精准投资策略</p>
    <div className="mt-6 inline-flex items-center text-indigo-400 font-medium">
      <span>了解更多</span>
      <motion.i 
        className="fas fa-arrow-right ml-2"
        animate={{ x: [0, 5, 0] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
    </div>
  </div>
</motion.a>`,
      filesChanged: ["src/pages/CorexQPage.tsx", "src/App.tsx"]
    },
    {
     id: "461",
     date: "2025-09-15",
     title: "更新所有页面中的品牌名称",
     description: "将所有页面中的'幻万'品牌名称更新为'COREX'",
     category: "update",
      details: "对所有页面中的品牌名称进行了统一更新：1. 将CorexQPage.tsx页脚中的'幻万人工智能'修改为'COREX 人工智能'；2. 将StrategyPage.tsx、ResearchPage.tsx和AgentPage.tsx页脚中的'幻万人工智能 | COREX Q'修改为'COREX 人工智能 | COREX Q'；3. 确保品牌名称在所有页面中保持一致。",
      codeSnippet: `// 页脚品牌名称更新示例
// 修改前
<footer className="py-6 text-center text-gray-500 text-sm mt-auto">
  <p>© 2025 幻万人工智能 | COREX Q</p>
</footer>

// 修改后
<footer className="py-6 text-center text-gray-500 text-sm mt-auto">
  <p>© 2025 COREX 人工智能 | COREX Q</p>
</footer>`,
     filesChanged: ["src/pages/CorexQPage.tsx", "src/pages/StrategyPage.tsx", "src/pages/ResearchPage.tsx", "src/pages/AgentPage.tsx"]
    },
    {
     id: "462",
     date: "2025-09-15",
     title: "修复App.tsx中的组件引用错误",
     description: "修复了App.tsx中未导入QuantStrategyPage组件导致的Lint错误",
     category: "bugfix",
      details: "发现并修复了App.tsx文件中的Lint错误，添加了QuantStrategyPage组件的导入语句，确保路由配置正确引用了该组件。",
      codeSnippet: `// 修复前
// 缺少QuantStrategyPage的导入

// 修复后
import QuantStrategyPage from "@/pages/QuantStrategyPage";

// 路由配置
<Route path="/q/quant-strategy" element={<QuantStrategyPage />} />`,
     filesChanged: ["src/App.tsx"]
    },
    {
     id: "462",
     date: "2025-09-15",
     title: "创建COREX Q量化策略展示页面",
     description: "创建了一个独立的量化策略展示页面，详细介绍COREX Q的量化策略",
     category: "feature",
      details: "创建了QuantStrategyPage.tsx，一个专门用于展示COREX Q量化策略的独立页面。页面包含了以下内容和功能：1. 策略概览介绍，详细说明了策略的原理和优势；2. 历史表现图表，使用recharts库展示了策略的回测数据和对比基准；3. 策略原理部分，解释了深度学习模型、多因子分析和风险管理框架；4. 风险指标展示，包括年化收益率、最大回撤、夏普比率等关键指标；5. 应用配置指南，说明了如何开始使用该策略；6. 页面保持了与COREX Q主页一致的设计风格，包括毛玻璃效果、渐变背景和动画效果；7. 在App.tsx中添加了对应的路由配置；8. 确保了页面的响应式布局，在不同设备上都有良好的显示效果。",
      codeSnippet: `// 量化策略页面的主要结构
const QuantStrategyPage: React.FC = () => {
  const { isDark } = useTheme();
  const [activeSection, setActiveSection] = useState('overview');
  const [isChartVisible, setIsChartVisible] = useState(false);

  // 页面加载动画
  useEffect(() => {
    setIsChartVisible(true);
    
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // 容器和元素动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };`,
      filesChanged: ["src/pages/QuantStrategyPage.tsx", "src/App.tsx"]
    },
    {
     id: "463",
     date: "2025-09-15",
     title: "修复COREX Q页面访问问题",
     description: "添加路由重定向，解决页面打不开的问题",
     category: "bugfix",
      details: "发现并修复了用户无法访问COREX Q页面的问题：1. 用户尝试通过'/runtime/q'路径访问页面，但该路由不存在；2. 在App.tsx中添加了路由配置，将'/runtime/q'重定向到正确的'/q'页面；3. 确保了COREX Q页面及其所有子页面能够正常访问；4. 此修复确保用户无论输入'/q'还是'/runtime/q'都能正确访问到COREX Q页面。",
      codeSnippet: `// 修复前 - 只有/q路由
<Route path="/q" element={<CorexQPage />} />

// 修复后 - 添加了重定向支持
<Route path="/q" element={<CorexQPage />} />
{/* 重定向 /runtime/q 到 /q */}
<Route path="/runtime/q" element={<CorexQPage />} />`,
      filesChanged: ["src/App.tsx"]
    },
    {
     id: "464",
     date: "2025-09-15",
     title: "创建缺失的ResearchPage组件",
     description: "修复代码中找不到ResearchPage文件的错误",
     category: "bugfix",
      details: "发现并修复了App.tsx中导入不存在组件的错误：1. 系统报错找不到/src/pages/ResearchPage文件，但App.tsx中尝试导入并使用了这个组件；2. 创建了完整的ResearchPage.tsx组件，包含了与其他COREX Q相关页面一致的设计风格和功能；3. 确保了组件的路由配置正确，可以正常访问；4. 修复后，COREX Q页面的研究模块可以正确跳转到研究页面。",
      codeSnippet: `// ResearchPage.tsx 组件的基本结构
import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";

const ResearchPage: React.FC = () => {
  const { isDark } = useTheme();
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };`,
      filesChanged: ["src/pages/ResearchPage.tsx"]
    },
    {
     id: "465",
     date: "2025-09-15",
     title: "修复COREX Q页面访问路径问题",
     description: "全面修复COREX Q页面及子页面的访问路径问题，确保在不同路径下都能正常访问",
     category: "bugfix",
      details: "发现并解决了COREX Q页面访问问题的根本原因：1. 系统存在两种访问路径结构('/q'和'/runtime/q')，但子页面路由只配置了一种路径；2. 在App.tsx中添加了所有COREX Q子页面在'/runtime/q'路径下的路由配置；3. 修改了CorexQPage.tsx中的链接，使其根据当前访问路径自动选择正确的链接格式；4. 修复了NavigationBar.tsx中的COREX Q链接，确保导航也能正确指向当前路径结构；5. 这些修改确保用户无论通过哪种路径访问，都能正常浏览所有COREX Q相关页面。",
      codeSnippet: `// 修复前 - 只支持一种路径结构
<Route path="/q/strategy" element={<StrategyPage />} />
<Route path="/q/research" element={<ResearchPage />} />

// 修复后 - 支持两种路径结构
<Route path="/q/strategy" element={<StrategyPage />} />
<Route path="/runtime/q/strategy" element={<StrategyPage />} />
<Route path="/q/research" element={<ResearchPage />} />
<Route path="/runtime/q/research" element={<ResearchPage />} />

// 智能链接生成
const currentBasePath = window.location.pathname.includes('/runtime') ? "/runtime/q" : "/q";
<a href={\`\${currentBasePath}/strategy\`}>策略</a>`,
      filesChanged: ["src/App.tsx", "src/pages/CorexQPage.tsx", "src/components/NavigationBar.tsx"]
    },
    {
     id: "466",
     date: "2025-09-15",
     title: "为COREX Q量化策略页面添加图表展示",
     description: "根据学术文章内容，为量化策略页面添加了多个数据可视化图表",
     category: "feature",
      details: "基于提供的COREX Q量化交易策略学术文章，为QuantStrategyPage.tsx页面添加了多个数据可视化图表，包括：1. 策略净值曲线对比图，展示COREX Q策略与基线策略的净值走势；2. 最大回撤曲线图，展示两种策略的回撤表现差异；3. 因子收益拆解图，分解Alpha组件和风险对冲组件的贡献；4. 跨资产表现柱状图，展示策略在不同资产类别上的表现；5. 压力指标变化图，展示市场压力指标p_stress的变化趋势；6. 因子暴露控制图表，展示策略对各风险因子的暴露控制情况。这些图表使策略的原理和表现更加直观，帮助用户更好地理解COREX Q策略的优势和特点。",
      codeSnippet: `// 净值曲线对比图示例
<LineChart data={equityCurveData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
  <XAxis dataKey="day" stroke="#94a3b8" />
  <YAxis stroke="#94a3b8" domain={[0.9, 2.0]} />
  <Tooltip 
    contentStyle={{ 
      backgroundColor: 'rgba(15, 23, 42, 0.9)', 
      borderColor: '#475569',
      borderRadius: '8px',
      color: '#f1f5f9'
    }}
  />
  <Line 
    type="monotone" 
    dataKey="corexq" 
    stroke="#8b5cf6" 
    strokeWidth={3} 
    dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4, fill: '#0f172a' }}
    activeDot={{ r: 8, stroke: '#8b5cf6', strokeWidth: 2, fill: '#c4b5fd' }}
    name="COREX Q策略（融合风险）"
  />
  <Line 
    type="monotone" 
    dataKey="baseline" 
    stroke="#64748b" 
    strokeWidth={3}
    dot={{ stroke: '#64748b', strokeWidth: 2, r: 4, fill: '#0f172a' }}
    name="基线策略（无风险控制）"
  />
</LineChart>`,
      filesChanged: ["src/pages/QuantStrategyPage.tsx"]
    },
    {
     id: "468",
     date: "2025-09-15",
     title: "修复PrismCorexStrategy.ts中的Lint错误",
     description: "修复了PrismCorexStrategy.ts文件中未定义的类名错误",
     category: "bugfix",
      details: "发现并修复了PrismCorexStrategy.ts文件中的Lint错误：1. 系统报错显示'PrismCorexQStrategy'未定义；2. 检查发现文件中定义的类名是'PrismCorexStrategy'，但在Hook实现中错误地引用了'PrismCorexQStrategy'；3. 修复了Hook实现中的类名引用，将其改为正确的'PrismCorexStrategy'；4. 同时创建了完整的PrismCorexStrategy.ts文件，实现了COREX Q策略与Prism.1-UFRM框架的集成；5. 添加了策略参数定义、生命周期管理、核心逻辑实现和React Hook支持等功能；6. 确保了代码的类型安全性和可维护性。",
      codeSnippet: `// 修复前
const initStrategy = async () => {
  const newStrategy = new PrismCorexQStrategy(params);
  const success = await newStrategy.initialize();
}

// 修复后
const initStrategy = async () => {
  const newStrategy = new PrismCorexStrategy(params);
  const success = await newStrategy.initialize();
}`,
     filesChanged: ["src/lib/PrismCorexStrategy.ts"]
    },
    {
     id: "467",
     date: "2025-09-15",
     title: "创建Prism.1-UFRM框架下的COREX Q策略集成模块",
     description: "将COREX Q策略集成到Prism.1-UFRM框架中，提供完整的策略生命周期管理",
     category: "feature",
      details: "创建了PrismCorexStrategy.ts文件，实现了COREX Q策略与Prism.1-UFRM框架的集成。该模块提供了以下功能：1. 完整的策略参数定义，包括基础参数、模型参数、资产配置参数和风控参数等；2. 策略生命周期管理，包括初始化、启动、暂停和停止等操作；3. 策略核心逻辑实现，包括市场数据获取、Alpha信号生成、风险计算与控制、交易指令生成与执行等；4. React Hook支持，方便在React组件中使用该策略；5. 详细的类型定义和文档注释，确保代码的可维护性和可读性。该模块可以作为COREX Q策略在Prism.1-UFRM框架下的标准实现，支持各种配置和扩展。",
      codeSnippet: `// PrismCorexStrategy类的主要结构
export class PrismCorexStrategy {
  private params: CorexQStrategyParams;
  private status: StrategyStatus = 'idle';
  private results: CorexQStrategyResult[] = [];
  private initialized: boolean = false;
  private runningInterval: ReturnType<typeof setInterval> | null = null;

  // 构造函数
  constructor(params: Partial<CorexQStrategyParams> = {}) {
    // 合并默认参数和用户提供的参数
    this.params = {
      ...DEFAULT_COREXQ_PARAMS,
      ...params,
      assetAllocation: {
        ...DEFAULT_COREXQ_PARAMS.assetAllocation,
        ...(params.assetAllocation || {})
      },
      positionLimits: {
        ...DEFAULT_COREXQ_PARAMS.positionLimits,
        ...(params.positionLimits || {})
      }
    };
  }

  // 策略初始化
  public async initialize(): Promise<boolean> {
    // 初始化逻辑...
  }

  // 启动策略
  public async start(): Promise<boolean> {
    // 启动逻辑...
  }
}

// React Hook支持
export const usePrismCorexStrategy = (params: Partial<CorexQStrategyParams> = {}) => {
  // Hook实现...
}`,
      filesChanged: ["src/lib/PrismCorexStrategy.ts"]
    },
    {
     id: "469",
     date: "2025-09-15",
     title: "重构策略库页面，添加Prism.1-UFRM策略展示",
     description: "将StrategyPage重构为策略库页面，展示COREX Q旗下的多种策略，包括Prism.1-UFRM",
     category: "feature",
      details: "对StrategyPage.tsx进行了全面重构，将其转变为策略库页面，实现了以下功能：1. 创建了策略卡片列表，展示COREX Q旗下的多种策略，包括Prism.1-UFRM；2. 为每个策略卡片添加了详细信息，如名称、描述、年化收益和最大回撤等；3. 为Prism.1-UFRM策略设置了正确的链接，点击后跳转到QuantStrategyPage查看详细信息；4. 保留了原有的视觉风格，包括毛玻璃效果、渐变背景和动画效果；5. 更新了QuantStrategyPage的标题，明确标识为Prism.1-UFRM策略详情页面；6. 确保了页面的响应式布局，在不同设备上都有良好的显示效果。",
      codeSnippet: `// 策略库页面的主要结构
// 策略数据
const strategies = [
  {
    id: "prism-1-ufrm",
    name: "Prism.1-UFRM",
    description: "普适性量化交易策略，融合AI Alpha与风险管理",
    performance: "年化收益 16.5%",
    risk: "最大回撤 26.6%",
    category: "量化策略",
    color: "from-indigo-500 to-purple-600",
    icon: "chart-line"
  },
  // 其他策略...
];

// 策略卡片渲染
{strategies.map((strategy, index) => (
  <motion.div key={strategy.id}>
    <Link 
      to={strategy.id === "prism-1-ufrm" 
        ? "/q/quant-strategy" 
        : \`#\${strategy.id}\`}
      className="block p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
    >
      {/* 卡片内容 */}
    </Link>
  </motion.div>
))}`,
      filesChanged: ["src/pages/StrategyPage.tsx", "src/pages/QuantStrategyPage.tsx"]
    },
    {
     id: "470",
     date: "2025-09-15",
     title: "再次调整COREX文本框长度",
     description: "增加COREX Q主页上COREX文本框的宽度，使其更长",
     category: "update",
      details: "根据用户需求，再次调整了CorexQPage.tsx页面中COREX文本框的样式，将宽度从120px增加到200px，使其变得更长。这样可以使文本框在页面上更加醒目，提升品牌展示效果。",
      codeSnippet: `// 调整前
<span
  className="text-indigo-900 font-bold text-xl"
  style={{
    fontSize: "24px",
    fontFamily: "DOUYINSANSBOLD-GB",
    fontWeight: "bold",
    color: "#FFFFFF",
    width: "120px",
    height: "40px",
    display: "inline-block"
  }}>COREX </span>

// 调整后
<span
  className="text-indigo-900 font-bold text-xl"
  style={{
    fontSize: "24px",
    fontFamily: "DOUYINSANSBOLD-GB",
    fontWeight: "bold",
    color: "#FFFFFF",
    width: "200px",
    height: "40px",
    display: "inline-block"
  }}>COREX </span>`,
      filesChanged: ["src/pages/CorexQPage.tsx"]
    },
    {
     id: "473",
     date: "2025-09-15",
     title: "创建量化策略主页",
     description: "基于COREX Q设计风格，创建一个新的量化策略主页，展示各类投资策略",
     category: "feature",
      details: "创建了新的QuantStrategyHomePage.tsx组件，基于用户提供的图片和COREX Q的设计风格实现了一个美观的量化策略主页：1. 设计了包含五种主要策略类型的网格布局（指数增强策略、CTA策略、量化对冲策略、量化多空策略和股票优选策略）；2. 每个策略使用卡片式设计，包含策略名称、描述、图标和交互元素；3. 添加了与COREX Q一致的视觉风格，包括毛玻璃效果、渐变背景、动画效果和粒子背景；4. 在页面底部展示了策略的三大特色与优势；5. 添加了醒目的行动按钮，引导用户开始使用量化策略；6. 在App.tsx中配置了相应的路由，支持标准路径和runtime路径两种访问方式；7. 确保了页面的响应式布局，在不同设备上都有良好的显示效果。",
      codeSnippet: `// 量化策略主页的主要结构
// 策略数据定义
const strategies = [
  {
    id: "index-enhancement",
    name: "指数增强策略",
    description: "在跟踪指数表现的基础上，通过量化模型获取超额收益...",
    color: "from-blue-500 to-cyan-500",
    icon: "chart-line"
  },
  // 其他策略...
];

// 策略卡片渲染
<motion.div 
  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
  variants={containerVariants}
>
  {strategies.map((strategy, index) => (
    <motion.div
      key={strategy.id}
      variants={itemVariants}
      whileHover={{ 
        y: -8,
        boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
        backdropFilter: "blur(20px)"
      }}
    >
      <Link 
        to="/q/quant-strategy"
        className="block p-8 rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg transition-all duration-500 h-full"
        style={{ textDecoration: 'none' }}
      >
        {/* 卡片内容 */}
      </Link>
    </motion.div>
  ))}
</motion.div>`,
      filesChanged: ["src/pages/QuantStrategyHomePage.tsx", "src/App.tsx"]
    },
    {
     id: "474",
     date: "2025-09-15",
     title: "修改COREX Q主页策略入口链接",
     description: "将COREX Q主页上的策略入口点击后链接到量化策略主页",
     category: "update",
      details: "修改了CorexQPage.tsx文件中的策略入口链接，将其从指向QuantStrategyPage改为指向QuantStrategyHomePage。这样用户在COREX Q主页点击策略入口时，将直接进入我们之前创建的量化策略主页，提供更好的用户体验和更全面的策略概览。同时保持了链接在标准路径和runtime路径下的一致性，确保在两种环境中都能正确工作。",
      codeSnippet: `// 修改前
<motion.a
  href={window.location.pathname.includes("/runtime") ? "/runtime/q/quant-strategy" : "/q/quant-strategy"}
  className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-indigo-500/10 transition-all duration-500"
  // ...其他属性
>
  {/* 内容 */}
</motion.a>

// 修改后
<motion.a
  href={window.location.pathname.includes("/runtime") ? "/runtime/q/quant-strategy-home" : "/q/quant-strategy-home"}
  className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-indigo-500/10 transition-all duration-500"
  // ...其他属性
>
  {/* 内容 */}
</motion.a>`,
     filesChanged: ["src/pages/CorexQPage.tsx"]
    },
    {
     id: "472",
     date: "2025-09-15",
     title: "修复COREX Q文本显示问题，确保单行显示",
     description: "解决COREX Q文本在页面上被分成两行显示的问题，确保其始终在同一行完整显示",
     category: "bugfix",
      details: "发现并修复了CorexQPage.tsx页面中COREX Q文本显示的问题：1. 原代码中，包含COREX Q文本的div元素有固定宽度w-12(48px)，而span元素有宽度200px，导致宽度冲突；2. 尽管我们添加了whiteSpace: 'nowrap'属性，但由于父元素宽度限制，文本仍被强制换行；3. 修复方案：移除了父div元素的固定宽度限制，改为设置minWidth: '150px'，确保它能完全容纳子元素内容；4. 同时优化了样式设置，移除了不必要的宽度属性，让文本自然显示。",
      codeSnippet: `// 修复前
<div
  className="w-12 h-12 rounded-lg bg-white flex items-center justify-center mr-3"
  style={{
    borderRadius: "16px",
    backgroundColor: "transparent"
  }}>
  <span
    className="text-indigo-900 font-bold text-xl"
    style={{
      fontSize: "24px",
      fontFamily: "DOUYINSANSBOLD-GB",
      fontWeight: "bold",
      color: "#FFFFFF",
      width: "200px",
      height: "40px",
      display: "inline-block",
      whiteSpace: "nowrap"
    }}>COREX Q</span>
</div>

// 修复后
<div
  className="flex items-center justify-center mr-3"
  style={{
    borderRadius: "16px",
    backgroundColor: "transparent",
    minWidth: "150px",
    height: "40px"
  }}>
  <span
    className="text-indigo-900 font-bold text-xl"
    style={{
      fontSize: "24px",
      fontFamily: "DOUYINSANSBOLD-GB",
      fontWeight: "bold",
      color: "#FFFFFF",
      whiteSpace: "nowrap",
      display: "inline-block"
    }}>COREX Q</span>
</div>`,
     filesChanged: ["src/pages/CorexQPage.tsx"]
    },
    {
     id: "471",
     date: "2025-09-15",
     title: "确保COREX Q文本单行显示",
     description: "修改CorexQPage页面中COREX Q文本的样式，确保其始终只显示为一行",
     category: "update",
      details: "根据用户需求，在CorexQPage.tsx页面中第356行的SPAN元素样式中添加了whiteSpace: 'nowrap'属性，确保COREX Q文本在任何情况下都只显示在一行内，不会出现换行问题。同时修正了文本内容，确保显示完整的'COREX Q'而不是'COREX '。",
      codeSnippet: `// 修改前
<span
  className="text-indigo-900 font-bold text-xl"
  style={{
    fontSize: "24px",
    fontFamily: "DOUYINSANSBOLD-GB",
    fontWeight: "bold",
    color: "#FFFFFF",
    width: "200px",
    height: "40px",
    display: "inline-block"
  }}>COREX </span>

// 修改后
<span
  className="text-indigo-900 font-bold text-xl"
  style={{
    fontSize: "24px",
    fontFamily: "DOUYINSANSBOLD-GB",
    fontWeight: "bold",
    color: "#FFFFFF",
    width: "200px",
    height: "40px",
    display: "inline-block",
    whiteSpace: "nowrap"
  }}>COREX Q</span>`,
     filesChanged: ["src/pages/CorexQPage.tsx"]
    },
      {
      id: "449",
      date: "2025-09-15",
      title: "修复收藏夹内容显示问题",
      description: "修复收藏夹中信息无法完整显示的问题",
      category: "bugfix",
       details: "优化了收藏夹页面中内容的显示方式，添加了以下改进：1. 移除了对长内容的截断逻辑，确保完整存储和显示收藏内容；2. 添加了自动换行和断字处理，确保内容不会溢出容器；3. 对于长内容添加了'查看更多'功能，用户可以点击展开查看完整内容。",
       codeSnippet: `// 优化收藏内容显示
<div className="favorite-content">
  <p className="${isDark ? "text-gray-300" : "text-gray-700"} whitespace-pre-wrap break-words">
    {message.content}
  </p>
</div>
{message.content.length > 200 && (
  <button onClick={() => setExpandedContentId(expandedContentId === message.id ? null : message.id)}>
    {expandedContentId === message.id ? '收起内容' : '查看更多'}
  </button>
)}`,
      filesChanged: ["src/pages/FavoritesPage.tsx", "src/contexts/chatContext.tsx"]
    },
    {
      id: "444",
      date: "2025-09-14",
      title: "添加历史消息搜索功能",
      description: "将对话历史摘要标题改为搜索框，支持搜索历史消息",
      category: "feature",
       details: "在对话历史摘要区域添加了搜索功能，用户可以通过关键词快速查找历史消息。实现了搜索过滤逻辑，并添加了未找到结果时的提示信息，提升了用户查找历史对话的效率。",
      codeSnippet: `// 添加搜索状态和处理函数
const [messageSearchQuery, setMessageSearchQuery] = useState<string>("");

// 在渲染消息列表时应用过滤
{[...messages]
  .reverse()
  .filter(message => !messageSearchQuery || 
      message.content.toLowerCase().includes(messageSearchQuery.toLowerCase()))
  .map((message, index) => (
    // 消息项渲染代码
  ))}`,
      filesChanged: ["src/pages/Home.tsx"]
    },
    {
      id: "443",
      date: "2025-09-14",
      title: "优化聊天输入框样式",
      description: "移除提示文字，添加紫色光效边框",
      category: "update",
       details: "优化了聊天输入框的视觉效果，移除了占位提示文字，并为输入框添加了紫色光效边框，提升了用户体验和界面美观度。",
      codeSnippet: `// 请求浏览器通知权限
const requestNotificationPermission = async () => {
  if ('Notification' in window) {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

// 显示通知
const showNotification = async (title, options) => {
  // 实现通知显示逻辑
};`,
      filesChanged: ["src/hooks/useTheme.ts", "src/pages/Home.tsx"]
    },
    {
      id: "441",
      date: "2025-09-14",
      title: "完善工作日志页面",
      description: "整合全部版本历史记录到工作日志页面",
      category: "update",
      details: "将所有版本历史记录整合到工作日志页面，提供完整的项目开发历程查看功能。添加了更强大的筛选和搜索功能，优化了大量日志数据的显示性能。"
    },
    {
      id: "440",
      date: "2025-09-14",
      title: "添加代码一键导出功能",
      description: "为AI生成的代码块添加了直接下载为文件的功能",
      category: "feature",
      details: "实现了代码块组件的下载功能，支持根据代码语言自动选择文件扩展名，使用户能够一键导出生成的代码为可执行文件。实现了Blob对象创建和URL.createObjectURL()方法来处理文件生成和下载逻辑。",
      codeSnippet: `const handleDownload = async () => {
  try {
    const code = String(children);
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const fileExtension = getFileExtension(language);
    a.download = \`code.\${fileExtension}\`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('代码文件已下载');
  } catch (err) {
    console.error('下载失败:', err);
    toast.error('下载失败，请手动复制');
  }
};`,
      filesChanged: ["src/components/CodeBlock.tsx"]
    },
    {
      id: "439",
      date: "2025-09-14",
      title: "调整时间排序为从近到远",
      description: "优化了对话历史摘要区域的显示效果和交互体验",
      category: "refactor",
      details: "优化了对话历史摘要的排序逻辑，现在按照时间从近到远的顺序显示消息。同时隐藏了滚动条，使界面更加整洁美观。实现了点击摘要条目可以跳转到对应消息的功能，提升了用户体验。",
      codeSnippet: `{/* 反转消息数组，使最新的消息显示在最上面 */}
{[...messages].reverse().map((message, index) => <motion.div
  key={message.id}
  className={\`p-3 rounded-lg transition-all duration-300 hover:shadow-md cursor-pointer \${message.sender === "user" ? "bg-gradient-to-r from-indigo-50 to-purple-50" : "bg-gradient-to-r from-purple-50 to-pink-50"}\`}
  whileHover={{
    scale: 1.01,
    backgroundColor: message.sender === "user" ? "rgba(238, 242, 255, 0.8)" : "rgba(245, 235, 255, 0.8)"
  }}>`,
      filesChanged: ["src/pages/Home.tsx"]
    },
    {
      id: "438",
      date: "2025-09-14",
      title: "修复 ChatMessage.tsx 中的 div 样式问题",
      description: "修复了聊天气泡样式问题",
      category: "bugfix",
      details: "修复了聊天气泡的样式问题，确保在各种屏幕尺寸下都能正确显示。调整了边框、阴影和过渡效果，提升了用户体验。"
    },
    {
      id: "437",
      date: "2025-09-14",
      title: "隐藏聊天侧边栏滚动条",
      description: "解决了聊天侧边栏滚动条显示异常的问题",
      category: "bugfix",
      details: "在聊天侧边栏组件中添加了隐藏滚动条的样式，使界面更加统一美观。使用了CSS属性scrollbarWidth: 'none'和::-webkit-scrollbar { display: none }来实现跨浏览器兼容的滚动条隐藏效果。",
      codeSnippet: `style={{
  scrollbarWidth: "none",
  "-ms-overflow-style": "none",
  borderColor: "#D6DAE4",
  borderWidth: "1px"
}}>
{/* 隐藏WebKit浏览器中的滚动条 */}
<style jsx>{\`
  &::-webkit-scrollbar {
    display: none;
  }
\`}</style>`,
      filesChanged: ["src/components/ChatSidebar.tsx"]
    },
    {
      id: "436",
      date: "2025-09-14",
      title: "隐藏滚动条",
      description: "尝试隐藏页面滚动条",
      category: "update",
      details: "尝试隐藏页面滚动条，使界面更加整洁。但此更改已回退，因为它影响了用户体验。"
    },
    {
      id: "435",
      date: "2025-09-14",
      title: "隐藏 DIV 的滚动条",
      description: "隐藏特定DIV元素的滚动条",
      category: "update",
      details: "为特定的DIV元素添加了隐藏滚动条的样式，使界面更加统一美观。"
    },
    {
      id: "434",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "433",
      date: "2025-09-14",
      title: "用户手动修改了ChatSidebar.tsx、Home.tsx",
      description: "用户对多个核心组件进行了自定义修改",
      category: "update",
      details: "用户手动修改了ChatSidebar.tsx和Home.tsx文件，对聊天侧边栏和主页的布局或功能进行了调整。"
    },
    {
      id: "432",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "431",
      date: "2025-09-14",
      title: "移除消息模块左侧彩条",
      description: "移除了消息模块左侧的彩条装饰",
      category: "update",
      details: "移除了ChatMessage.tsx中消息模块左侧的彩条装饰，使界面更加简洁。"
    },
    {
      id: "430",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "429",
      date: "2025-09-14",
      title: "修复 Home.tsx 中 DIV 元素悬停显示问题",
      description: "修复了DIV元素悬停效果显示异常的问题",
      category: "bugfix",
      details: "修复了Home.tsx中DIV元素在悬停时的显示问题，确保过渡效果和样式正确应用。"
    },
    {
      id: "428",
      date: "2025-09-14",
      title: "修复 Home.tsx 中 DIV 元素悬停显示问题",
      description: "修复了DIV元素悬停效果显示异常的问题",
      category: "bugfix",
      details: "修复了Home.tsx中DIV元素在悬停时的显示问题，确保过渡效果和样式正确应用。"
    },
    {
      id: "427",
      date: "2025-09-14",
      title: "前端选中的按钮区域",
      description: "优化了按钮区域的样式和交互效果",
      category: "update",
      details: "优化了前端选中的按钮区域的样式和交互效果，提升了用户体验。"
    },
    {
      id: "426",
      date: "2025-09-14",
      title: "前端选中区域模块一致性检查",
      description: "检查并确保各模块视觉一致性",
      category: "update",
      details: "对前端选中区域的各个模块进行了一致性检查，确保颜色、间距、圆角等视觉元素保持统一。"
    },
    {
      id: "425",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "424",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "423",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "422",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "421",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "420",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "419",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "418",
      date: "2025-09-14",
      title: "调整 DIV 高度与外模块一致",
      description: "调整了DIV元素的高度，使其与外部模块保持一致",
      category: "update",
      details: "调整了特定DIV元素的高度，使其与外部容器模块保持一致。此更改已回退，可能因为影响了其他布局。"
    },
    {
      id: "417",
      date: "2025-09-14",
      title: "调整 DIV 模块显示全部内容",
      description: "修改了DIV模块的样式，确保能够显示全部内容",
      category: "update",
      details: "调整了特定DIV模块的样式属性，确保其能够完整显示内部的所有内容，而不会被截断。"
    },
    {
      id: "416",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "415",
      date: "2025-09-14",
      title: "前端选中区域标记",
      description: "标记了前端需要特别注意的区域",
      category: "update",
      details: "标记了前端代码中需要特别注意或可能需要修改的区域，方便后续开发和维护。"
    },
    {
      id: "414",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "413",
      date: "2025-09-14",
      title: "添加毛玻璃动效",
      description: "为界面元素添加了毛玻璃动画效果",
      category: "feature",
      details: "为特定的界面元素添加了毛玻璃动画效果，增强了视觉体验和现代感。"
    },
    {
      id: "412",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "411",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "410",
      date: "2025-09-14",
      title: "前端选中区域编辑",
      description: "编辑了前端选中区域的代码",
      category: "update",
      details: "对前端代码中选中的特定区域进行了编辑修改。此更改已回退，可能因为出现了问题。"
    },
    {
      id: "409",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。此更改已回退。"
    },
    {
      id: "408",
      date: "2025-09-14",
      title: "固定代码编辑器显示区高度",
      description: "设置了代码编辑器显示区域的固定高度",
      category: "update",
      details: "为代码编辑器显示区域设置了固定的高度，以确保在各种情况下都能保持良好的布局。"
    },
    {
      id: "407",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "406",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "405",
      date: "2025-09-14",
      title: "调整代码预览框样式大小",
      description: "修改了代码预览框的样式和大小",
      category: "update",
      details: "调整了代码预览框的样式属性和尺寸，使其显示更加美观和实用。"
    },
    {
      id: "404",
      date: "2025-09-14",
      title: "为选中区域添加编辑功能",
      description: "为前端选中区域添加了编辑功能",
      category: "feature",
      details: "为前端代码中选中的特定区域添加了编辑功能，提升了用户交互体验。"
    },
    {
      id: "403",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "402",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "401",
      date: "2025-09-14",
      title: "设计代码视窗模块",
      description: "设计并实现了代码视窗模块",
      category: "feature",
      details: "设计并实现了代码视窗模块，提供了更好的代码展示和编辑体验。"
    },
    {
      id: "400",
      date: "2025-09-14",
      title: "前端选中的 DIV 区域",
      description: "标记了前端需要特别注意的DIV区域",
      category: "update",
      details: "标记了前端代码中需要特别注意或可能需要修改的DIV区域，方便后续开发和维护。"
    },
    {
      id: "399",
      date: "2025-09-14",
      title: "前端选中区域代码优化",
      description: "对前端选中区域的代码进行了优化",
      category: "refactor",
      details: "对前端代码中选中的特定区域进行了优化，提高了代码质量和性能。"
    },
    {
      id: "398",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "397",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "396",
      date: "2025-09-14",
      title: "优化主页代码区域背景动效",
      description: "优化了主页代码区域的背景动画效果",
      category: "update",
      details: "优化了主页代码区域的背景动画效果，提升了视觉体验和性能。"
    },
    {
      id: "395",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。"
    },
    {
      id: "394",
      date: "2025-09-14",
      title: "前端选中区域编辑",
      description: "编辑了前端选中区域的代码",
      category: "update",
      details: "对前端代码中选中的特定区域进行了编辑修改。此更改已回退，可能因为出现了问题。"
    },
    {
      id: "393",
      date: "2025-09-14",
      title: "用户手动修改了Home.tsx",
      description: "用户对主页进行了自定义修改",
      category: "update",
      details: "用户手动修改了Home.tsx文件，对主页的布局或功能进行了调整。此更改已回退。"
    },
    {
      id: "392",
      date: "2025-09-14",
      title: "前端选中区域标记",
      description: "标记了前端需要特别注意的区域",
      category: "update",
      details: "标记了前端代码中需要特别注意或可能需要修改的区域，方便后续开发和维护。"
    },
    {
      id: "391",
      date: "2025-09-14",
      title: "前端选中区域主题调整",
      description: "调整了前端选中区域的主题样式",
      category: "update",
      details: "调整了前端代码中选中区域的主题样式，包括颜色、字体等视觉元素。"
    }
  ];

    // 添加数据库功能日志
    logEntries.unshift({
      id: "475",
      date: new Date().toISOString().split('T')[0],
      title: "添加数据库功能",
      description: "增强本地存储功能，添加自动保存上传图片和知识内容的数据库服务",
      category: "feature",
      details: "实现了一个增强的本地存储服务，创建了StorageService类和相应的React Hooks，用于管理上传的图片和知识内容：1. 创建了专门的数据服务类，使用LocalStorage作为存储媒介，组织成更结构化的'数据库'形式；2. 实现了图片和知识的增删改查功能；3. 提供了数据库备份和恢复功能；4. 创建了React Hooks（useImages, useKnowledge, useDatabase）方便组件使用这些数据；5. 更新了图片上传功能，使其自动将图片保存到数据库中；6. 添加了存储配额管理，当存储空间不足时自动清理旧数据；7. 确保了数据在应用各部分之间能够正确共享和访问。",
      codeSnippet: `// StorageService类的主要结构
class StorageService {
  // 初始化数据库
  init(): void {
    // 确保所有表都已创建
    this.ensureTableExists(DB_TABLES.IMAGES);
    this.ensureTableExists(DB_TABLES.KNOWLEDGE);
    this.ensureTableExists(DB_TABLES.METADATA);
    
    // 设置数据库版本
    this.setMetadata('version', '1.0.0');
    this.setMetadata('lastInitialized', new Date().toISOString());
  }
  
  // 添加图片方法示例
  addImage(image: Omit<UploadedImage, 'id' | 'uploadDate'>): UploadedImage {
    try {
      const newImage: UploadedImage = {
        ...image,
        id: this.generateId(),
        uploadDate: new Date().toISOString()
      };
      
      const images = this.getTableData<UploadedImage>(DB_TABLES.IMAGES);
      images.push(newImage);
      this.saveTableData(DB_TABLES.IMAGES, images);
      
      return newImage;
    } catch (error) {
      console.error('Error adding image:', error);
      throw error;
    }
  }
}`,
      filesChanged: ["src/lib/StorageService.ts", "src/hooks/useStorage.ts", "src/pages/Home.tsx"]
     });

    // 添加GRE阅读题到题库
    logEntries.unshift({
      id: "482",
      date: new Date().toISOString().split('T')[0],
      title: "添加GRE阅读题示例",
      description: "将用户提供的GRE阅读题添加到题库系统中",
      category: "feature",
      details: "根据用户提供的图片和题目内容，添加了一道关于玛雅低地水资源管理的GRE阅读题：1. 完整提取了文章内容和题目；2. 添加了5个选项，其中正确答案是'identify the source of evidence that suggested a hypothesis'；3. 提供了详细的解析，解释了为什么该选项是正确的；4. 添加了相关标签以便分类和搜索；5. 设置题目难度为中等；6. 通过自动检测机制确保不会重复添加相同的题目；7. 该题目已添加到题库中，可以在GRE题库页面查看和练习。",
      codeSnippet: `// 添加GRE阅读题的代码
await addGREQuestion({
  type: 'reading_comprehension',
  difficulty: 'medium',
  content: 'The author mentions "studies of lake and shallow ocean sediments" primarily in order to',
  passage: 'Availability and management of water greatly influenced human settlement in the Maya Lowlands...',
  options: [
    { id: 'a', text: 'describe the results of a novel study', isCorrect: false },
    { id: 'b', text: 'identify the source of evidence that suggested a hypothesis', isCorrect: true },
    { id: 'c', text: 'undermine a conventional explanation', isCorrect: false },
    { id: 'd', text: 'highlight the importance of one type of evidence', isCorrect: false },
    { id: 'e', text: 'clarify the value of a particular undertaking', isCorrect: false }
  ],
  correctAnswer: 'b',
  explanation: 'The author mentions "studies of lake and shallow ocean sediments" as the source of evidence that led researchers to hypothesize that climate was responsible for the Classic Maya collapse.',
  tags: ['reading_comprehension', 'maya_civilization', 'climate_change', 'water_management']
});`,
      filesChanged: ["src/pages/GREQuestionBankPage.tsx"]
    });

    // 添加GRE模拟考试功能日志
    logEntries.unshift({
      id: "481",
      date: new Date().toISOString().split('T')[0],
      title: "添加GRE模拟考试功能",
      description: "创建了模仿真实GRE考试界面的刷题页面，提供更真实的考试体验",
      category: "feature",
      details: "实现了一个高度模仿真实GRE考试界面的模拟考试功能：1. 创建了GRERealExamPage组件，完全模仿ETS GRE考试的界面布局；2. 实现了考试导航栏，包含退出、标记、复习、帮助、返回、下一步等按钮；3. 添加了题目进度显示和倒计时功能；4. 支持标记题目、隐藏/显示计时器、查看帮助等功能；5. 实现了句子等价题的题型，支持选择两个答案；6. 添加了模拟考试入口到GRE题库页面；7. 确保了在标准路径和runtime路径下都能访问；8. 保持了与真实GRE考试一致的视觉风格和交互体验。",
      codeSnippet: `// GRE模拟考试页面的主要结构
const GRERealExamPage: React.FC = () => {
  // 考试状态管理
  const [currentSection, setCurrentSection] = useState(2);
  const [totalSections, setTotalSections] = useState(5);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(7); // 0-based index for 8th question
  const [totalQuestionsInSection, setTotalQuestionsInSection] = useState(12);
  const [timeRemaining, setTimeRemaining] = useState(7 * 60 + 36); // 7 minutes 36 seconds
  const [isTimerVisible, setIsTimerVisible] = useState(true);
  const [markedQuestions, setMarkedQuestions] = useState<number[]>([]);
  const [reviewMode, setReviewMode] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  
  // 实现模拟考试的各种功能
  // ...
}`,
      filesChanged: ["src/pages/GRERealExamPage.tsx", "src/App.tsx", "src/pages/GREQuestionBankPage.tsx"]
    });

    // 添加GRE题库功能日志
    logEntries.unshift({
      id: "480",
      date: new Date().toISOString().split('T')[0],
      title: "添加GRE题库数据库功能",
      description: "实现GRE题库数据库，支持选择题和阅读题管理，包含题库页面和练习页面",
      category: "feature",
      details: "实现了完整的GRE题库系统，包括：1. 在数据库中添加了GRE题库存储对象，支持选择题和阅读题两种类型；2. 创建了GREQuestionBankPage，用于管理和展示所有题目；3. 实现了GREQuestionEditorPage，用于添加和编辑题目；4. 开发了GREQuestionPracticePage，提供交互式练习功能；5. 支持按类型、难度过滤题目，以及关键词搜索；6. 为题库系统添加了丰富的动画效果和视觉设计，保持与COREX Q一致的风格；7. 在导航栏中添加了题库入口；8. 添加了模拟数据，方便用户立即体验功能；9. 支持标准路径和runtime路径两种访问方式。",
      codeSnippet: `// 数据库中添加GRE题库相关接口
export interface GREQuestionOption {
  id: string;
  text: string;
  isCorrect?: boolean;
}

export interface GREQuestion {
  id: string;
  type: 'multiple_choice' | 'reading_comprehension';
  difficulty: 'easy' | 'medium' | 'hard';
  content: string;
  options?: GREQuestionOption[];
  correctAnswer?: string;
  explanation?: string;
  passage?: string;
  tags?: string[];
  createDate: string;
  updateDate?: string;
}`,
      filesChanged: ["src/lib/IndexedDBService.ts", "src/lib/StorageService.ts", "src/hooks/useStorage.ts", "src/pages/GREQuestionBankPage.tsx", "src/pages/GREQuestionEditorPage.tsx", "src/pages/GREQuestionPracticePage.tsx", "src/App.tsx"]
    });

    // 添加新的存储选项功能日志
    logEntries.unshift({
      id: "479",
      date: new Date().toISOString().split('T')[0],
      title: "添加新的数据库存储选项",
      description: "增加数据库分享功能和存储类型切换选项，提供更多存储方式选择",
      category: "feature",
      details: "为数据库管理系统添加了新的存储选项，包括：1. 实现了通过Web Share API分享数据库的功能，用户可以将数据库备份分享到其他应用；2. 添加了存储类型切换选项，用户可以手动选择使用IndexedDB存储；3. 优化了数据库导入流程，确保异步操作正确处理；4. 更新了数据库操作按钮，更清晰地标识各功能；5. 在存储统计页面显示当前使用的存储类型，帮助用户了解系统状态。这些更新为用户提供了更灵活的数据存储和管理选择。",
      codeSnippet: `// 处理分享数据库
const handleShareDatabase = async () => {
  try {
    // 检查浏览器是否支持Web Share API
    if (!navigator.share) {
      toast.warning("您的浏览器不支持分享功能，请使用导出功能");
      return;
    }
    
    // 获取数据库内容并分享
    const data = await exportDatabase();
    const blob = new Blob([data], { type: 'application/json' });
    
    await navigator.share({
      title: 'COREX数据库备份',
      text: 'COREX数据库备份文件',
      files: [new File([blob], fileName, { type: 'application/json' })]
    });
    
    toast.success("数据库分享成功");
  } catch (error) {
    console.error("分享数据库时发生错误:", error);
    toast.error("数据库分享失败");
  }
};`,
      filesChanged: ["src/pages/DatabasePage.tsx", "src/lib/StorageService.ts"]
    });

     // 添加存储服务导入错误修复日志
    logEntries.unshift({
      id: "478",
      date: new Date().toISOString().split('T')[0],
      title: "修复GRE题库页面中的函数导入错误",
      description: "修复了GREQuestionBankPage.ts中未正确导入addGREQuestion和getQuestionsByFilter函数的问题",
      category: "bugfix",
      details: "发现并修复了GREQuestionBankPage.ts文件中的ReferenceError错误：1. 系统报错显示'addGREQuestion is not defined'；2. 问题在于从useGREQuestions hook中解构时没有包含addGREQuestion和getQuestionsByFilter函数，但代码中却尝试使用这些函数；3. 修复方案：更新解构语句，添加缺失的函数；4. 这个修复确保了代码能够正确编译和运行，同时保持了功能的完整性。",
      codeSnippet: `// 修复前
const { 
  questions, 
  loading, 
  getQuestionsByType,
  getQuestionsByDifficulty,
  deleteGREQuestion
} = useGREQuestions();

// 修复后
const { 
  questions, 
  loading, 
  getQuestionsByType,
  getQuestionsByDifficulty,
  deleteGREQuestion,
  addGREQuestion,
  getQuestionsByFilter
} = useGREQuestions();`,
      filesChanged: ["src/pages/GREQuestionBankPage.tsx"]
    });

    // 添加IndexedDB升级日志
    logEntries.unshift({
      id: "477",
      date: new Date().toISOString().split('T')[0],
      title: "使用IndexedDB增大数据库容量",
      description: "升级存储系统，使用IndexedDB替代localStorage，大幅提升数据库容量",
      category: "feature",
      details: "对数据库系统进行了全面升级，使用IndexedDB替代localStorage，大幅提升了存储容量和性能：1. 创建了IndexedDBService类，封装了完整的IndexedDB操作；2. 实现了从localStorage到IndexedDB的自动数据迁移，确保现有数据不丢失；3. 增强了StorageService类，实现了IndexedDB优先、localStorage降级的无缝切换机制；4. 更新了useStorage钩子，使其支持异步操作；5. 优化了数据库管理页面，显示存储类型和容量信息；6. IndexedDB提供了更大的存储容量（250MB-2GB，取决于浏览器），比localStorage的5-10MB有显著提升；7. 支持事务操作，提高了数据操作的原子性和可靠性；8. 保持了与原有API的兼容性，现有功能无需修改即可使用新的存储系统。",
      codeSnippet: `// IndexedDBService的主要结构
class IndexedDBService {
  private db: IDBDatabase | null = null;
  private initPromise: Promise<void> | null = null;

  // 初始化数据库
  async init(): Promise<void> {
    if (this.initPromise) {
      return this.initPromise;

    this.initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      
      // 创建存储对象和索引
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        // 创建各种存储对象
        // ...
      };
      
      // 处理成功和失败
      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        // 迁移数据
        this.migrateFromLocalStorage().then(() => resolve());
      };
      
      request.onerror = (event) => {
        reject((event.target as IDBOpenDBRequest).error);
      };
    });
    
    return this.initPromise;
  }

  // 图片相关方法
  async addImage(image: Omit<UploadedImage, 'id' | 'uploadDate'>): Promise<UploadedImage> {
    // 实现添加图片逻辑
  }
  
  // 其他数据操作方法...
}`,
      filesChanged: ["src/lib/IndexedDBService.ts", "src/lib/StorageService.ts", "src/hooks/useStorage.ts", "src/pages/Home.tsx", "src/pages/DatabasePage.tsx"]
    });

    // 添加数据库功能日志
    logEntries.unshift({
      id: "476",
      date: new Date().toISOString().split('T')[0],
      title: "添加数据库管理页面",
      description: "创建数据库管理页面，添加进入数据库的导航按钮",
      category: "feature",
      details: "实现了数据库管理页面，用户现在可以通过导航栏访问存储的图片和知识内容：1. 在NavigationBar中添加了数据库导航按钮；2. 创建了DatabasePage组件，用于展示和管理数据库内容；3. 实现了三个标签页：图片管理、知识内容管理和数据库统计；4. 添加了数据库导入和导出功能，支持备份和恢复数据；5. 为图片添加了删除功能；6. 确保了页面在标准路径和runtime路径下都能正确访问；7. 保持了与COREX Q一致的视觉风格，包括毛玻璃效果、渐变背景和动画效果。",
      codeSnippet: `// 导航栏添加数据库按钮
const navItems = [{
  // ...其他导航项
  path: "/database",
  label: "数据库",
  icon: "database"
}];

// 路由配置
<Route path="/database" element={<DatabasePage />} />
<Route path="/runtime/database" element={<DatabasePage />} />

// 数据库管理页面主要功能
const handleImportDatabase = async () => {
  // 导入数据库逻辑
};

const handleExportDatabase = () => {
  // 导出数据库逻辑
};`,
      filesChanged: ["src/pages/DatabasePage.tsx", "src/components/NavigationBar.tsx", "src/App.tsx"]
    });

  // 过滤日志条目
  const filteredEntries = logEntries.filter(entry => {
    const matchesCategory = activeTab === "all" || entry.category === activeTab;
    const matchesSearch = searchQuery === "" || 
                          entry.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          entry.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          entry.details.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // 获取分类数量
  const getCategoryCount = (category: string) => {
    return logEntries.filter(entry => entry.category === category).length;
  };

  // 获取分类对应的中文名称
  const getCategoryName = (category: string) => {
    const categoryMap: Record<string, string> = {
      "all": "全部",
      "feature": "新功能",
      "bugfix": "Bug修复",
      "refactor": "代码重构",
      "update": "更新改进"
    };
    return categoryMap[category] || category;
  };

  // 获取分类对应的图标
  const getCategoryIcon = (category: string) => {
    const iconMap: Record<string, string> = {
      "feature": "fas fa-plus-circle",
      "bugfix": "fas fa-bug",
      "refactor": "fas fa-code-branch",
      "update": "fas fa-sync"
    };
    return iconMap[category] || "fas fa-list";
  };

  // 获取分类对应的颜色
  const getCategoryColor = (category: string) => {
    const colorMap: Record<string, string> = {
      "feature": isDark ? "text-emerald-400" : "text-emerald-600",
      "bugfix": isDark ? "text-red-400" : "text-red-600",
      "refactor": isDark ? "text-blue-400" : "text-blue-600",
      "update": isDark ? "text-amber-400" : "text-amber-600"
    };
    return colorMap[category] || "text-gray-500";
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

   return (
     <div className={`min-h-screen flex flex-col ${isDark ? "bg-gradient-to-br from-gray-900 via-purple-950 to-indigo-950 text-white" : "bg-gradient-to-br from-white via-purple-50 to-indigo-50 text-gray-900"} relative overflow-hidden`}>
      {/* 背景装饰元素 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className={`absolute top-20 left-20 w-64 h-64 rounded-full ${isDark ? "bg-purple-700/20" : "bg-purple-200/40"} blur-3xl animate-pulse`} style={{ animationDuration: '8s' }}></div>
        <div className={`absolute bottom-20 right-20 w-72 h-72 rounded-full ${isDark ? "bg-indigo-700/20" : "bg-indigo-200/40"} blur-3xl animate-pulse`} style={{ animationDuration: '10s', animationDelay: '1s' }}></div>
        <div className={`absolute top-1/2 left-1/3 w-48 h-48 rounded-full ${isDark ? "bg-pink-700/20" : "bg-pink-200/40"} blur-3xl animate-pulse`} style={{ animationDuration: '12s', animationDelay: '2s' }}></div>
      </div>
      <NavigationBar currentPage="/log" />
      
      <div className="container mx-auto px-4 py-8 flex-grow relative z-10">
        <motion.div 
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">工作日志</h1>
            <p className={`${isDark ? "text-gray-400" : "text-gray-600"} mb-4`}>记录开发过程中的重要变更和改进</p>
            <div className={`inline-block px-4 py-2 rounded-full text-sm ${isDark ? "bg-indigo-900/30 text-indigo-400" : "bg-indigo-100 text-indigo-700"}`}>
              共 {logEntries.length} 条记录
            </div>
          </div>
          
           {/* 搜索和筛选区域 */}
          <div className="mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <input
                  type="text"
                  placeholder="搜索日志..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full px-4 py-2 rounded-lg border ${
                    isDark 
                      ? "bg-gray-800 border-gray-700 text-white" 
                      : "bg-white border-gray-300 text-gray-800"
                  } focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                />
                <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {["all", "feature", "bugfix", "refactor", "update"].map((category) => (
                  <motion.button
                    key={category}
                    className={`px-3 py-1.5 rounded-full text-sm flex items-center gap-1 transition-all ${
                      activeTab === category 
                        ? isDark 
                          ? "bg-indigo-900/30 text-indigo-400 border border-indigo-800/50" 
                          : "bg-indigo-100 text-indigo-700 border border-indigo-200" 
                        : isDark 
                          ? "bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700" 
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"
                    }`}
                    onClick={() => setActiveTab(category)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {category !== "all" && <i className={`${getCategoryIcon(category)} text-xs`}></i>}
                    <span>{getCategoryName(category)}</span>
                    {category !== "all" && (
                      <span className={`text-xs ${activeTab === category ? "" : isDark ? "text-gray-500" : "text-gray-400"}`}>
                        ({getCategoryCount(category)})
                      </span>
                    )}
                  </motion.button>
                ))}
              </div>
            </div>
            
            {/* 显示过滤结果统计 */}
            {searchQuery || activeTab !== "all" && (
              <div className="mt-3 flex items-center justify-between text-sm">
                <span className={`${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  显示 {filteredEntries.length} 条记录 (共 {logEntries.length} 条)
                </span>
                {(searchQuery || activeTab !== "all") && (
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setSearchQuery("");
                      setActiveTab("all");
                    }}
                    className={`text-xs px-3 py-1 rounded-full ${
                      isDark ? "bg-gray-800 text-gray-300 hover:bg-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    }`}
                  >
                    清除筛选
                  </motion.button>
                )}
              </div>
            )}
          </div>
        </motion.div>
        
          {/* 日志列表 */}
          <motion.div 
            className="space-y-4 max-w-4xl mx-auto"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.1
                }
              }
            }}
            initial="hidden"
            animate="visible"
          >
             {filteredEntries.map((entry) => (
              <motion.div
                key={entry.id}
                className={`rounded-xl border overflow-hidden transition-all backdrop-blur-md ${
                  isDark 
                    ? "bg-gray-800/80 border-gray-700" 
                    : "bg-white/80 border-gray-100 shadow-md"
                }`}
                whileHover={{ y: -3, boxShadow: isDark ? "0 10px 25px -5px rgba(139, 92, 246, 0.2)" : "0 10px 25px -5px rgba(139, 92, 246, 0.1)" }}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 }
                }}
              >
                {/* 日志头部 */}
                <div 
                  className={`p-4 cursor-pointer flex justify-between items-center ${
                    expandedEntry === entry.id ? (isDark ? "bg-gray-700" : "bg-gray-50") : ""
                  }`}
                  onClick={() => setExpandedEntry(expandedEntry === entry.id ? null : entry.id)}
                >
                  <div className="flex items-center gap-3">
                     <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isDark 
                        ? "bg-gradient-to-br from-purple-900/50 to-indigo-900/50" 
                        : "bg-gradient-to-br from-purple-100 to-indigo-100"
                    }`}>
                      <i className={`${getCategoryIcon(entry.category)} ${getCategoryColor(entry.category)}`}></i>
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{entry.title}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-xs ${getCategoryColor(entry.category)}`}>
                          {getCategoryName(entry.category)}
                        </span>
                        <span className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                          {formatDate(entry.date)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <motion.div
                    animate={{ rotate: expandedEntry === entry.id ? 180 : 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <i className={`fas fa-chevron-down text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}></i>
                  </motion.div>
                </div>
                
                {/* 日志内容 */}
                <motion.div
                  initial={false}
                  animate={{ height: expandedEntry === entry.id ? "auto" : 0, opacity: expandedEntry === entry.id ? 1 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className={`p-4 ${isDark ? "bg-gray-800/50" : "bg-white"}`}>
                    <p className={`mb-4 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                      {entry.description}
                    </p>
                    
                    <div className="mb-4">
                      <h4 className={`text-sm font-medium mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                        详细说明
                      </h4>
                      <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"} whitespace-pre-line`}>
                        {entry.details}
                      </p>
                    </div>
                    
                    {entry.codeSnippet && (
                      <div className="mb-4">
                        <h4 className={`text-sm font-medium mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                          代码示例
                        </h4>
                        <pre className={`p-3 rounded-md text-xs overflow-x-auto ${
                          isDark ? "bg-gray-900 text-gray-300" : "bg-gray-100 text-gray-800"
                        }`}>
                          <code>{entry.codeSnippet}</code>
                        </pre>
                      </div>
                    )}
                    
                    {entry.filesChanged && entry.filesChanged.length > 0 && (
                      <div>
                        <h4 className={`text-sm font-medium mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                          修改的文件
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {entry.filesChanged.map((file, index) => (
                            <span key={index} className={`px-2 py-1 text-xs rounded-md ${
                              isDark ? "bg-gray-700 text-gray-300" : "bg-gray-100 text-gray-700"
                            }`}>
                              {file}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              </motion.div>
            ))}
            
            {filteredEntries.length === 0 && (
              <motion.div
                className={`text-center p-8 rounded-lg border ${
                  isDark ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"
                }`}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 }
                }}
              >
                <i className="fas fa-search text-2xl mb-3 text-gray-400"></i>
                <h3 className={`font-medium mb-1 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                  没有找到匹配的日志
                </h3>
                <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                  尝试调整搜索条件或筛选类别
                </p>
              </motion.div>
            )}
          </motion.div>
      </div>
      
      <footer className={`py-6 mt-auto ${isDark ? "bg-gray-900 border-t border-gray-800" : "bg-white border-t border-gray-200"}`}>
        <div className="container mx-auto px-4 text-center">
          <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>
            © 2025 COREX AI 团队 | 工作日志系统
          </p>
        </div>
      </footer>
    </div>
  );
};

export default LogPage;