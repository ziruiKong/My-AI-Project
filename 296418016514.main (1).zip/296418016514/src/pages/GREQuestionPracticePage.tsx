import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useGREQuestions } from "../hooks/useStorage";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { GREQuestion, GREQuestionOption } from "../lib/StorageService";

const GREQuestionPracticePage: React.FC = () => {
  const { isDark } = useTheme();
  const { questions, loading } = useGREQuestions();
  const navigate = useNavigate();
  
  const [questionTypeFilter, setQuestionTypeFilter] = useState<'all' | 'multiple_choice' | 'reading_comprehension'>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');
  const [currentQuestion, setCurrentQuestion] = useState<GREQuestion | null>(null);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isLoadingQuestion, setIsLoadingQuestion] = useState(false);
  const [practiceMode, setPracticeMode] = useState<'random' | 'sequential'>('random');
  
  // 过滤题目池
  const getFilteredQuestions = () => {
    let filtered = questions;
    
    // 按类型过滤
    if (questionTypeFilter !== 'all') {
      filtered = filtered.filter(q => q.type === questionTypeFilter);
    }
    
    // 按难度过滤
    if (difficultyFilter !== 'all') {
      filtered = filtered.filter(q => q.difficulty === difficultyFilter);
    }
    
    return filtered;
  };
  
  // 加载下一个题目
  const loadNextQuestion = () => {
    const filteredQuestions = getFilteredQuestions();
    
    if (filteredQuestions.length === 0) {
      toast.warning("没有符合条件的题目");
      return;
    }
    
    setIsLoadingQuestion(true);
    
    try {
      // 随机选择题目
      const randomIndex = Math.floor(Math.random() * filteredQuestions.length);
      const question = filteredQuestions[randomIndex];
      
      setCurrentQuestion(question);
      setSelectedAnswer(null);
      setShowResult(false);
      
      // 滚动到题目顶部
      setTimeout(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 100);
    } catch (error) {
      console.error('加载题目失败:', error);
      toast.error("加载题目失败");
    } finally {
      setIsLoadingQuestion(false);
    }
  };
  
  // 处理答案选择
  const handleAnswerSelect = (optionId: string) => {
    if (!showResult) {
      setSelectedAnswer(optionId);
    }
  };
  
  // 提交答案
  const handleSubmitAnswer = () => {
    if (!selectedAnswer) {
      toast.warning("请先选择答案");
      return;
    }
    
    setShowResult(true);
  };
  
  // 重置练习
  const handleReset = () => {
    setCurrentQuestion(null);
    setSelectedAnswer(null);
    setShowResult(false);
  };
  
  // 获取题目类型显示名称
  const getQuestionTypeLabel = (type: string) => {
    switch (type) {
      case 'multiple_choice':
        return '选择题';
      case 'reading_comprehension':
        return '阅读题';
      default:
        return '未知类型';
    }
  };
  
  // 获取难度显示名称
  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return '简单';
      case 'medium':
        return '中等';
      case 'hard':
        return '困难';
      default:
        return '未知难度';
    }
  };
  
  // 获取难度对应的样式
  const getDifficultyStyle = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-600/20 text-green-400';
      case 'medium':
        return 'bg-amber-600/20 text-amber-400';
      case 'hard':
        return 'bg-red-600/20 text-red-400';
      default:
        return 'bg-gray-600/20 text-gray-400';
    }
  };
  
  // 检查答案是否正确
  const isAnswerCorrect = (optionId: string) => {
    if (!currentQuestion) return false;
    
    // 如果是选择题，检查选项是否标记为正确
    if (currentQuestion.type === 'multiple_choice' && currentQuestion.options) {
      return currentQuestion.options.some(o => o.id === optionId && o.isCorrect);
    }
    
    // 对于阅读题，这里简化处理
    return optionId === currentQuestion.correctAnswer;
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/gre-question-bank" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-8">
        <motion.div
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* 页面标题 */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-graduation-cap text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">GRE练习</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              通过练习提高您的GRE考试技能，挑战不同类型和难度的题目
            </p>
          </div>
          
          {/* 过滤和控制 */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              {/* 练习模式 */}
              <div className="md:w-1/2">
                <label className="block text-gray-300 mb-2 font-medium">练习模式</label>
                <select
                  value={practiceMode}
                  onChange={(e) => setPracticeMode(e.target.value as any)}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="random">随机练习</option>
                  <option value="sequential">顺序练习</option>
                </select>
              </div>
              
              {/* 类型过滤 */}
              <div className="md:w-1/2">
                <label className="block text-gray-300 mb-2 font-medium">题目类型</label>
                <select
                  value={questionTypeFilter}
                  onChange={(e) => setQuestionTypeFilter(e.target.value as any)}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">所有类型</option>
                  <option value="multiple_choice">选择题</option>
                  <option value="reading_comprehension">阅读题</option>
                </select>
              </div>
              
              {/* 难度过滤 */}
              <div className="md:w-1/2">
                <label className="block text-gray-300 mb-2 font-medium">难度</label>
                <select
                  value={difficultyFilter}
                  onChange={(e) => setDifficultyFilter(e.target.value as any)}
                  className="w-full px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">所有难度</option>
                  <option value="easy">简单</option>
                  <option value="medium">中等</option>
                  <option value="hard">困难</option>
                </select>
              </div>
              
              {/* 开始练习按钮 */}
              <div className="md:w-1/2 flex items-end">
                <motion.button
                  onClick={loadNextQuestion}
                  className="w-full px-6 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium"
                  whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
                  whileTap={{ scale: 0.97 }}
                  disabled={isLoadingQuestion || (currentQuestion && !showResult)}
                >
                  {isLoadingQuestion ? "加载中..." : "开始练习"}
                </motion.button>
              </div>
            </div>
          </div>
          
          {/* 题目显示区域 */}
          {currentQuestion ? (
            <motion.div
              className="rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg p-6 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* 题目信息 */}
              <div className="flex flex-wrap justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyStyle(currentQuestion.difficulty)}`}>
                    {getDifficultyLabel(currentQuestion.difficulty)}
                  </span>
                  <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-gray-300">
                    {getQuestionTypeLabel(currentQuestion.type)}
                  </span>
                </div>
                
                <motion.button
                  onClick={handleReset}
                  className="mt-2 px-3 py-1 text-sm rounded-lg bg-red-600/20 text-red-400 hover:bg-red-600/40 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <i className="fas fa-redo-alt mr-1"></i> 重新开始
                </motion.button>
              </div>
              
              {/* 阅读文章（仅阅读题显示） */}
              {currentQuestion.passage && (
                <div className="mb-6 p-4 rounded-lg bg-white/5 border border-white/10">
                  <p className="text-gray-300">{currentQuestion.passage}</p>
                </div>
              )}
              
              {/* 题目内容 */}
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-white mb-4">{currentQuestion.content}</h2>
              </div>
              
              {/* 选项 */}
              {currentQuestion.options && (
                <div className="space-y-3 mb-8">
                  {currentQuestion.options.map((option) => {
                    const isSelected = selectedAnswer === option.id;
                    const isCorrect = isAnswerCorrect(option.id);
                    const showCorrectness = showResult;
                    
                    let optionClass = "flex items-start gap-3 p-4 rounded-lg border transition-colors cursor-pointer";
                    
                    if (!showResult) {
                      optionClass += isSelected ? " bg-indigo-900/30 border-indigo-700 text-white" : " bg-white/5 border-white/10 text-gray-300 hover:bg-white/10";
                    } else {
                      if (isSelected && isCorrect) {
                        optionClass += " bg-green-900/30 border-green-700 text-white";
                      } else if (isSelected && !isCorrect) {
                        optionClass += " bg-red-900/30 border-red-700 text-white";
                      } else if (isCorrect) {
                        optionClass += " bg-green-900/30 border-green-700 text-white";
                      } else {
                        optionClass += " bg-white/5 border-white/10 text-gray-400";
                      }
                    }
                    
                    return (
                      <motion.div
                        key={option.id}
                        className={optionClass}
                        onClick={() => handleAnswerSelect(option.id)}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        style={{ cursor: !showResult ? 'pointer' : 'default' }}
                      >
                        <div className={`inline-flex items-center justify-center w-8 h-8 rounded-full flex-shrink-0 ${
                          showResult 
                            ? isCorrect 
                              ? 'bg-green-600 text-white' 
                              : isSelected 
                                ? 'bg-red-600 text-white' 
                                : 'bg-gray-700 text-gray-300'
                            : isSelected 
                              ? 'bg-indigo-600 text-white' 
                              : 'bg-gray-700 text-gray-300'
                        }`}>
                          {option.id.toUpperCase()}
                        </div>
                        <div className="flex-grow">
                          <p>{option.text}</p>
                          {showResult && isCorrect && (
                            <motion.div
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.3 }}
                              className="mt-2 text-green-400 text-sm"
                            >
                              <i className="fas fa-check-circle mr-1"></i> 正确答案
                            </motion.div>
                          )}
                          {showResult && isSelected && !isCorrect && (
                            <motion.div
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.3 }}
                              className="mt-2 text-red-400 text-sm"
                            >
                              <i className="fas fa-times-circle mr-1"></i> 错误答案
                            </motion.div>
                          )}
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
              
              {/* 操作按钮 */}
              {!showResult ? (
                <div className="flex justify-center">
                  <motion.button
                    onClick={handleSubmitAnswer}
                    className="px-8 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium"
                    whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
                    whileTap={{ scale: 0.97 }}
                    disabled={!selectedAnswer}
                  >
                    提交答案
                  </motion.button>
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="mt-6"
                >
                  {/* 解析 */}
                  {currentQuestion.explanation && (
                    <div className="mb-6 p-4 rounded-lg bg-white/5 border border-white/10">
                      <h3 className="text-lg font-semibold text-white mb-2">解析</h3>
                      <p className="text-gray-300">{currentQuestion.explanation}</p>
                    </div>
                  )}
                  
                  <div className="flex justify-center">
                    <motion.button
                      onClick={loadNextQuestion}
                      className="px-8 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium"
                      whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
                      whileTap={{ scale: 0.97 }}
                    >
                      下一题
                    </motion.button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          ) : (
            <motion.div
              className="rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg p-10 text-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
                <i className="fas fa-question-circle text-3xl"></i>
              </div>
              <h2 className="text-2xl font-bold text-white mb-4">开始您的GRE练习</h2>
              <p className="text-gray-300 mb-8 max-w-xl mx-auto">
                选择题目类型和难度，然后点击"开始练习"按钮开始挑战。系统会为您随机选择符合条件的题目。
              </p>
              <motion.button
                onClick={loadNextQuestion}
                className="px-8 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium"
                whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
                whileTap={{ scale: 0.97 }}
              >
                开始练习
              </motion.button>
            </motion.div>
          )}
          
          {/* 返回按钮 */}
          <div className="mt-12 p-4 text-center">
            <Link 
              to="/gre-question-bank" 
              className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <i className="fas fa-arrow-left"></i>
              <span>返回题库</span>
            </Link>
          </div>
        </motion.div>
      </div>
      
      {/* 页脚 */}
      <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | GRE题库系统</p>
      </footer>
    </div>
  );
};

export default GREQuestionPracticePage;