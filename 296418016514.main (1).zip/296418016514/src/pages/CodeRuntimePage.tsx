import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '../hooks/useTheme';
import { useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import NavigationBar from '../components/NavigationBar';

export interface CodeRuntimePageProps {
  initialCode?: string;
  language?: string;
}

const CodeRuntimePage: React.FC<CodeRuntimePageProps> = ({ initialCode, language }) => {
  const { isDark } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  
  // 从URL参数中获取初始代码和语言类型
  const queryParams = new URLSearchParams(location.search);
  const codeFromUrl = queryParams.get('code');
  const languageFromUrl = queryParams.get('language') || 'javascript';
  
  const [code, setCode] = useState<string>(initialCode || codeFromUrl || '// 在此输入您的代码\nconsole.log("Hello, World!");');
  const [lang, setLang] = useState<string>(language || languageFromUrl);
  const [isRunning, setIsRunning] = useState(false);
  const [showEditor, setShowEditor] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  
  // 支持的语言类型
  const supportedLanguages = [
    { id: 'javascript', name: 'JavaScript' },
    { id: 'html', name: 'HTML' },
    { id: 'css', name: 'CSS' },
    { id: 'python', name: 'Python (暂不支持直接运行)' },
    { id: 'java', name: 'Java (暂不支持直接运行)' },
    { id: 'typescript', name: 'TypeScript (暂不支持直接运行)' }
  ];

  useEffect(() => {
    // 如果URL中有代码参数，自动运行一次
    if (codeFromUrl) {
      setTimeout(() => {
        handleRunCode();
      }, 1000);
    }
  }, [codeFromUrl]);

  // 处理代码运行
  const handleRunCode = () => {
    if (!iframeRef.current) return;
    
    setIsRunning(true);
    
    try {
      const codeToRun = code;
      const iframeDoc = iframeRef.current.contentDocument;
      if (!iframeDoc) return;
      
      // 根据语言类型创建适合的运行环境
      let htmlContent = '';
      
      switch (lang.toLowerCase()) {
        case 'html':
          htmlContent = codeToRun;
          break;
        case 'javascript':
        case 'js':
          htmlContent = `
            <!DOCTYPE html>
            <html lang="zh-CN">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>JavaScript 运行环境</title>
              <script src="https://cdn.tailwindcss.com"></script>
            </head>
            <body class="bg-gray-50 dark:bg-gray-900 p-4">
              <div id="output" class="mb-4 p-4 bg-white dark:bg-gray-800 rounded-md shadow-sm"></div>
              <script>
                // 重写console.log以便在页面上显示输出
                const originalConsoleLog = console.log;
                const outputElement = document.getElementById('output');
                console.log = function(...args) {
                  originalConsoleLog.apply(console, args);
                  const logElement = document.createElement('div');
                  logElement.className = 'mb-2 text-sm';
                  logElement.textContent = args.map(arg => 
                    typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
                  ).join(' ');
                  outputElement.appendChild(logElement);
                };
                
                // 捕获错误
                window.onerror = function(message, source, lineno, colno, error) {
                  const errorElement = document.createElement('div');
                  errorElement.className = 'mb-2 text-sm text-red-500';
                  errorElement.textContent = \`Error: \${message} at line \${lineno}\`;
                  outputElement.appendChild(errorElement);
                  return true;
                };
                
                // 运行用户代码
                try {
                  ${codeToRun}
                } catch (e) {
                  console.error('代码执行错误:', e);
                }
              </script>
            </body>
            </html>
          `;
          break;
        case 'css':
          htmlContent = `
            <!DOCTYPE html>
            <html lang="zh-CN">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>CSS 运行环境</title>
              <style>
                ${codeToRun}
              </style>
            </head>
            <body>
              <div class="test-element">测试元素 1</div>
              <div class="test-element">测试元素 2</div>
              <div class="test-element">测试元素 3</div>
            </body>
            </html>
          `;
          break;
        default:
          htmlContent = `
            <!DOCTYPE html>
            <html lang="zh-CN">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>代码预览</title>
              <script src="https://cdn.tailwindcss.com"></script>
            </head>
            <body class="bg-gray-50 dark:bg-gray-900 p-4">
              <div class="bg-white dark:bg-gray-800 p-4 rounded-md shadow-sm">
                <pre class="whitespace-pre-wrap font-mono text-sm"><code>${escapeHtml(codeToRun)}</code></pre>
              </div>
              <div class="mt-4 text-gray-500 text-sm">
                当前语言 (${lang}) 不支持直接运行，请下载后在相应环境中运行。
              </div>
            </body>
            </html>
          `;
      }
      
      iframeDoc.open();
      iframeDoc.write(htmlContent);
      iframeDoc.close();
      
      // 显示成功提示
      setTimeout(() => {
        setIsRunning(false);
        toast.success('代码运行成功！');
      }, 1000);
    } catch (error) {
      console.error('运行代码时出错:', error);
      toast.error('代码运行失败，请检查代码是否正确');
      setIsRunning(false);
    }
  };

  // 复制代码到剪贴板
  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(code);
      toast.success('代码已复制到剪贴板');
    } catch (error) {
      console.error('复制失败:', error);
      toast.error('复制失败，请手动复制');
    }
  };

  // 下载代码文件
  const handleDownloadCode = async () => {
    try {
      const fileExtension = getFileExtension(lang);
      const blob = new Blob([code], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `code.${fileExtension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('代码文件已下载');
    } catch (error) {
      console.error('下载失败:', error);
      toast.error('下载失败，请手动复制');
    }
  };

  // 根据语言获取文件扩展名
  const getFileExtension = (language: string): string => {
    const extensionMap: Record<string, string> = {
      'javascript': 'js',
      'js': 'js',
      'typescript': 'ts',
      'ts': 'ts',
      'python': 'py',
      'java': 'java',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'xml': 'xml',
      'sql': 'sql',
      'bash': 'sh',
      'shell': 'sh',
      'markdown': 'md',
      'md': 'md'
    };
    
    return extensionMap[language.toLowerCase()] || 'txt';
  };

  return (
    <div 
      className={`min-h-screen flex flex-col ${isDark ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"}`}
    >
      <NavigationBar currentPage="/code-runtime" />
      
      <div className="container mx-auto px-4 py-6 flex-grow">
        <motion.div 
          className="max-w-7xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-6">
            <h1 className="text-3xl font-bold mb-2">代码运行环境</h1>
            <p className={`${isDark ? "text-gray-400" : "text-gray-600"}`}>在这个环境中编写、运行和测试您的代码</p>
          </div>
          
          {/* 语言选择和工具栏 */}
          <div className="mb-4 p-4 border-b border-gray-200 dark:border-gray-700 flex flex-wrap items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-4">
              <div>
                <label className={`mr-2 text-sm ${isDark ? "text-gray-300" : "text-gray-700"}`}>语言：</label>
                <select 
                  value={lang} 
                  onChange={(e) => setLang(e.target.value)}
                  className={`px-3 py-1.5 rounded-md border ${isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-300"}`}
                >
                  {supportedLanguages.map(l => (
                    <option key={l.id} value={l.id}>{l.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center gap-2">
                <button 
                  className="px-3 py-1.5 rounded-md bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                  onClick={() => setShowEditor(!showEditor)}
                >
                  {showEditor ? '隐藏编辑器' : '显示编辑器'}
                </button>
                
                <button 
                  className="px-3 py-1.5 rounded-md bg-indigo-600 text-white hover:bg-indigo-700 transition-colors"
                  onClick={handleCopyCode}
                >
                  复制代码
                </button>
                
                <button 
                  className="px-3 py-1.5 rounded-md bg-green-600 text-white hover:bg-green-700 transition-colors"
                  onClick={handleDownloadCode}
                >
                  下载代码
                </button>
                
                <button 
                  className="px-3 py-1.5 rounded-md bg-purple-600 text-white hover:bg-purple-700 transition-colors"
                  onClick={() => navigate('/')}
                >
                  返回聊天
                </button>
              </div>
            </div>
            
            <motion.button 
              className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 transition-colors flex items-center gap-2"
              onClick={handleRunCode}
              disabled={isRunning}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isRunning ? (
                <>
                  <i className="fas fa-spinner fa-spin"></i> 运行中...
                </>
              ) : (
                <>
                  <i className="fas fa-play"></i> 运行代码
                </>
              )}
            </motion.button>
          </div>
          
          {/* 代码编辑器和预览区域 */}
          <div className="flex flex-col h-[calc(100vh-200px)]">
            {showEditor && (
              <motion.div 
                className={`mb-4 border rounded-lg overflow-hidden ${isDark ? "border-gray-700" : "border-gray-200"}`}
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <div className={`p-2 bg-gray-100 dark:bg-gray-800 text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                  代码编辑器
                </div>
                <textarea
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className={`w-full h-64 p-4 font-mono text-sm ${isDark ? "bg-gray-900 text-gray-100" : "bg-white text-gray-800"} border-0 outline-none resize-none`}
                  style={{ fontFamily: 'Consolas, Monaco, monospace' }}
                  spellCheck={false}
                />
              </motion.div>
            )}
            
            <div className="flex-1 border rounded-lg overflow-hidden flex flex-col bg-white dark:bg-gray-800">
              <div className={`p-2 bg-gray-100 dark:bg-gray-800 text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"} border-b ${isDark ? "border-gray-700" : "border-gray-200"}`}>
                运行结果
              </div>
              <div className="flex-1 relative overflow-hidden">
                <iframe
                  ref={iframeRef}
                  className="w-full h-full border-0"
                  sandbox="allow-scripts allow-same-origin"
                  title="代码运行环境"
                />
                {!code && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm">
                    <p className={`text-center ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                      请在编辑器中输入代码并点击"运行代码"按钮
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
      
      <footer className={`py-4 border-t mt-auto ${isDark ? "border-gray-800 bg-gray-900" : "border-gray-200 bg-white"}`}>
        <div className="container mx-auto px-4 text-center">
          <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
            © 2025 COREX AI | 代码运行环境
          </p>
        </div>
      </footer>
    </div>
  );
};

// 辅助函数：转义HTML特殊字符
function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export default CodeRuntimePage;