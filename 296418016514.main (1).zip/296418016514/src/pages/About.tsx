import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import AudioPlayer from "../components/AudioPlayer";
import YouTubePlayer from "../components/YouTubePlayer";
import SpotifyPlayer from "../components/SpotifyPlayer";

const About: React.FC = () => {
    const {
        isDark
    } = useTheme();

    const [isLoaded, setIsLoaded] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setIsLoaded(true);

        const handleMouseMove = (e: MouseEvent) => {
            if (!containerRef.current)
                return;

            const {
                left,
                top,
                width,
                height
            } = containerRef.current.getBoundingClientRect();

            const x = (e.clientX - left) / width - 0.5;
            const y = (e.clientY - top) / height - 0.5;
            const gradientElements = containerRef.current.querySelectorAll(".gradient-shift");

            gradientElements.forEach((el: HTMLElement) => {
                el.style.setProperty("--x", `${x * 5}%`);
                el.style.setProperty("--y", `${y * 5}%`);
            });
        };

        document.addEventListener("mousemove", handleMouseMove);

        return () => {
            document.removeEventListener("mousemove", handleMouseMove);
        };
    }, []);

    const handlePlayStateChange = (playing: boolean) => {
        setIsPlaying(playing);
    };

    const containerVariants = {
        hidden: {
            opacity: 0
        },

        visible: {
            opacity: 1,

            transition: {
                staggerChildren: 0.1,
                delayChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: {
            y: 20,
            opacity: 0
        },

        visible: {
            y: 0,
            opacity: 1,

            transition: {
                duration: 0.6,
                ease: "easeOut"
            }
        }
    };

    const features = [{
        icon: "comment-dots",
        title: "智能对话",
        description: "基于先进的AI技术，提供流畅自然的对话体验"
    }, {
        icon: "image",
        title: "图像处理",
        description: "支持图像分析、OCR识别等多种图像处理功能"
    }, {
        icon: "microphone",
        title: "语音识别",
        description: "将音频内容转换成文字，方便进行后续处理"
    }, {
        icon: "search",
        title: "网络搜索",
        description: "集成网络搜索能力，获取最新最全面的信息"
    }];

    return (
        <div
            className="min-h-screen flex flex-col bg-white text-gray-900"
            style={{
                backgroundImage: `
                    radial-gradient(circle at 25% 35%, rgba(168, 85, 247, 0.07) 0%, transparent 50%),
                    radial-gradient(circle at 75% 65%, rgba(139, 92, 246, 0.07) 0%, transparent 50%)
                `,

                backgroundSize: "100% 100%, 100% 100%",
                backgroundColor: "white"
            }}>
            {}
            <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
                {}
                <svg
                    className="absolute top-0 left-0 w-full h-full"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M0,200 Q250,100 500,300 T1000,350 T1500,250 T2000,400"
                        stroke="rgba(168, 85, 247, 0.15)"
                        strokeWidth="2"
                        fill="none"
                        strokeDasharray="10,20"
                        style={{
                            animation: "flowAnimation 30s linear infinite",
                            transform: "translateY(-100px)"
                        }} />
                </svg>
            </div>
            <NavigationBar currentPage="/about" />
            <div
                ref={containerRef}
                className="container mx-auto px-4 py-12 flex-grow relative z-10">
                <motion.div
                    className="max-w-5xl mx-auto"
                    variants={containerVariants}
                    initial="hidden"
                    animate={isLoaded ? "visible" : "hidden"}>
                    {}
                    <motion.div
                        className="text-center mb-24 pt-16"
                        variants={itemVariants}
                        style={{
                            borderRadius: "16px"
                        }}>
                        {}
                        {}
                        <AudioPlayer
                            src="https://lh-sycdn.kuwo.cn/d6ad9447bc4fbb3d09a489e5ca2396e6/636f5303/resource"
                            fallbackSrc="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                            autoPlay={false}
                            volume={0.3}
                            loop={true}
                            className="fixed bottom-8 right-8"
                            onPlayStateChange={handlePlayStateChange} />
                        {}
                        <></>
                        <h1 className="text-5xl md:text-6xl font-bold mb-6">No need to ask
                                                    <br />
                            <span
                                className="bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-purple-700"
                                style={{
                                    fontWeight: "bold"
                                }}>I'm a smooth operator</span>
                        </h1>
                        {}
                        <motion.div
                            className="my-12 max-w-2xl mx-auto"
                            initial={{
                                opacity: 0,
                                y: 20
                            }}
                            animate={{
                                opacity: 1,
                                y: 0
                            }}
                            transition={{
                                delay: 1.5,
                                duration: 0.5
                            }}>
                            {}
                            <SpotifyPlayer
                                spotifyEmbedUrl="https://open.spotify.com/embed/track/1Hv1VTm8zeOeybub15mA2R?utm_source=generator&autoplay=true"
                                width="100%"
                                height="152"
                                className="w-full"
                                autoPlay={true}
                                onLoad={() => console.log("Spotify播放器已加载")} />
                        </motion.div>
                        {}
                        <motion.div
                            className="my-12 max-w-2xl mx-auto"
                            initial={{
                                opacity: 0,
                                y: 20
                            }}
                            animate={{
                                opacity: 0,
                                y: 0
                            }}
                            style={{
                                display: "none"
                            }}>
                            <YouTubePlayer videoId="4TYv2PhG89A" title="示例视频标题" className="w-full" />
                        </motion.div>
                        <></>
                    </motion.div>
                    {}
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-24"
                        variants={containerVariants}>
                        {features.slice(0, 2).map((feature, index) => <motion.div
                            key={index}
                            className="p-8 rounded-xl transition-all duration-300 border relative overflow-hidden group bg-white shadow-lg border-purple-100 hover:border-purple-200"
                            style={{
                                backgroundImage: "radial-gradient(circle at center, rgba(168, 85, 247, 0.05) 0%, transparent 70%)"
                            }}
                            variants={itemVariants}
                            whileHover={{
                                y: -5,
                                boxShadow: "0 20px 25px -5px rgba(168, 85, 247, 0.1), 0 10px 10px -5px rgba(168, 85, 247, 0.05)",
                                borderColor: "rgba(168, 85, 247, 0.5)"
                            }}
                            transition={{
                                type: "spring",
                                stiffness: 300,
                                damping: 20
                            }}>
                            {}
                            <div className="absolute top-0 right-0 w-40 h-40 -mr-20 -mt-20 opacity-10">
                                <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        fill="#A855F7"
                                        d="M44.8,-74.2C58.4,-69.2,70,-56.9,77.2,-42.5C84.3,-28.2,87.1,-11.9,85.7,3.1C84.2,18.2,78.5,32.2,69.3,44.3C60.1,56.3,47.4,66.4,33.1,72.8C18.8,79.3,2.8,82,-12.1,80.8C-27,79.7,-41.8,74.7,-54.4,65.4C-66.9,56.1,-77.3,42.4,-83.6,27.2C-89.9,12,-92,4.4,-89.7,-2.7C-87.4,-9.7,-80.6,-16.1,-72.3,-22.9C-64.1,-29.7,-54.3,-36.9,-43.1,-42.8C-31.9,-48.7,-19.3,-53.2,-5.5,-56C8.3,-58.8,22.9,-59.8,36.9,-57.4C51,-55,64.4,-49.2,70.9,-39.8C77.5,-30.4,77.2,-17.3,76.9,-4.1C76.5,9.1,76.1,22.3,70.5,33.6C64.8,44.8,54.1,54.1,41.2,59.4C28.3,64.7,14.1,66,-0.7,68.1C-15.6,70.2,-31.2,73.1,-43.9,68.8C-56.6,64.5,-66.4,53,-73.9,40C-81.3,26.9,-86.4,12.4,-86.4,-1.4C-86.4,-15.3,-81.3,-28.5,-72.8,-40.4C-64.3,-52.3,-52.3,-63,-38.9,-68.9C-25.5,-74.7,-10.8,-75.7,2.9,-76.9C16.7,-78.2,26.8,-81.8,44.8,-74.2Z"
                                        transform="translate(100 100)" />
                                </svg>
                            </div>
                            <div className="relative z-10">
                                <h3 className="text-2xl font-semibold mb-4 flex items-center">
                                    <span
                                        className="inline-flex items-center justify-center w-10 h-10 mr-3 rounded-full bg-purple-500/20 text-purple-600">
                                        <i className={`fas fa-${feature.icon} text-lg`}></i>
                                    </span>
                                    {index === 0 ? "COREX AI" : "COREX 开放平台"}
                                </h3>
                                <p className="text-gray-600 mb-6">
                                    {index === 0 ? "一款AI智能助手，由COREX自研的大语言模型驱动，支持在线搜索、深度思考、多模态推理和超长文本对话。" : "开放平台支持灵活的API调用，轻松完成对接，让您的程序拥有领先体验。"}
                                </p>
                                <motion.button
                                    className="px-6 py-3 rounded-lg bg-gradient-to-r from-purple-500 to-purple-700 text-white font-medium flex items-center justify-center w-full hover:from-purple-600 hover:to-purple-800 transition-all"
                                    whileHover={{
                                        scale: 1.02,
                                        boxShadow: "0 0 15px rgba(168, 85, 247, 0.4)"
                                    }}
                                    whileTap={{
                                        scale: 0.98
                                    }}>立即体验
                                                                                                                                                                                                                                                                                                    <i className="fas fa-arrow-right ml-2"></i>
                                </motion.button>
                            </div>
                        </motion.div>)}
                    </motion.div>
                    {}
                    <motion.div className="mb-24 px-8" variants={itemVariants}>
                        <div className="max-w-3xl mx-auto text-center">
                            <h2 className="text-3xl font-bold mb-6">品牌理念</h2>
                            <p className="text-gray-600 text-lg leading-relaxed">COREX致力于打造最先进的AI技术，将能源转化为智能，
                                                                                                                                                                                                                                                                为用户提供卓越的智能交互体验，赋能各行各业实现智能化转型。
                                                                                                                                                                                                                                                            </p>
                            <div
                                className="w-20 h-1 bg-gradient-to-r from-purple-500 to-purple-700 mx-auto my-8 rounded-full"></div>
                            <p className="text-gray-600 text-lg leading-relaxed">我们的技术团队由来自国内外顶尖高校和科技公司的AI专家组成，
                                                                                                                                                                                                                                                                在大语言模型、多模态交互和机器学习领域拥有丰富的经验。
                                                                                                                                                                                                                                                            </p>
                        </div>
                    </motion.div>
                </motion.div>
            </div>
            {}
            <footer
                className="py-8 border-t bg-white border-purple-100 text-gray-600 mt-auto">
                <div className="container mx-auto px-4 text-center">
                    <div className="flex justify-center mb-4 space-x-6">
                        <a href="#" className="hover:text-purple-600 transition-colors">隐私政策</a>
                        <a href="#" className="hover:text-purple-600 transition-colors">使用条款</a>
                        <a href="#" className="hover:text-purple-600 transition-colors">常见问题</a>
                    </div>
                    <div className="flex justify-center mb-6 space-x-4">
                        <motion.a
                            href="#"
                            className="w-10 h-10 rounded-full flex items-center justify-center bg-purple-50 text-purple-600 hover:text-white hover:bg-purple-600 transition-all"
                            whileHover={{
                                scale: 1.1
                            }}
                            whileTap={{
                                scale: 0.9
                            }}>
                            <i className="fab fa-weixin"></i>
                        </motion.a>
                        <motion.a
                            href="#"
                            className="w-10 h-10 rounded-full flex items-center justify-center bg-purple-50 text-purple-600 hover:text-white hover:bg-purple-600 transition-all"
                            whileHover={{
                                scale: 1.1
                            }}
                            whileTap={{
                                scale: 0.9
                            }}>
                            <i className="fab fa-github"></i>
                        </motion.a>
                        <motion.a
                            href="#"
                            className="w-10 h-10 rounded-full flex items-center justify-center bg-purple-50 text-purple-600 hover:text-white hover:bg-purple-600 transition-all"
                            whileHover={{
                                scale: 1.1
                            }}
                            whileTap={{
                                scale: 0.9
                            }}>
                            <i className="fab fa-twitter"></i>
                        </motion.a>
                    </div>
                    <p>© 2025 COREX AI. 保留所有权利。</p>
                </div>
            </footer>
        </div>
    );
};

export default About;