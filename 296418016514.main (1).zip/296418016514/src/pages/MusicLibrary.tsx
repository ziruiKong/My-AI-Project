import { useState } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";

// 定义音乐项类型
interface MusicTrack {
  id: string;
  title: string;
  artist: string;
  src: string;
  coverUrl: string;
}

const MusicLibrary: React.FC = () => {
  const { isDark } = useTheme();
  const [currentTrack, setCurrentTrack] = useState<MusicTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioRef] = useState<HTMLAudioElement>(new Audio());

  // 模拟音乐列表数据
  const musicTracks: MusicTrack[] = [
    {
      id: "1",
      title: "示例音乐 1",
      artist: "SoundHelix",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      coverUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=music%20album%20cover%20electronic%20music%20purple%20theme&sign=d72d723ce051bcabb4741019e67ce9d6"
    },
    {
      id: "2",
      title: "示例音乐 2",
      artist: "SoundHelix",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
      coverUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=music%20album%20cover%20jazz%20music%20blue%20theme&sign=78d6f9bf219fc030ffd4f210b88372be"
    },
    {
      id: "3",
      title: "示例音乐 3",
      artist: "SoundHelix",
      src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
      coverUrl: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=music%20album%20cover%20classical%20music%20golden%20theme&sign=4b2f73dd0827261a51f86e0f135023d1"
    }
  ];

  // 处理播放/暂停
  const togglePlay = (track: MusicTrack) => {
    // 如果点击的是当前播放的曲目，则切换播放/暂停状态
    if (currentTrack?.id === track.id) {
      if (isPlaying) {
        audioRef.pause();
      } else {
        audioRef.play();
      }
      setIsPlaying(!isPlaying);
    } else {
      // 否则，切换到新曲目并播放
      audioRef.src = track.src;
      audioRef.play();
      setCurrentTrack(track);
      setIsPlaying(true);
    }
  };

  // 格式化时间显示
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // 更新播放进度
  const handleTimeUpdate = () => {
    // 这里可以实现进度条更新逻辑
  };

  // 初始化音频事件监听
  audioRef.addEventListener('ended', () => {
    setIsPlaying(false);
  });

  audioRef.addEventListener('timeupdate', handleTimeUpdate);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{
      background: isDark ? "#0f172a" : "#ffffff",
      color: isDark ? "#f8fafc" : "#2d3748"
    }}>
      <NavigationBar currentPage="/music" />
      
      <div className="container mx-auto px-4 py-12 flex-grow">
        <motion.div 
          className="max-w-4xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.h1 
            className="text-4xl font-bold mb-8 text-center"
            variants={itemVariants}
          >
            音乐库
          </motion.h1>
          
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={containerVariants}
          >
            {musicTracks.map(track => (
              <motion.div
                key={track.id}
                className={`rounded-xl overflow-hidden shadow-lg border ${
                  isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
                } hover:shadow-xl transition-all`}
                variants={itemVariants}
                whileHover={{ y: -5 }}
              >
                <div className="relative">
                  <img 
                    src={track.coverUrl} 
                    alt={track.title}
                    className="w-full h-48 object-cover"
                  />
                  <motion.button
                    className={`absolute bottom-4 right-4 p-3 rounded-full ${
                      isDark ? 'bg-purple-600' : 'bg-purple-500'
                    } text-white shadow-lg`}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => togglePlay(track)}
                  >
                    {currentTrack?.id === track.id && isPlaying ? 
                      <i className="fas fa-pause"></i> : 
                      <i className="fas fa-play"></i>
                    }
                  </motion.button>
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-1">{track.title}</h3>
                  <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{track.artist}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
          
          {/* 当前播放信息 */}
          {currentTrack && (
            <motion.div
              className={`mt-8 p-4 rounded-xl border ${
                isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
              } flex items-center`}
              variants={itemVariants}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <img 
                src={currentTrack.coverUrl} 
                alt={currentTrack.title}
                className="w-16 h-16 object-cover rounded-md mr-4"
              />
              <div className="flex-1">
                <h3 className="text-lg font-semibold">{currentTrack.title}</h3>
                <p className={`${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{currentTrack.artist}</p>
              </div>
              <motion.button
                className={`p-3 rounded-full ${
                  isDark ? 'bg-purple-600' : 'bg-purple-500'
                } text-white`}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => togglePlay(currentTrack)}
              >
                {isPlaying ? <i className="fas fa-pause"></i> : <i className="fas fa-play"></i>}
              </motion.button>
            </motion.div>
          )}
        </motion.div>
      </div>
      
      <footer className="py-6 text-center" style={{
        borderTop: isDark ? '1px solid #334155' : '1px solid #e2e8f0'
      }}>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          © 2025 音乐库示例 | 仅供演示使用
        </p>
      </footer>
    </div>
  );
};

export default MusicLibrary;