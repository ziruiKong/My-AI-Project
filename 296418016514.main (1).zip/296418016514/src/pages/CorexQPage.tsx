import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useNavigate } from "react-router-dom";

interface Particle {
    x: number;
    y: number;
    radius: number;
    color: string;
    velocityX: number;
    velocityY: number;
    shape: "circle" | "square" | "triangle" | "star";
    pulseRate?: number;
    pulseTime?: number;
}

const CorexQPage: React.FC = () => {
    const {
        isDark
    } = useTheme();

    const navigate = useNavigate();
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const animationRef = useRef<number>();
    const particlesRef = useRef<Particle[]>([]);
    const [language, setLanguage] = useState<"zh" | "en">("zh");

    useEffect(() => {
        const initParticles = () => {
            const canvas = canvasRef.current;

            if (!canvas)
                return;

            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            particlesRef.current = [];
            const particleCount = 800;
            const shapes: ("circle" | "square" | "triangle" | "star")[] = ["circle", "square", "triangle", "star"];

            const colors = [
                `rgba(255, 255, 255, 0.8)`,
                `rgba(168, 85, 247, 0.7)`,
                `rgba(99, 102, 241, 0.6)`,
                `rgba(139, 92, 246, 0.5)`
            ];

            for (let i = 0; i < particleCount; i++) {
                const x = Math.random() * canvas.width;
                const y = Math.random() * canvas.height;
                const radius = Math.random() * 2 + 0.3;
                const color = colors[Math.floor(Math.random() * colors.length)];
                const velocityX = (Math.random() - 0.5) * 0.8;
                const velocityY = (Math.random() - 0.5) * 0.8;
                const shape = shapes[Math.floor(Math.random() * shapes.length)];
                const pulseRate = Math.random() > 0.7 ? Math.random() * 0.05 + 0.01 : 0;
                const pulseTime = Math.random() * 1000;

                particlesRef.current.push({
                    x,
                    y,
                    radius,
                    color,
                    velocityX,
                    velocityY,
                    shape,
                    pulseRate,
                    pulseTime
                });
            }
        };

        const animate = () => {
            const canvas = canvasRef.current;

            if (!canvas)
                return;

            const ctx = canvas.getContext("2d");

            if (!ctx)
                return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);

            particlesRef.current.forEach(particle => {
                particle.x += particle.velocityX;
                particle.y += particle.velocityY;

                if (particle.x < 0)
                    particle.x = canvas.width;

                if (particle.x > canvas.width)
                    particle.x = 0;

                if (particle.y < 0)
                    particle.y = canvas.height;

                if (particle.y > canvas.height)
                    particle.y = 0;

                if (particle.pulseRate > 0) {
                    const pulseFactor = Math.sin((Date.now() + particle.pulseTime) * particle.pulseRate);
                    const currentRadius = particle.radius * (1 + pulseFactor * 0.3);

                    if (particle.shape === "circle") {
                        ctx.beginPath();
                        ctx.arc(particle.x, particle.y, currentRadius, 0, Math.PI * 2);
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    } else if (particle.shape === "square") {
                        ctx.fillStyle = particle.color;

                        ctx.fillRect(
                            particle.x - currentRadius,
                            particle.y - currentRadius,
                            currentRadius * 2,
                            currentRadius * 2
                        );
                    } else if (particle.shape === "triangle") {
                        ctx.beginPath();
                        ctx.moveTo(particle.x, particle.y - currentRadius);
                        ctx.lineTo(particle.x - currentRadius, particle.y + currentRadius);
                        ctx.lineTo(particle.x + currentRadius, particle.y + currentRadius);
                        ctx.closePath();
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    } else if (particle.shape === "star") {
                        ctx.beginPath();

                        for (let i = 0; i < 5; i++) {
                            const angle = i * 2 * Math.PI / 5 - Math.PI / 2;
                            const outerX = particle.x + Math.cos(angle) * currentRadius;
                            const outerY = particle.y + Math.sin(angle) * currentRadius;

                            if (i === 0) {
                                ctx.moveTo(outerX, outerY);
                            } else {
                                ctx.lineTo(outerX, outerY);
                            }

                            const innerX = particle.x + Math.cos(angle + Math.PI / 5) * currentRadius * 0.5;
                            const innerY = particle.y + Math.sin(angle + Math.PI / 5) * currentRadius * 0.5;
                            ctx.lineTo(innerX, innerY);
                        }

                        ctx.closePath();
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    }
                } else {
                    if (particle.shape === "circle") {
                        ctx.beginPath();
                        ctx.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    } else if (particle.shape === "square") {
                        ctx.fillStyle = particle.color;

                        ctx.fillRect(
                            particle.x - particle.radius,
                            particle.y - particle.radius,
                            particle.radius * 2,
                            particle.radius * 2
                        );
                    } else if (particle.shape === "triangle") {
                        ctx.beginPath();
                        ctx.moveTo(particle.x, particle.y - particle.radius);
                        ctx.lineTo(particle.x - particle.radius, particle.y + particle.radius);
                        ctx.lineTo(particle.x + particle.radius, particle.y + particle.radius);
                        ctx.closePath();
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    } else if (particle.shape === "star") {
                        ctx.beginPath();

                        for (let i = 0; i < 5; i++) {
                            const angle = i * 2 * Math.PI / 5 - Math.PI / 2;
                            const outerX = particle.x + Math.cos(angle) * particle.radius;
                            const outerY = particle.y + Math.sin(angle) * particle.radius;

                            if (i === 0) {
                                ctx.moveTo(outerX, outerY);
                            } else {
                                ctx.lineTo(outerX, outerY);
                            }

                            const innerX = particle.x + Math.cos(angle + Math.PI / 5) * particle.radius * 0.5;
                            const innerY = particle.y + Math.sin(angle + Math.PI / 5) * particle.radius * 0.5;
                            ctx.lineTo(innerX, innerY);
                        }

                        ctx.closePath();
                        ctx.fillStyle = particle.color;
                        ctx.fill();
                    }
                }
            });

            animationRef.current = requestAnimationFrame(animate);
        };

        const handleResize = () => {
            initParticles();
        };

        initParticles();
        animate();
        window.addEventListener("resize", handleResize);

        return () => {
            window.removeEventListener("resize", handleResize);

            if (animationRef.current) {
                cancelAnimationFrame(animationRef.current);
            }
        };
    }, []);

    const toggleLanguage = () => {
        setLanguage(language === "zh" ? "en" : "zh");
    };

    const businessSections = [{
        id: 1,

        title: {
            zh: "萤火",
            en: "FIRE-FLYER"
        },

        description: {
            zh: "以分时调度共享 AI 算力，弹性运行超大规模深度学习训练",
            en: "Shared AI computing power with time-sharing scheduling, elastically running ultra-large-scale deep learning training"
        }
    }, {
        id: 2,

        title: {
            zh: "幻方量化",
            en: "HIGH-FLYER QUANT"
        },

        description: {
            zh: "使用 AI 进行投资的对冲基金",
            en: "Hedge fund that uses AI for investment"
        }
    }, {
        id: 3,

        title: {
            zh: "幻方AI科研",
            en: "HIGH-FLYER AI RESEARCH"
        },

        description: {
            zh: "AI 基础科学研究",
            en: "Basic AI science research"
        }
    }];

    return (
        <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
            {}
            {}
            <div
                className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
            <canvas ref={canvasRef} className="fixed inset-0 z-0 pointer-events-none" />
            {}
            <motion.button
                className="fixed top-4 right-4 z-50 px-3 py-1 text-sm text-white bg-gray-800/50 backdrop-blur-sm rounded-full hover:bg-gray-700/50 transition-colors"
                whileHover={{
                    scale: 1.05
                }}
                whileTap={{
                    scale: 0.95
                }}
                onClick={toggleLanguage}>
                {language === "zh" ? "中文 / EN" : "Chinese / 英文"}
            </motion.button>
            {}
            <NavigationBar currentPage="/q" />
            {}
            <div
                className="flex-grow relative z-10 flex flex-col items-center justify-center px-4 py-8">
                <motion.div
                    className="max-w-6xl mx-auto text-center"
                    initial={{
                        opacity: 0
                    }}
                    animate={{
                        opacity: 1
                    }}
                    transition={{
                        duration: 1.5
                    }}>
                    {}
                    <motion.h1
                        className="text-4xl md:text-6xl font-bold mb-6 text-white tracking-wider"
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        transition={{
                            duration: 1,
                            delay: 0.2
                        }}
                        style={{
                            fontFamily: "\"Noto Sans SC\", sans-serif",
                            fontWeight: "bold"
                        }}>理性算法化为流畅智慧
                                                                                                                                                                                                                                                                                                                                            </motion.h1>
                    <motion.h2
                        className="text-2xl md:text-4xl font-bold text-white mb-12"
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        transition={{
                            duration: 1,
                            delay: 0.4
                        }}
                        style={{
                            fontFamily: "\"Noto Serif SC\", serif",
                            fontWeight: "normal",
                            fontSize: "24px"
                        }}>
                        {language === "zh" ? "在市场波动中，于核心处精准取胜" : "Precisely Winning at the Core Amid Market Fluctuations"}
                    </motion.h2>
                    {}
                    <motion.div
                        className="inline-flex items-center justify-center mb-20"
                        initial={{
                            opacity: 0
                        }}
                        animate={{
                            opacity: 1
                        }}
                        transition={{
                            duration: 1,
                            delay: 0.8
                        }}>
                        <div
                            className="flex items-center justify-center mr-3"
                            style={{
                                borderRadius: "16px",
                                backgroundColor: "transparent",
                                minWidth: "150px",
                                height: "40px"
                            }}>
                            <span
                                className="text-indigo-900 font-bold text-xl"
                                style={{
                                    fontSize: "24px",
                                    fontFamily: "\"Noto Serif SC\", serif",
                                    fontWeight: "bold",
                                    color: "#FFFFFF",
                                    whiteSpace: "nowrap",
                                    display: "inline-block"
                                }}>COREX | Q</span>
                        </div>
                        <></>
                    </motion.div>
                    {}
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto"
                        variants={{
                            hidden: {
                                opacity: 0
                            },

                            visible: {
                                opacity: 1,

                                transition: {
                                    staggerChildren: 0.2
                                }
                            }
                        }}
                        initial="hidden"
                        animate="visible"
                        transition={{
                            delay: 1.2
                        }}>
                        {}
                        <motion.a
                            href={window.location.pathname.includes("/runtime") ? "/runtime/q/quant-strategy-home" : "/q/quant-strategy-home"}
                            className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-indigo-500/10 transition-all duration-500"
                            variants={{
                                hidden: {
                                    opacity: 0,
                                    y: 30
                                },

                                visible: {
                                    opacity: 1,
                                    y: 0,

                                    transition: {
                                        duration: 0.8
                                    }
                                }
                            }}
                            whileHover={{
                                y: -5,
                                boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
                                backdropFilter: "blur(20px)"
                            }}
                            whileTap={{
                                scale: 0.98
                            }}
                            style={{
                                textDecoration: "none"
                            }}>
                            {}
                            <div
                                className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none"></div>
                            <div className="relative z-10">
                                <></>
                                <h3
                                    className="text-2xl font-bold mb-3 text-white"
                                    style={{
                                        fontFamily: "\"Noto Serif SC\", serif"
                                    }}>策略</h3>
                                <p className="text-gray-300">基于深度学习的量化模型，分析市场数据，提供精准投资策略</p>
                                <div className="mt-6 inline-flex items-center text-indigo-400 font-medium">
                                    <span>了解更多</span>
                                    <motion.i
                                        className="fas fa-arrow-right ml-2"
                                        animate={{
                                            x: [0, 5, 0]
                                        }}
                                        transition={{
                                            duration: 1.5,
                                            repeat: Infinity,
                                            repeatType: "loop"
                                        }} />
                                </div>
                            </div>
                        </motion.a>
                        {}
                        <motion.a
                            href={window.location.pathname.includes("/runtime") ? "/runtime/q/research" : "/q/research"}
                            className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-purple-500/10 transition-all duration-500"
                            variants={{
                                hidden: {
                                    opacity: 0,
                                    y: 30
                                },

                                visible: {
                                    opacity: 1,
                                    y: 0,

                                    transition: {
                                        duration: 0.8,
                                        delay: 0.2
                                    }
                                }
                            }}
                            whileHover={{
                                y: -5,
                                boxShadow: "0 25px 50px -12px rgba(168, 85, 247, 0.25)",
                                backdropFilter: "blur(20px)"
                            }}
                            whileTap={{
                                scale: 0.98
                            }}
                            style={{
                                textDecoration: "none"
                            }}>
                            {}
                            <div
                                className="absolute -top-24 -right-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>
                            <div className="relative z-10">
                                <></>
                                <h3
                                    className="text-2xl font-bold mb-3 text-white"
                                    style={{
                                        fontFamily: "\"Noto Serif SC\", serif"
                                    }}>研究</h3>
                                <p className="text-gray-300">深入挖掘市场规律，持续优化算法模型，把握投资先机</p>
                                <div className="mt-6 inline-flex items-center text-purple-400 font-medium">
                                    <span>了解更多</span>
                                    <motion.i
                                        className="fas fa-arrow-right ml-2"
                                        animate={{
                                            x: [0, 5, 0]
                                        }}
                                        transition={{
                                            duration: 1.5,
                                            repeat: Infinity,
                                            repeatType: "loop"
                                        }} />
                                </div>
                            </div>
                        </motion.a>
                        {}
                        <motion.a
                            href={window.location.pathname.includes("/runtime") ? "/runtime/q/agent" : "/q/agent"}
                            className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 p-8 shadow-lg hover:shadow-blue-500/10 transition-all duration-500"
                            variants={{
                                hidden: {
                                    opacity: 0,
                                    y: 30
                                },

                                visible: {
                                    opacity: 1,
                                    y: 0,

                                    transition: {
                                        duration: 0.8,
                                        delay: 0.4
                                    }
                                }
                            }}
                            whileHover={{
                                y: -5,
                                boxShadow: "0 25px 50px -12px rgba(79, 70, 229, 0.25)",
                                backdropFilter: "blur(20px)"
                            }}
                            whileTap={{
                                scale: 0.98
                            }}
                            style={{
                                textDecoration: "none"
                            }}>
                            {}
                            <div
                                className="absolute -top-24 -right-24 w-48 h-48 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
                            <div className="relative z-10">
                                <></>
                                <h3
                                    className="text-2xl font-bold mb-3 text-white"
                                    style={{
                                        fontFamily: "\"Noto Serif SC\", serif"
                                    }}>智能体</h3>
                                <p className="text-gray-300">7×24小时监控市场，自动执行交易策略，智能风险管理</p>
                                <div className="mt-6 inline-flex items-center text-blue-400 font-medium">
                                    <span>了解更多</span>
                                    <motion.i
                                        className="fas fa-arrow-right ml-2"
                                        animate={{
                                            x: [0, 5, 0]
                                        }}
                                        transition={{
                                            duration: 1.5,
                                            repeat: Infinity,
                                            repeatType: "loop"
                                        }} />
                                </div>
                            </div>
                        </motion.a>
                    </motion.div>
                </motion.div>
            </div>
            {}
            <footer className="py-6 text-center text-gray-500 text-sm">
                <p>© 2025 COREX 人工智能</p>
            </footer>
        </div>
    );
};

export default CorexQPage;