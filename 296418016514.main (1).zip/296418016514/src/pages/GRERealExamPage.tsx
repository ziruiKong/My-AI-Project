import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useGREQuestions } from "../hooks/useStorage";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "sonner";
import { GREQuestion, GREQuestionOption } from "../lib/StorageService";

// 定义题目类型
interface ExamQuestion {
  id: string;
  content: string;
  questionType: "sentence_equivalence" | "text_completion" | "reading_comprehension";
  instructions: string;
  options: {
    id: string;
    text: string;
    isCorrect?: boolean;
  }[];
  passage?: string;
}

const GRERealExamPage: React.FC = () => {
  const { isDark } = useTheme();
  const { questions: greQuestions, loading } = useGREQuestions();
  const navigate = useNavigate();
  
  // 考试状态
  const [currentSection, setCurrentSection] = useState(2);
  const [totalSections, setTotalSections] = useState(5);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(7); // 0-based index for 8th question
  const [totalQuestionsInSection, setTotalQuestionsInSection] = useState(12);
  const [timeRemaining, setTimeRemaining] = useState(7 * 60 + 36); // 7 minutes 36 seconds
  const [isTimerVisible, setIsTimerVisible] = useState(true);
  const [markedQuestions, setMarkedQuestions] = useState<number[]>([]);
  const [reviewMode, setReviewMode] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  
  // 模拟题目数据
  const [examQuestions, setExamQuestions] = useState<ExamQuestion[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<ExamQuestion | null>(null);
  
  // 加载题目数据
  useEffect(() => {
    if (loading) return;
    
    // 这里我们将使用模拟数据来创建考试题目
    const mockQuestions: ExamQuestion[] = [
      {
        id: "1",
        content: "Because the country's media are now operating freely and the electoral authorities have been changed, there should be no repeat of the _______ of last year's election, when media coverage and vote counts were manipulated by the intelligence agency.",
        questionType: "sentence_equivalence",
        instructions: "Select the two answer choices that, when used to complete the sentence, fit the meaning of the sentence as a whole and produce completed sentences that are alike in meaning.",
        options: [
          { id: "a", text: "chicanery", isCorrect: true },
          { id: "b", text: "blundering", isCorrect: false },
          { id: "c", text: "ingenuousness", isCorrect: false },
          { id: "d", text: "naïveté", isCorrect: false },
          { id: "e", text: "vindictiveness", isCorrect: false },
          { id: "f", text: "subterfuge", isCorrect: true }
        ]
      },
      // 可以添加更多模拟题目
      {
        id: "2",
        content: "The new policy was intended to _______ the economy, but many experts argue that it will only _______ the existing problems.",
        questionType: "text_completion",
        instructions: "For each blank select one entry from the corresponding column of choices. Fill all blanks in the way that best completes the text.",
        options: [
          { id: "a1", text: "stimulate", isCorrect: true },
          { id: "a2", text: "stabilize", isCorrect: false },
          { id: "a3", text: "weaken", isCorrect: false },
          { id: "b1", text: "exacerbate", isCorrect: true },
          { id: "b2", text: "mitigate", isCorrect: false },
          { id: "b3", text: "resolve", isCorrect: false }
        ]
      }
    ];
    
    setExamQuestions(mockQuestions);
    setCurrentQuestion(mockQuestions[currentQuestionIndex]);
  }, [loading, greQuestions]);
  
  // 计时器
  useEffect(() => {
    if (timeRemaining <= 0) {
      return;
    }
    
    const timer = setInterval(() => {
      setTimeRemaining(prev => prev - 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, [timeRemaining]);
  
  // 格式化时间
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // 处理选项选择
  const handleOptionSelect = (optionId: string) => {
    setSelectedOptions(prev => {
      // 对于句子等价题，可以选择两个选项
      if (currentQuestion?.questionType === "sentence_equivalence") {
        if (prev.includes(optionId)) {
          return prev.filter(id => id !== optionId);
        } else if (prev.length < 2) {
          return [...prev, optionId];
        }
        return prev;
      }
      
      // 对于其他题型，只能选择一个选项
      return [optionId];
    });
  };
  
  // 处理标记题目
  const handleMarkQuestion = () => {
    setMarkedQuestions(prev => {
      if (prev.includes(currentQuestionIndex)) {
        return prev.filter(index => index !== currentQuestionIndex);
      } else {
        return [...prev, currentQuestionIndex];
      }
    });
  };
  
  // 处理下一题
  const handleNextQuestion = () => {
    if (currentQuestionIndex < totalQuestionsInSection - 1) {
      setCurrentQuestionIndex(prev => {
        const newIndex = prev + 1;
        setCurrentQuestion(examQuestions[newIndex]);
        setSelectedOptions([]);
        return newIndex;
      });
    }
  };
  
  // 处理上一题
  const handlePrevQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => {
        const newIndex = prev - 1;
        setCurrentQuestion(examQuestions[newIndex]);
        setSelectedOptions([]);
        return newIndex;
      });
    }
  };
  
  // 处理退出部分
  const handleExitSection = () => {
    if (window.confirm("确定要退出当前部分吗？未完成的题目将会被标记为未回答。")) {
      navigate('/gre-question-bank');
    }
  };
  
  // 处理帮助
  const handleHelp = () => {
    toast.info("GRE考试帮助：请仔细阅读题目要求，选择最合适的答案。");
  };
  
  // 切换计时器显示
  const toggleTimerVisibility = () => {
    setIsTimerVisible(!isTimerVisible);
  };
  
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-black text-white">
        <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-xl">加载GRE考试题目...</p>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-100 text-gray-900">
      {/* 顶部导航栏 - 模拟GRE考试界面 */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-2 px-4 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="font-bold text-lg">ETS® GRE®</div>
          <div>GRE® General Test</div>
        </div>
        
        <div className="flex items-center gap-1">
          <button 
            onClick={handleExitSection}
            className="bg-gray-700 hover:bg-gray-600 px-3 py-1 text-sm rounded"
          >
            Exit Section
          </button>
          
          <button 
            onClick={handleMarkQuestion}
            className={`px-3 py-1 text-sm rounded ${markedQuestions.includes(currentQuestionIndex) ? 'bg-yellow-600 hover:bg-yellow-700' : 'bg-gray-700 hover:bg-gray-600'}`}
          >
            Mark
          </button>
          
          <button 
            onClick={() => setReviewMode(!reviewMode)}
            className="bg-gray-700 hover:bg-gray-600 px-3 py-1 text-sm rounded"
          >
            Review
          </button>
          
          <button 
            onClick={handleHelp}
            className="bg-gray-700 hover:bg-gray-600 px-3 py-1 text-sm rounded"
          >
            Help
          </button>
          
          <button 
            onClick={handlePrevQuestion}
            className="bg-blue-700 hover:bg-blue-800 px-3 py-1 text-sm rounded flex items-center gap-1"
            disabled={currentQuestionIndex === 0}
          >
            <i className="fas fa-arrow-left"></i> Back
          </button>
          
          <button 
            onClick={handleNextQuestion}
            className="bg-blue-700 hover:bg-blue-800 px-3 py-1 text-sm rounded flex items-center gap-1"
            disabled={currentQuestionIndex >= totalQuestionsInSection - 1}
          >
            Next <i className="fas fa-arrow-right"></i>
          </button>
        </div>
      </div>
      
      {/* 考试进度和计时器 */}
      <div className="bg-white border-b border-gray-300 py-2 px-4 flex justify-between items-center">
        <div className="text-sm">
          Section {currentSection} of {totalSections} | Question {currentQuestionIndex + 1} of {totalQuestionsInSection}
        </div>
        
        <div className="flex items-center gap-2">
          {isTimerVisible && (
            <div className="text-sm font-bold text-red-600">
              {formatTime(timeRemaining)}
            </div>
          )}
          <button 
            onClick={toggleTimerVisibility}
            className="text-sm text-gray-600 hover:text-gray-900"
          >
            {isTimerVisible ? 'Hide Time' : 'Show Time'}
          </button>
        </div>
      </div>
      
      {/* 主内容区域 */}
      <div className="flex-grow p-8 flex justify-center">
        <div className="w-full max-w-4xl bg-white border border-gray-300 rounded-lg shadow-sm p-6">
          {currentQuestion && (
            <div>
              {/* 题目说明 */}
              <div className="bg-gray-100 p-4 mb-6 rounded border-l-4 border-gray-400 text-sm">
                {currentQuestion.instructions}
              </div>
              
              {/* 阅读文章（如果有） */}
              {currentQuestion.passage && (
                <div className="mb-6">
                  <p className="text-gray-700">{currentQuestion.passage}</p>
                </div>
              )}
              
              {/* 题目内容 */}
              <div className="mb-8">
                <p className="text-lg">{currentQuestion.content}</p>
              </div>
              
              {/* 选项列表 */}
              <div className="space-y-3">
                {currentQuestion.options.map((option) => (
                  <div key={option.id} className="flex items-start gap-3">
                    <div 
                      onClick={() => handleOptionSelect(option.id)}
                      className={`w-5 h-5 mt-0.5 border-2 rounded-sm cursor-pointer flex items-center justify-center ${
                        selectedOptions.includes(option.id) 
                          ? 'border-indigo-600 bg-indigo-600' 
                          : 'border-gray-400 hover:border-gray-600'
                      }`}
                    >
                      {selectedOptions.includes(option.id) && (
                        <i className="fas fa-check text-white text-xs"></i>
                      )}
                    </div>
                    <div className="flex-grow">
                      <p>{option.text}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* 底部导航按钮 */}
              <div className="mt-10 flex justify-between">
                <button 
                  onClick={handlePrevQuestion}
                  className="bg-gray-200 hover:bg-gray-300 px-5 py-2 rounded text-sm flex items-center gap-2"
                  disabled={currentQuestionIndex === 0}
                >
                  <i className="fas fa-arrow-left"></i> Previous
                </button>
                
                <button 
                  onClick={handleNextQuestion}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded text-sm flex items-center gap-2"
                  disabled={currentQuestionIndex >= totalQuestionsInSection - 1}
                >
                  Next <i className="fas fa-arrow-right"></i>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* 页脚 */}
      <footer className="py-4 border-t border-gray-200 text-center text-sm text-gray-600">
        <p>© 2025 COREX 人工智能 | GRE模拟考试</p>
      </footer>
    </div>
  );
};

export default GRERealExamPage;