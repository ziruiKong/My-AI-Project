import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useGREQuestions } from "../hooks/useStorage";
import { Link } from "react-router-dom";
import { toast } from "sonner";

const GREQuestionBankPage: React.FC = () => {
  const { isDark } = useTheme();
  const { 
    questions, 
    loading, 
    getQuestionsByType,
    getQuestionsByDifficulty,
    deleteGREQuestion,
    addGREQuestion,
    getQuestionsByFilter
  } = useGREQuestions();
  
  const [activeTab, setActiveTab] = useState<'all' | 'multiple_choice' | 'reading_comprehension'>('all');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filteredQuestions, setFilteredQuestions] = useState(questions);
  
   // 过滤题目
  useEffect(() => {
    let result = questions;
    
    // 按类型过滤
    if (activeTab !== 'all') {
      result = getQuestionsByType(activeTab);
    }
    
    // 按难度过滤
    if (difficultyFilter !== 'all') {
      result = result.filter(q => q.difficulty === difficultyFilter);
    }
    
    // 按搜索关键词过滤
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(q => 
        q.content.toLowerCase().includes(query) || 
        q.passage?.toLowerCase().includes(query) ||
        q.tags?.some(tag => tag.toLowerCase().includes(query)) ||
        q.explanation?.toLowerCase().includes(query)
      );
    }
    
    setFilteredQuestions(result);
  }, [questions, activeTab, difficultyFilter, searchQuery, getQuestionsByType]);

  // 添加这道GRE阅读题到题库
  useEffect(() => {
    const addSampleQuestion = async () => {
      try {
        // 检查是否已经添加过这道题
        const existingQuestions = await getQuestionsByFilter(q => 
          q.content.includes("The author mentions \"studies of lake and shallow ocean sediments\"")
        );
        
        if (existingQuestions.length === 0) {
          // 创建新的阅读题
          await addGREQuestion({
            type: 'reading_comprehension',
            difficulty: 'medium',
            content: 'The author mentions "studies of lake and shallow ocean sediments" primarily in order to',
            passage: 'Availability and management of water greatly influenced human settlement in the Maya Lowlands, and much of Mayan social innovation was centered on storing excess water for times of need. In northern Yucatán the permanent water table is sufficiently shallow that it can be accessed by natural wells known as cenotes. However, over much of the Maya Lowlands, the water table is too deep to have been available to the Maya. In response, they constructed artificial reservoirs to trap runoff. For example, Gallopin estimates that the reservoirs at Tikal (an ancient Mayan city) could have provided for the domestic needs of about 9,600 people for a period of 6 to 18 months. Even with elaborate water capture and management systems, the Maya were greatly dependent upon adequate rainfall over much of their empire and were thus susceptible to frequent or prolonged droughts that approached or exceeded the capacity of their reservoirs. In fact, evidence of droughts in the region based on studies of lake and shallow ocean sediments has led many researchers to suspect that climate was responsible for the Classic Maya collapse.',
            options: [
              { id: 'a', text: 'describe the results of a novel study', isCorrect: false },
              { id: 'b', text: 'identify the source of evidence that suggested a hypothesis', isCorrect: true },
              { id: 'c', text: 'undermine a conventional explanation', isCorrect: false },
              { id: 'd', text: 'highlight the importance of one type of evidence', isCorrect: false },
              { id: 'e', text: 'clarify the value of a particular undertaking', isCorrect: false }
            ],
            correctAnswer: 'b',
            explanation: 'The author mentions "studies of lake and shallow ocean sediments" as the source of evidence that led researchers to hypothesize that climate was responsible for the Classic Maya collapse.',
            tags: ['reading_comprehension', 'maya_civilization', 'climate_change', 'water_management']
          });
          console.log('GRE阅读题添加成功');
        }
      } catch (error) {
        console.error('添加GRE阅读题失败:', error);
      }
    };
    
    if (typeof window !== 'undefined' && !loading) {
      addSampleQuestion();
    }
  }, [loading, addGREQuestion, getQuestionsByFilter]);
  
  // 处理删除题目
  const handleDeleteQuestion = async (id: string) => {
    if (window.confirm("确定要删除这道题目吗？此操作不可撤销。")) {
      const success = await deleteGREQuestion(id);
      if (success) {
        toast.success("题目删除成功");
      } else {
        toast.error("题目删除失败");
      }
    }
  };
  
  // 获取题目类型显示名称
  const getQuestionTypeLabel = (type: string) => {
    switch (type) {
      case 'multiple_choice':
        return '选择题';
      case 'reading_comprehension':
        return '阅读题';
      default:
        return '未知类型';
    }
  };
  
  // 获取难度显示名称
  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return '简单';
      case 'medium':
        return '中等';
      case 'hard':
        return '困难';
      default:
        return '未知难度';
    }
  };
  
  // 获取难度对应的样式
  const getDifficultyStyle = (difficulty: string) => {
    switch (difficulty) {
      case 'easy':
        return 'bg-green-600/20 text-green-400';
      case 'medium':
        return 'bg-amber-600/20 text-amber-400';
      case 'hard':
        return 'bg-red-600/20 text-red-400';
      default:
        return 'bg-gray-600/20 text-gray-400';
    }
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/gre-question-bank" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-8">
        <motion.div
          className="max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* 页面标题 */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-graduation-cap text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">GRE题库</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              管理和练习GRE考试题目，提高您的考试准备效率
            </p>
          </div>
          
          {/* 操作按钮 */}
           <div className="flex flex-wrap justify-center gap-4 mb-12">
            <motion.Link
              to="/gre-question-bank/add"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-plus"></i>
              添加新题目
            </motion.Link>
            
            <motion.Link
              to="/gre-question-bank/practice"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-medium flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(59, 130, 246, 0.4)" }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-play"></i>
              开始练习
            </motion.Link>
            
            <motion.Link
              to="/gre-question-bank/exam"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-red-600 to-orange-600 text-white font-medium flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(239, 68, 68, 0.4)" }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-file-alt"></i>
              模拟考试
            </motion.Link>
          </div>
          
          {/* 搜索和过滤 */}
          <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="搜索题目内容..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full px-4 py-2 pl-10 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 md:w-auto md:flex md:gap-4">
                {/* 类型过滤 */}
                <select
                  value={activeTab}
                  onChange={(e) => setActiveTab(e.target.value as any)}
                  className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">所有类型</option>
                  <option value="multiple_choice">选择题</option>
                  <option value="reading_comprehension">阅读题</option>
                </select>
                
                {/* 难度过滤 */}
                <select
                  value={difficultyFilter}
                  onChange={(e) => setDifficultyFilter(e.target.value as any)}
                  className="px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="all">所有难度</option>
                  <option value="easy">简单</option>
                  <option value="medium">中等</option>
                  <option value="hard">困难</option>
                </select>
              </div>
            </div>
          </div>
          
          {/* 统计信息 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl p-4">
              <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">总题目数</h3>
              <p className="text-3xl font-bold text-white">{filteredQuestions.length}</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl p-4">
              <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">选择题</h3>
              <p className="text-3xl font-bold text-white">{getQuestionsByType('multiple_choice').length}</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl p-4">
              <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">阅读题</h3>
              <p className="text-3xl font-bold text-white">{getQuestionsByType('reading_comprehension').length}</p>
            </div>
          </div>
          
          {/* 题目列表 */}
          <div className="rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg overflow-hidden">
            {loading ? (
              <div className="flex justify-center items-center h-60">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                  <p className="mt-4 text-gray-300">加载中...</p>
                </div>
              </div>
            ) : filteredQuestions.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-60">
                <i className="fas fa-question-circle text-4xl text-gray-500 mb-4"></i>
                <p className="text-gray-300">暂无题目</p>
                <motion.Link
                  to="/gre-question-bank/add"
                  className="mt-4 px-4 py-2 rounded-lg bg-indigo-600/30 text-indigo-300 hover:bg-indigo-600/50 transition-colors"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  添加题目
                </motion.Link>
              </div>
            ) : (
              <div className="divide-y divide-white/10">
                {filteredQuestions.map((question) => (
                  <motion.div
                    key={question.id}
                    className="p-6 hover:bg-white/5 transition-colors"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    whileHover={{ y: -3 }}
                  >
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
                      <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDifficultyStyle(question.difficulty)}`}>
                            {getDifficultyLabel(question.difficulty)}
                          </span>
                          <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-gray-300">
                            {getQuestionTypeLabel(question.type)}
                          </span>
                          {question.tags && question.tags.length > 0 && (
                            <div className="flex gap-1">
                              {question.tags.slice(0, 3).map((tag, index) => (
                                <span 
                                  key={index} 
                                  className="px-2 py-1 rounded-full text-xs bg-indigo-900/30 text-indigo-300"
                                >
                                  {tag}
                                </span>
                              ))}
                              {question.tags.length > 3 && (
                                <span className="px-2 py-1 rounded-full text-xs bg-gray-800/50 text-gray-400">
                                  +{question.tags.length - 3}
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <h3 className="text-xl font-bold text-white mb-2 line-clamp-2">
                          {question.content}
                        </h3>
                        
                        {question.passage && (
                          <div className="mb-3">
                            <p className="text-gray-400 text-sm mb-1">阅读文章:</p>
                            <p className="text-gray-300 line-clamp-2">{question.passage}</p>
                          </div>
                        )}
                        
                        {question.options && (
                          <div className="mb-3"><p className="text-gray-400 text-sm mb-1">选项:</p>
                            <ul className="space-y-1">
                              {question.options.map((option) => (
                                <li key={option.id} className="flex items-start gap-2">
                                  <span className={`inline-block w-5 h-5 rounded-full flex items-center justify-center text-xs mt-0.5 ${option.isCorrect ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300'}`}>
                                    {option.id}
                                  </span>
                                  <span className="text-gray-300">{option.text}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Link
                          to={`/gre-question-bank/edit/${question.id}`}
                          className="w-10 h-10 rounded-full bg-indigo-600/20 text-indigo-400 flex items-center justify-center hover:bg-indigo-600/40 transition-colors"
                        >
                          <i className="fas fa-edit"></i>
                        </Link>
                        
                        <motion.button
                          className="w-10 h-10 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center hover:bg-red-600/40 transition-colors"
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleDeleteQuestion(question.id)}
                          title="删除题目"
                        >
                          <i className="fas fa-trash-alt"></i>
                        </motion.button>
                        
                        <Link
                          to={`/gre-question-bank/view/${question.id}`}
                          className="w-10 h-10 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center hover:bg-blue-600/40 transition-colors"
                        >
                          <i className="fas fa-eye"></i>
                        </Link>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
          
          {/* 返回按钮 */}
          <div className="mt-12 p-4 text-center">
            <Link 
              to="/database" 
              className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <i className="fas fa-arrow-left"></i>
              <span>返回数据库</span>
            </Link>
          </div>
        </motion.div>
      </div>
      
      {/* 页脚 */}
      <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | GRE题库系统</p>
      </footer>
    </div>
  );
};

export default GREQuestionBankPage;