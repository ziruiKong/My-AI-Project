import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";
import DynamicParticles from "../components/DynamicParticles";

const QuantStrategyHomePage: React.FC = () => {
    const {
        isDark
    } = useTheme();

    const containerVariants = {
        hidden: {
            opacity: 0
        },

        visible: {
            opacity: 1,

            transition: {
                staggerChildren: 0.2
            }
        }
    };

    const itemVariants = {
        hidden: {
            y: 20,
            opacity: 0
        },

        visible: {
            y: 0,
            opacity: 1,

            transition: {
                duration: 0.6
            }
        }
    };

    const strategies = [{
        id: "index-enhancement",
        name: "指数增强策略",
        description: "在跟踪指数表现的基础上，通过量化模型获取超额收益，同时严格控制与基准指数的跟踪误差",
        color: "from-blue-500 to-cyan-500",
        icon: "chart-line",
        gradientDirection: "diagonal-tl"
    }, {
        id: "cta",
        name: "CTA策略",
        description: "利用期货市场的趋势跟踪、反转策略等，捕捉大宗商品和金融衍生品的价格波动机会",
        color: "from-orange-500 to-amber-500",
        icon: "chart-pie",
        gradientDirection: "diagonal-tr"
    }, {
        id: "quant-hedging",
        name: "量化对冲策略",
        description: "通过多因子选股和股指期货对冲，在控制市场风险的同时获取稳定的Alpha收益",
        color: "from-green-500 to-emerald-500",
        icon: "balance-scale",
        gradientDirection: "diagonal-bl"
    }, {
        id: "quant-long-short",
        name: "量化多空策略",
        description: "基于量化模型同时持有多头和空头头寸，在不同市场环境下均能获取相对稳定的收益",
        color: "from-purple-500 to-violet-500",
        icon: "arrows-alt-h",
        gradientDirection: "diagonal-br"
    }, {
        id: "stock-selection",
        name: "股票优选策略",
        description: "通过多因子模型筛选具有Alpha潜力的个股，构建优化投资组合，追求长期稳健增长",
        color: "from-pink-500 to-rose-500",
        icon: "check-circle",
        gradientDirection: "vertical"
    }];

    return (
        <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
            {}
            <div
                className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
            {}
            <DynamicParticles
                className="opacity-60"
                particleCount={300}
                particleSizeRange={[1, 2]}
                speedRange={[0.1, 0.3]}
                lineDistance={80} />
            {}
            <NavigationBar currentPage="/q/quant-strategy-home" />
            {}
            <div className="flex-grow relative z-10 flex flex-col px-4 py-16">
                <motion.div
                    className="max-w-6xl mx-auto"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible">
                    {}
                    <></>
                    {}
                    <motion.div
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16"
                        variants={containerVariants}>
                        {strategies.map((strategy, index) => <motion.div
                            key={strategy.id}
                            variants={itemVariants}
                            whileHover={{
                                y: -8,
                                boxShadow: `0 25px 50px -12px ${strategy.color.split(" ")[0].replace("from-", "rgba(").replace("-500", "999, 0.3)")}`,
                                backdropFilter: "blur(20px)"
                            }}
                            initial={{
                                opacity: 0,
                                y: 30
                            }}
                            animate={{
                                opacity: 1,
                                y: 0
                            }}
                            transition={{
                                duration: 0.5,
                                delay: index * 0.1
                            }}>
                            <Link
                                to={`${window.location.pathname.includes("/runtime") ? "/runtime/q/quant-strategy" : "/q/quant-strategy"}#${strategy.id}`}
                                className={`block p-8 rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg transition-all duration-500 h-full flex flex-col`}
                                style={{
                                    textDecoration: "none"
                                }}>
                                <div className="relative overflow-hidden rounded-xl mb-6">
                                    <div
                                        className={`w-16 h-16 rounded-xl bg-gradient-to-br ${strategy.color} flex items-center justify-center text-white`}>
                                        <i className={`fas fa-${strategy.icon} text-2xl`}></i>
                                    </div>
                                    <div
                                        className={`absolute -bottom-8 -right-8 w-24 h-24 rounded-full bg-gradient-to-br ${strategy.color} opacity-10 blur-xl`}></div>
                                </div>
                                <h3 className="text-2xl font-bold mb-4 text-white flex items-center">
                                    {strategy.name}
                                    <motion.div
                                        className="ml-2"
                                        whileHover={{
                                            x: 3
                                        }}>
                                        <span
                                            className="flex items-center justify-center w-8 h-8 rounded-full bg-white/10 border border-white/20 text-white">
                                            <i className="fas fa-plus text-xs"></i>
                                        </span>
                                    </motion.div>
                                </h3>
                                <p className="text-gray-300 mb-6 flex-grow">{strategy.description}</p>
                                <div className="flex justify-between items-center">
                                    <div className="flex -space-x-2">
                                        {[1, 2, 3].map(i => <div
                                            key={i}
                                            className={`w-3 h-3 rounded-full bg-gradient-to-br ${strategy.color}`}></div>)}
                                    </div>
                                    <motion.div
                                        className="text-indigo-400 flex items-center font-medium"
                                        whileHover={{
                                            x: 3
                                        }}>查看详情
                                                              <i className="fas fa-arrow-right ml-2 text-sm"></i>
                                    </motion.div>
                                </div>
                            </Link>
                        </motion.div>)}
                    </motion.div>
                    {}
                    <motion.div className="mt-24" variants={itemVariants}>
                        <div className="text-center mb-16">
                            <h2 className="text-3xl font-bold mb-4 text-white">策略特色与优势</h2>
                            <p className="text-xl text-gray-300 max-w-2xl mx-auto">我们的量化投资策略融合了前沿的人工智能技术与多年的投资经验
                                              </p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            <motion.div
                                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                                whileHover={{
                                    y: -5
                                }}>
                                <div
                                    className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                                    <i className="fas fa-brain text-xl"></i>
                                </div>
                                <h3 className="text-xl font-bold mb-2 text-white">AI驱动</h3>
                                <p className="text-gray-300">基于深度学习的量化模型，自动识别市场模式和交易机会，持续优化投资决策
                                                    </p>
                            </motion.div>
                            <motion.div
                                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                                whileHover={{
                                    y: -5
                                }}>
                                <div
                                    className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                                    <i className="fas fa-shield-alt text-xl"></i>
                                </div>
                                <h3 className="text-xl font-bold mb-2 text-white">风险控制</h3>
                                <p className="text-gray-300">多维度风险评估体系，严格控制最大回撤，保障投资组合安全
                                                    </p>
                            </motion.div>
                            <motion.div
                                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                                whileHover={{
                                    y: -5
                                }}>
                                <div
                                    className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                                    <i className="fas fa-chart-line text-xl"></i>
                                </div>
                                <h3 className="text-xl font-bold mb-2 text-white">持续优化</h3>
                                <p className="text-gray-300">基于历史数据不断回测和优化模型参数，适应市场变化，保持策略有效性
                                                    </p>
                            </motion.div>
                        </div>
                    </motion.div>
                    {}
                    <motion.div className="mt-20 text-center" variants={itemVariants}>
                        <motion.button
                            className="px-10 py-4 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium text-lg flex items-center justify-center mx-auto gap-2 shadow-lg shadow-indigo-600/20"
                            whileHover={{
                                scale: 1.05,
                                boxShadow: "0 0 30px rgba(139, 92, 246, 0.4)"
                            }}
                            whileTap={{
                                scale: 0.97
                            }}>
                            <i className="fas fa-rocket text-xl"></i>开始使用量化策略
                                        </motion.button>
                        <p className="mt-4 text-gray-400 text-sm">风险提示：投资有风险，入市需谨慎
                                        </p>
                    </motion.div>
                </motion.div>
            </div>
            {}
            <div className="p-6 relative z-10">
                <Link
                    to="/q"
                    className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors">
                    <i className="fas fa-arrow-left"></i>
                    <span>返回COREX Q主页</span>
                </Link>
            </div>
            {}
            <footer className="py-8 text-center text-gray-500 text-sm mt-auto">
                <p>© 2025 COREX 人工智能 | COREX Q</p>
            </footer>
        </div>
    );
};

export default QuantStrategyHomePage;