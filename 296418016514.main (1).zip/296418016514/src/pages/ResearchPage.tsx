import React from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";

const ResearchPage: React.FC = () => {
  const { isDark } = useTheme();
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/q/research" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col items-center justify-center px-4 py-12">
        <motion.div
          className="max-w-5xl mx-auto text-center"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* 页面标题 */}
          <motion.div 
            className="mb-16"
            variants={itemVariants}
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 text-white mb-6">
              <i className="fas fa-flask text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">投资研究</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              深入挖掘市场规律，持续优化算法模型，把握投资先机
            </p>
          </motion.div>
          
          {/* 研究领域 */}
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16"
            variants={containerVariants}
          >
            {[
              {
                title: "市场微观结构",
                description: "研究订单流、流动性和价格形成机制，揭示市场运行的内在规律",
                icon: "microscope"
              },
              {
                title: "因子发现",
                description: "通过机器学习算法发掘有效的风险因子和alpha信号，构建超额收益来源",
                icon: "lightbulb"
              },
              {
                title: "模型优化",
                description: "持续改进预测模型，整合最新的深度学习和强化学习技术提升预测精度",
                icon: "brain"
              },
              {
                title: "回测框架",
                description: "开发高性能回测系统，支持复杂策略的历史验证和参数优化",
                icon: "code"
              }
            ].map((field, index) => (
              <motion.div
                key={index}
                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                variants={itemVariants}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(168, 85, 247, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center mb-4 text-white">
                  <i className={`fas fa-${field.icon} text-xl`}></i>
                </div>
                <h3 className="text-xl font-bold mb-2 text-white">{field.title}</h3>
                <p className="text-gray-300">{field.description}</p>
              </motion.div>
            ))}
          </motion.div>
          
          {/* 行动按钮 */}
          <motion.div
            className="flex flex-col sm:flex-row gap-4 justify-center"
            variants={itemVariants}
          >
            <motion.button
              className="px-8 py-3 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium text-lg flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-search"></i>
              浏览研究成果
            </motion.button>
            
            <motion.button
              className="px-8 py-3 rounded-lg bg-white/10 border border-white/20 text-white font-medium text-lg flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, backgroundColor: "rgba(255, 255, 255, 0.15)" }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-chart-pie"></i>
              查看市场分析
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
      
      {/* 返回按钮 */}
      <div className="p-6 relative z-10">
        <Link to="/q" className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors">
          <i className="fas fa-arrow-left"></i>
          <span>返回COREX Q主页</span>
        </Link>
      </div>
      
      {/* 页脚 */}
       <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | COREX Q</p>
      </footer>
    </div>
  );
};

export default ResearchPage;