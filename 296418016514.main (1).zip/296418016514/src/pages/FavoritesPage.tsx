import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useChat } from "../contexts/chatContext";
import { toast } from "sonner";

const FavoritesPage: React.FC = () => {
  const { isDark } = useTheme();
  const { favoriteMessages, toggleFavorite } = useChat();
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedMessageId, setExpandedMessageId] = useState<string | null>(null);
  const [expandedContentId, setExpandedContentId] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  // 过滤收藏的消息
  const filteredMessages = favoriteMessages.filter(message => 
    !searchQuery || 
    message.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // 复制消息内容
  const handleCopyContent = async (id: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopySuccess(id);
      setTimeout(() => setCopySuccess(null), 2000);
      toast.success("内容已复制到剪贴板");
    } catch (error) {
      console.error("复制失败:", error);
      toast.error("复制失败，请手动复制");
    }
  };

  // 移除收藏
  const handleRemoveFavorite = (id: string) => {
    toggleFavorite(id);
    toast.success("已取消收藏");
  };

  // 格式化日期
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  // 获取消息类型图标
  const getMessageTypeIcon = (type: string) => {
    switch (type) {
      case "image":
        return "fa-image";
      case "file":
        return "fa-file";
      default:
        return "fa-comment";
    }
  };

  // 获取模型显示名称
  const getModelDisplayName = (model?: string) => {
    switch (model) {
      case "deepseek-reasoner":
        return "Corex-1o";
      case "kimi-k2":
        return "Corex-M1";
      default:
        return "Corex-1";
    }
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? "bg-gradient-to-br from-gray-900 via-purple-950 to-indigo-950 text-white" : "bg-gradient-to-br from-white via-purple-50 to-indigo-50 text-gray-900"} relative overflow-hidden`}>
      {/* 背景装饰元素 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className={`absolute top-20 left-20 w-64 h-64 rounded-full ${isDark ? "bg-purple-700/20" : "bg-purple-200/40"} blur-3xl animate-pulse`} style={{ animationDuration: '8s' }}></div>
        <div className={`absolute bottom-20 right-20 w-72 h-72 rounded-full ${isDark ? "bg-indigo-700/20" : "bg-indigo-200/40"} blur-3xl animate-pulse`} style={{ animationDuration: '10s', animationDelay: '1s' }}></div>
      </div>

      <NavigationBar currentPage="/favorites" />
      
      <div className="container mx-auto px-4 py-8 flex-grow relative z-10">
        <motion.div 
          className="max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-indigo-600 text-white mb-4">
              <i className="fas fa-star text-2xl"></i>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">我的收藏</h1>
            <p className={`${isDark ? "text-gray-400" : "text-gray-600"} mb-4`}>查看和管理您收藏的重要消息</p>
            <div className={`inline-block px-4 py-2 rounded-full text-sm ${isDark ? "bg-indigo-900/30 text-indigo-400" : "bg-indigo-100 text-indigo-700"}`}>
              共 {favoriteMessages.length} 条收藏
            </div>
          </div>
          
          {/* 搜索框 */}
          <div className="relative mb-8">
            <input
              type="text"
              placeholder="搜索收藏的消息..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full px-4 py-2 rounded-lg border ${
                isDark 
                  ? "bg-gray-800 border-gray-700 text-white" 
                  : "bg-white border-gray-300 text-gray-800"
              } focus:outline-none focus:ring-2 focus:ring-indigo-500`}
            />
            <i className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          </div>
          
          {/* 收藏消息列表 */}
          <motion.div 
            className="space-y-4"
            variants={{
              hidden: { opacity: 0 },
              visible: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.1
                }
              }
            }}
            initial="hidden"
            animate="visible"
          >
            {filteredMessages.length > 0 ? (
              filteredMessages.map((message) => (
                <motion.div
                  key={message.id}
                  className={`rounded-xl border overflow-hidden transition-all backdrop-blur-md ${
                    isDark 
                      ? "bg-gray-800/80 border-gray-700" 
                      : "bg-white/80 border-gray-100 shadow-md"
                  }`}
                  whileHover={{ y: -3, boxShadow: isDark ? "0 10px 25px -5px rgba(139, 92, 246, 0.2)" : "0 10px 25px -5px rgba(139, 92, 246, 0.1)" }}
                  variants={{
                    hidden: { opacity: 0, y: 20 },
                    visible: { opacity: 1, y: 0 }
                  }}
                >
                  {/* 消息头部 */}
                  <div 
                    className={`p-4 cursor-pointer flex justify-between items-center ${
                      expandedMessageId === message.id ? (isDark ? "bg-gray-700" : "bg-gray-50") : ""
                    }`}
                    onClick={() => setExpandedMessageId(expandedMessageId === message.id ? null : message.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        isDark 
                          ? "bg-gradient-to-br from-purple-900/50 to-indigo-900/50" 
                          : "bg-gradient-to-br from-purple-100 to-indigo-100"
                      }`}>
                        <i className={`fas ${getMessageTypeIcon(message.type || "text")} text-purple-500`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate">{message.content.substring(0, 50)}...</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                            {formatDate(message.timestamp)}
                          </span>
                          {message.model && (
                            <span className={`text-xs px-2 py-0.5 rounded-full ${
                              message.model === "deepseek-reasoner" 
                                ? isDark ? "bg-purple-100/20 text-purple-400" : "bg-purple-100 text-purple-700" 
                                : message.model === "kimi-k2" 
                                ? isDark ? "bg-teal-100/20 text-teal-400" : "bg-teal-100 text-teal-700" 
                                : isDark ? "bg-indigo-100/20 text-indigo-400" : "bg-indigo-100 text-indigo-700"
                            }`}>
                              {getModelDisplayName(message.model)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <motion.div
                      animate={{ rotate: expandedMessageId === message.id ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <i className={`fas fa-chevron-down text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}></i>
                    </motion.div>
                  </div>
                  
                  {/* 消息内容 */}
                  <motion.div
                    initial={false}
                    animate={{ height: expandedMessageId === message.id ? "auto" : 0, opacity: expandedMessageId === message.id ? 1 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className={`p-4 ${isDark ? "bg-gray-800/50" : "bg-white"}`}>
                      <div className={`mb-4 p-4 rounded-lg ${isDark ? "bg-gray-900" : "bg-gray-50"}`}>
                        <div 
                          className={`favorite-content ${expandedContentId === message.id ? 'expanded' : ''}`}
                          style={{ maxHeight: expandedContentId === message.id ? '1000px' : '200px' }}
                        >
                          <p 
                            className={`${isDark ? "text-gray-300" : "text-gray-700"} whitespace-pre-wrap break-words`}
                          >
                            {message.content}
                          </p>
                        </div>
                        {message.content.length > 200 && (
                          <button 
                            className={`mt-2 text-xs ${isDark ? "text-indigo-400 hover:text-indigo-300" : "text-indigo-600 hover:text-indigo-800"}`}
                            onClick={() => setExpandedContentId(expandedContentId === message.id ? null : message.id)}
                          >
                            {expandedContentId === message.id ? '收起内容' : '查看更多'}
                          </button>
                        )}
                      </div>
                      
                      {/* 文件/图片预览 */}
                      {message.type === "image" && message.fileInfo?.url && (
                        <div className="mb-4">
                          <img 
                            src={message.fileInfo.url} 
                            alt="预览图片" 
                            className="w-full max-h-60 object-contain rounded-lg"
                          />
                          {message.fileInfo.name && (
                            <p className={`mt-2 text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                              {message.fileInfo.name}
                            </p>
                          )}
                        </div>
                      )}
                      
                      {message.type === "file" && message.fileInfo && (
                        <div className="mb-4 p-3 rounded-lg bg-gray-100 dark:bg-gray-700">
                          <div className="flex items-center gap-3">
                            <div className="p-3 rounded-lg bg-gray-200 dark:bg-gray-600">
                              <i className="fa-solid fa-file text-blue-500" size={24} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{message.fileInfo.name}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">
                                {message.fileInfo.size > 1024 * 1024 
                                  ? `${(message.fileInfo.size / (1024 * 1024)).toFixed(1)} MB` 
                                  : `${(message.fileInfo.size / 1024).toFixed(1)} KB`}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* 操作按钮 */}
                      <div className="flex justify-end gap-2 mt-4">
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className={`px-3 py-1.5 rounded-lg text-sm ${
                            isDark ? "bg-gray-700 hover:bg-gray-600" : "bg-gray-100 hover:bg-gray-200"
                          } transition-colors flex items-center gap-1`}
                          onClick={() => handleCopyContent(message.id, message.content)}
                        >
                          {copySuccess === message.id ? (
                            <>
                              <i className="fas fa-check text-green-500"></i> 已复制
                            </>
                          ) : (
                            <>
                              <i className="fas fa-copy"></i> 复制内容
                            </>
                          )}
                        </motion.button>
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          className={`px-3 py-1.5 rounded-lg text-sm ${
                            isDark ? "bg-red-900/30 text-red-400 hover:bg-red-900/50" : "bg-red-100 text-red-600 hover:bg-red-200"
                          } transition-colors flex items-center gap-1`}
                          onClick={() => handleRemoveFavorite(message.id)}
                        >
                          <i className="fas fa-star-slash"></i> 取消收藏
                        </motion.button>
                      </div>
                    </div>
                  </motion.div>
                </motion.div>
              ))
            ) : (
              <motion.div
                className={`text-center p-10 rounded-lg border ${
                  isDark ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"
                }`}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 }
                }}
              >
                {searchQuery ? (
                  <>
                    <i className="fas fa-search text-2xl mb-3 text-gray-400"></i>
                    <h3 className={`font-medium mb-1 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                      没有找到匹配的收藏
                    </h3>
                    <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                      尝试使用不同的关键词搜索
                    </p>
                  </>
                ) : (
                  <>
                    <i className="fas fa-star text-2xl mb-3 text-gray-400"></i>
                    <h3 className={`font-medium mb-1 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                      还没有收藏任何内容
                    </h3>
                    <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"} mb-4`}>
                      在聊天界面中，点击消息下方的"收藏"按钮保存重要内容
                    </p>
                    <a 
                      href="/" 
                      className={`inline-flex items-center px-4 py-2 rounded-lg ${
                        isDark ? "bg-indigo-600 hover:bg-indigo-700" : "bg-indigo-600 hover:bg-indigo-700"
                      } text-white font-medium transition-colors`}
                    >
                      <i className="fas fa-comments mr-2"></i>
                      开始聊天
                    </a>
                  </>
                )}
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      </div>
      
      <footer className={`py-6 mt-auto ${isDark ? "bg-gray-900 border-t border-gray-800" : "bg-white border-t border-gray-200"}`}>
        <div className="container mx-auto px-4 text-center">
          <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>
            © 2025 COREX AI 团队 | 我的收藏
          </p>
        </div>
      </footer>
    </div>
  );
};

export default FavoritesPage;