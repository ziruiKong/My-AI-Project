import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { useImages, useKnowledge, useDatabase } from "../hooks/useStorage";
import { Link } from "react-router-dom";
import { toast } from "sonner";

const DatabasePage: React.FC = () => {
  const { isDark } = useTheme();
  const { images, loading: imagesLoading, deleteImage } = useImages();
  const { knowledgeItems, loading: knowledgeLoading } = useKnowledge();
  const [stats, setStats] = useState<any>(null);
  const { exportDatabase, importDatabase, getDatabaseStats } = useDatabase();
  
  const [activeTab, setActiveTab] = useState<'images' | 'knowledge' | 'stats'>('images');
  const [importFile, setImportFile] = useState<File | null>(null);
  const [databaseStats, setDatabaseStats] = useState<any>(null);
  
  // 加载数据库统计信息
  useEffect(() => {
    const loadStats = async () => {
      const stats = await getDatabaseStats();
      setDatabaseStats(stats);
      setStats(stats);
    };
    loadStats();
  }, [images, knowledgeItems, getDatabaseStats]);
  
  // 处理导入文件变化
  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImportFile(e.target.files[0]);
    }
  };
  
  // 处理导入数据库
  const handleImportDatabase = async () => {
    if (!importFile) {
      toast.warning("请选择要导入的数据库文件");
      return;
    }
    
    try {
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        const jsonData = event.target?.result as string;
        const success = await importDatabase(jsonData);
        
        if (success) {
          toast.success("数据库导入成功");
          setImportFile(null);
        } else {
          toast.error("数据库导入失败");
        }
      };
      
      reader.onerror = () => {
        toast.error("文件读取失败");
        setImportFile(null);
      };
      
      reader.readAsText(importFile);
    } catch (error) {
      console.error("导入数据库时发生错误:", error);
      toast.error("数据库导入失败");
      setImportFile(null);
    }
  };
 
  // 处理导出数据库
  const handleExportDatabase = async () => {
    try {
      const data = await exportDatabase();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `corex_database_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success("数据库导出成功");
    } catch (error) {
      console.error("导出数据库时发生错误:", error);
      toast.error("数据库导出失败");
    }
  };

  // 处理分享数据库
  const handleShareDatabase = async () => {
    try {
      // 检查浏览器是否支持Web Share API
      if (!navigator.share) {
        toast.warning("您的浏览器不支持分享功能，请使用导出功能");
        return;
      }
      
      // 获取数据库内容
      const data = await exportDatabase();
      const blob = new Blob([data], { type: 'application/json' });
      
      // 创建临时URL
      const url = URL.createObjectURL(blob);
      const fileName = `corex_database_${new Date().toISOString().split('T')[0]}.json`;
      
      // 尝试使用Web Share API
      await navigator.share({
        title: 'COREX数据库备份',
        text: `COREX数据库备份文件 - ${fileName}`,
        files: [new File([blob], fileName, { type: 'application/json' })]
      });
      
      // 释放URL
      URL.revokeObjectURL(url);
      
      toast.success("数据库分享成功");
    } catch (error) {
      console.error("分享数据库时发生错误:", error);
      toast.error("数据库分享失败");
    }
  };

  // 获取数据库使用信息
  useEffect(() => {
    const getStorageInfo = async () => {
      try {
        if ('storage' in navigator && 'estimate' in navigator.storage) {
          const estimate = await navigator.storage.estimate();
          console.log('Storage estimate:', estimate);
        }
      } catch (error) {
        console.error('Error getting storage info:', error);
      }
    };
    
    getStorageInfo();
  }, []);
  
  // 处理删除图片
  const handleDeleteImage = async (id: string) => {
    if (window.confirm("确定要删除这张图片吗？")) {
      const success = await deleteImage(id);
      if (success) {
        toast.success("图片删除成功");
        // 重新加载统计信息
        const newStats = await getDatabaseStats();
        setDatabaseStats(newStats);
      } else {
        toast.error("图片删除失败");
      }
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/database" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-8">
        <motion.div
          className="max-w-6xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* 页面标题 */}
          <div className="mb-12 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-database text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">数据库管理</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              管理存储的图片和知识内容，支持多种存储方式和分享功能
            </p>
          </div>
          
          {/* 数据库操作按钮 */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <motion.button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" }}
              whileTap={{ scale: 0.97 }}
              onClick={handleExportDatabase}
            >
              <i className="fas fa-download"></i>
              导出为文件
            </motion.button>
            
            <motion.button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-medium flex items-center justify-center gap-2"
              whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(59, 130, 246, 0.4)" }}
              whileTap={{ scale: 0.97 }}
              onClick={handleShareDatabase}
            >
              <i className="fas fa-share-alt"></i>
              分享数据库
            </motion.button>
            
            <label className="px-6 py-3 rounded-lg bg-white/10 border border-white/20 text-white font-medium flex items-center justify-center gap-2 cursor-pointer">
              <i className="fas fa-upload"></i>
              导入数据库
              <input
                type="file"
                accept=".json"
                onChange={handleImportFileChange}
                className="hidden"
              />
            </label>
            
            {importFile && (
              <motion.button
                className="px-4 py-3 rounded-lg bg-green-600 text-white font-medium flex items-center justify-center gap-2"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleImportDatabase}
              >
                <i className="fas fa-check"></i>
                确认导入: {importFile.name}
              </motion.button>
            )}
          </div>
          
          {/* 存储类型切换 */}
          <div className="text-center mb-12">
            <h3 className="text-xl font-semibold mb-4 text-white">存储类型</h3>
            <p className="text-gray-300 mb-6">
              当前使用 {databaseStats?.storageType === 'IndexedDB' ? 'IndexedDB' : 'LocalStorage'} 存储，
              {databaseStats?.storageType === 'IndexedDB' ? '提供更大的存储容量' : '适合轻量级数据存储'}
            </p>
            {databaseStats?.storageType !== 'IndexedDB' && (
              <motion.button
                className="px-6 py-3 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white font-medium flex items-center justify-center gap-2 mx-auto"
                whileHover={{ scale: 1.03, boxShadow: "0 0 25px rgba(168, 85, 247, 0.4)" }}
                whileTap={{ scale: 0.97 }}
                onClick={async () => {
                  try {
                    // 提示用户即将切换到IndexedDB
                    if (window.confirm('确定要切换到IndexedDB存储吗？这将迁移您的所有数据，提供更大的存储容量。')) {
                      // 重新初始化数据库，强制使用IndexedDB
                      localStorage.setItem('forceIndexedDB', 'true');
                      toast.info('正在切换存储类型，请稍候...');
                      setTimeout(() => {
                        window.location.reload();
                      }, 1000);
                    }
                  } catch (error) {
                    console.error('切换存储类型失败:', error);
                    toast.error('切换存储类型失败');
                  }
                }}
              >
                <i className="fas fa-database"></i>
                切换到IndexedDB存储
              </motion.button>
            )}
          </div>
          
           {/* 标签切换 */}
          <div className="flex justify-center mb-8 flex-wrap">
            <div className="inline-flex bg-white/10 rounded-xl p-1 backdrop-blur-md">
              <motion.button
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'images' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-gray-300 hover:text-white'
                }`}
                onClick={() => setActiveTab('images')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
              >
                图片 ({images.length})
              </motion.button>
              
              <motion.button
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'knowledge' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-gray-300 hover:text-white'
                }`}
                onClick={() => setActiveTab('knowledge')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
              >
                知识内容 ({knowledgeItems.length})
              </motion.button>
              
              <motion.button
                className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'stats' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white' : 'text-gray-300 hover:text-white'
                }`}
                onClick={() => setActiveTab('stats')}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
              >
                数据库统计
              </motion.button>
            </div>
          </div>
          
          {/* GRE题库入口 */}
          <motion.div
            className="mb-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Link
              to={window.location.pathname.includes('/runtime') ? "/runtime/gre-question-bank" : "/gre-question-bank"}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-medium"
            >
              <i className="fas fa-graduation-cap"></i>
              访问GRE题库
            </Link>
          </motion.div>
          
          {/* 内容区域 */}
          <div className="rounded-2xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg p-6 overflow-hidden">
            {/* 图片标签内容 */}
            {activeTab === 'images' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold mb-6 text-white">存储的图片</h2>
                
                {imagesLoading ? (
                  <div className="flex justify-center items-center h-60">
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                      <p className="mt-4 text-gray-300">加载中...</p>
                    </div>
                  </div>
                ) : images.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-60">
                    <i className="fas fa-images text-4xl text-gray-500 mb-4"></i>
                    <p className="text-gray-300">暂无存储的图片</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    {images.map((image) => (
                      <motion.div
                        key={image.id}
                        className="relative rounded-xl overflow-hidden backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        whileHover={{ y: -5 }}
                      >
                        <div className="p-4">
                          <div className="aspect-w-4 aspect-h-3 mb-4 bg-gray-800 rounded-lg overflow-hidden">
                            <img 
                              src={image.previewUrl} 
                              alt={`Uploaded image ${image.id}`} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-white font-medium truncate max-w-[180px]">
                                {image.file.name || `Image ${image.id}`}
                              </p>
                              <p className="text-xs text-gray-400 mt-1">
                                {new Date(image.uploadDate).toLocaleDateString()}
                              </p>
                            </div>
                            <motion.button
                              className="w-8 h-8 rounded-full bg-red-600/20 text-red-400 flex items-center justify-center hover:bg-red-600/40 transition-colors"
                              whileHover={{ scale: 1.1 }}
                              whileTap={{ scale: 0.9 }}
                              onClick={() => handleDeleteImage(image.id)}
                              title="删除图片"
                            >
                              <i className="fas fa-trash-alt text-sm"></i>
                            </motion.button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
            
            {/* 知识内容标签内容 */}
            {activeTab === 'knowledge' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold mb-6 text-white">知识内容</h2>
                
                {knowledgeLoading ? (
                  <div className="flex justify-center items-center h-60">
                    <div className="flex flex-col items-center">
                      <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                      <p className="mt-4 text-gray-300">加载中...</p>
                    </div>
                  </div>
                ) : knowledgeItems.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-60">
                    <i className="fas fa-book text-4xl text-gray-500 mb-4"></i>
                    <p className="text-gray-300">暂无存储的知识内容</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {knowledgeItems.map((item) => (
                      <motion.div
                        key={item.id}
                        className="backdrop-blur-xl bg-white/10 border border-white/20 rounded-xl p-5 shadow-md"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                        whileHover={{ y: -3 }}
                      >
                        <div className="flex justify-between items-start">
                          <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                          <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-gray-300">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-gray-300 mb-4 line-clamp-2">{item.content}</p>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-400">
                            创建于 {new Date(item.createDate).toLocaleDateString()}
                            {item.updateDate && ` • 更新于 ${new Date(item.updateDate).toLocaleDateString()}`}
                          </p>
                          {item.tags && item.tags.length > 0 && (
                            <div className="flex gap-2">
                              {item.tags.map((tag, index) => (
                                <span 
                                  key={index} 
                                  className="px-2 py-1 rounded-full text-xs bg-indigo-900/30 text-indigo-300"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
            
            {/* 数据库统计标签内容 */}
             {activeTab === 'stats' && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-bold mb-6 text-white">数据库统计信息</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
                  <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">总项目数</h3>
                    <p className="text-3xl font-bold text-white">{databaseStats?.totalItems || 0}</p>
                  </div>
                  
                  <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">图片数</h3>
                    <p className="text-3xl font-bold text-white">{databaseStats?.imageCount || 0}</p>
                  </div>
                  
                  <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">知识内容数</h3>
                    <p className="text-3xl font-bold text-white">{databaseStats?.knowledgeCount || 0}</p>
                  </div>
                  
                  <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">GRE题目数</h3>
                    <p className="text-3xl font-bold text-white">{databaseStats?.greQuestionCount || 0}</p>
                  </div>
                  
                  <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">存储类型</h3>
                    <p className="text-3xl font-bold text-white">
                      {databaseStats?.storageType === 'IndexedDB' 
                        ? 'IndexedDB' 
                        : databaseStats?.storageType || 'LocalStorage'}
                    </p>
                  </div>
                </div>
                
                {/* GRE题目统计 */}
                {databaseStats?.greQuestionCount && databaseStats.greQuestionCount > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                      <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">GRE选择题</h3>
                      <p className="text-3xl font-bold text-white">{databaseStats?.greQuestionsByType?.multipleChoice || 0}</p>
                    </div>
                    
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                      <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">GRE阅读题</h3>
                      <p className="text-3xl font-bold text-white">{databaseStats?.greQuestionsByType?.readingComprehension || 0}</p>
                    </div>
                  </div>
                )}
                
                <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                  <h3 className="text-xl font-semibold mb-4 text-white">数据库信息</h3>
                  <div className="space-y-3 text-gray-300">
                    <div className="flex justify-between">
                      <span>版本:</span>
                      <span className="font-medium">{databaseStats?.version || 'Unknown'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>最后初始化时间:</span>
                      <span className="font-medium">
                        {databaseStats?.lastInitialized 
                          ? new Date(databaseStats.lastInitialized).toLocaleString() 
                          : 'Never'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>存储位置:</span>
                      <span className="font-medium">
                        {databaseStats?.storageType === 'IndexedDB' 
                          ? '浏览器索引数据库 (IndexedDB)' 
                          : '浏览器本地存储 (LocalStorage)'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>存储限制:</span>
                      <span className="font-medium">
                        {databaseStats?.storageType === 'IndexedDB' 
                          ? '约 250MB - 2GB (取决于浏览器)' 
                          : '约 5-10 MB (取决于浏览器)'}
                      </span>
                    </div>
                    {databaseStats?.storageType === 'IndexedDB' && (
                      <div className="flex justify-between">
                        <span>优势:</span>
                        <span className="font-medium">更大容量，更好的性能，支持事务</span>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </div>
          
          {/* 返回按钮 */}
          <div className="mt-12 p-4 text-center">
            <Link 
              to="/" 
              className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              <i className="fas fa-arrow-left"></i>
              <span>返回首页</span>
            </Link>
          </div>
        </motion.div>
      </div>
      
      {/* 页脚 */}
      <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | 数据库管理系统</p>
      </footer>
    </div>
  );
};

export default DatabasePage;