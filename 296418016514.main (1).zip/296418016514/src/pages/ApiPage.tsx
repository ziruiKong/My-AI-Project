import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";

interface ApiEndpoint {
    id: string;
    title: string;
    description: string;
    endpoint: string;
    method: "GET" | "POST" | "PUT" | "DELETE";
    parameters: Array<{
        name: string;
        type: string;
        required: boolean;
        description: string;
    }>;
    responseFormat: string;
    exampleRequest?: string;
    exampleResponse?: string;
    category: "聊天" | "图像" | "文本" | "搜索";
}

const ApiPage: React.FC = () => {
    const {
        isDark
    } = useTheme();

    const [activeTab, setActiveTab] = useState<string>("all");
    const [searchQuery, setSearchQuery] = useState<string>("");
    const [expandedEndpoint, setExpandedEndpoint] = useState<string | null>(null);
    const [copySuccess, setCopySuccess] = useState<string | null>(null);

    const apiEndpoints: ApiEndpoint[] = [{
        id: "chat-completions",
        title: "聊天完成",
        description: "生成基于用户输入的AI回复",
        endpoint: "/v1/chat/completions",
        method: "POST",

        parameters: [{
            name: "messages",
            type: "array",
            required: true,
            description: "对话历史消息数组"
        }, {
            name: "model",
            type: "string",
            required: true,
            description: "使用的AI模型名称"
        }, {
            name: "temperature",
            type: "number",
            required: false,
            description: "控制生成文本的随机性"
        }, {
            name: "max_tokens",
            type: "number",
            required: false,
            description: "最大生成token数量"
        }],

        responseFormat: "JSON",

        exampleRequest: `{
  "model": "deepseek-chat",
  "messages": [
    {
      "role": "user",
      "content": "解释量子计算的基本原理"
    }
  ],
  "temperature": 0.7,
  "max_tokens": 500
}`,

        exampleResponse: `{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "量子计算是一种基于量子力学原理的计算范式..."
      },
      "finish_reason": "stop",
      "index": 0
    }
  ],
  "usage": {
    "prompt_tokens": 15,
    "completion_tokens": 120,
    "total_tokens": 135
  },
  "id": "chatcmpl-123",
  "object": "chat.completion",
  "created": 1677652288
}`,

        category: "聊天"
    }, {
        id: "images-generations",
        title: "图像生成",
        description: "根据文本描述生成图像",
        endpoint: "/v1/images/generations",
        method: "POST",

        parameters: [{
            name: "prompt",
            type: "string",
            required: true,
            description: "图像描述提示词"
        }, {
            name: "n",
            type: "number",
            required: false,
            description: "生成图像数量"
        }, {
            name: "size",
            type: "string",
            required: false,
            description: "生成图像尺寸"
        }],

        responseFormat: "JSON",

        exampleRequest: `{
  "prompt": "一个美丽的太空场景，有行星和星云",
  "n": 1,
  "size": "1024x1024"
}`,

        exampleResponse: `{
  "created": 1677649884,
  "data": [
    {
      "url": "https://api.siliconflow.cn/v1/images/generations/abc123.png"
    }
  ]
}`,

        category: "图像"
    }, {
        id: "images-analysis",
        title: "图像分析",
        description: "分析图像内容并返回详细描述",
        endpoint: "/v1/images/analysis",
        method: "POST",

        parameters: [{
            name: "image",
            type: "string",
            required: true,
            description: "图像的Base64编码或URL"
        }, {
            name: "prompt",
            type: "string",
            required: false,
            description: "可选的分析提示词"
        }],

        responseFormat: "JSON",

        exampleRequest: `{
  "image": "https://example.com/image.jpg",
  "prompt": "描述这张图片中的内容"
}`,

        exampleResponse: `{
  "description": "这张图片展示了一个美丽的海滩场景，有蓝色的海水和白色的沙滩..."
}`,

        category: "图像"
    }, {
        id: "audio-transcriptions",
        title: "音频转文字",
        description: "将音频内容转换为文本",
        endpoint: "/v1/audio/transcriptions",
        method: "POST",

        parameters: [{
            name: "file",
            type: "file",
            required: true,
            description: "音频文件"
        }, {
            name: "model",
            type: "string",
            required: true,
            description: "使用的语音识别模型"
        }],

        responseFormat: "JSON",
        exampleRequest: `// 这是一个表单数据请求，包含音频文件和参数`,

        exampleResponse: `{
  "text": "这是一段示例音频的转写内容，包含了测试用的文本信息。"
}`,

        category: "文本"
    }, {
        id: "search",
        title: "网络搜索",
        description: "执行网络搜索并返回结果",
        endpoint: "/v1/search",
        method: "GET",

        parameters: [{
            name: "q",
            type: "string",
            required: true,
            description: "搜索查询关键词"
        }, {
            name: "limit",
            type: "number",
            required: false,
            description: "返回结果数量限制"
        }],

        responseFormat: "JSON",
        exampleRequest: "GET /v1/search?q=最新科技进展&limit=10",

        exampleResponse: `{
  "results": [
    {
      "title": "2025年十大前沿科技展望",
      "url": "https://tech-review.example.com/2025-tech-trends",
      "snippet": "人工智能、量子计算、生物科技等领域的最新进展将在2025年引领新一轮科技革命..."
    }
    // 更多结果...
  ],
  "total": 100
}`,

        category: "搜索"
    }, {
        id: "translate",
        title: "文本翻译",
        description: "将文本从一种语言翻译成另一种语言",
        endpoint: "/v1/translate",
        method: "POST",

        parameters: [{
            name: "text",
            type: "string",
            required: true,
            description: "要翻译的文本"
        }, {
            name: "from",
            type: "string",
            required: false,
            description: "源语言（默认自动检测）"
        }, {
            name: "to",
            type: "string",
            required: true,
            description: "目标语言"
        }],

        responseFormat: "JSON",

        exampleRequest: `{
  "text": "Hello, world!",
  "from": "auto",
  "to": "zh"
}`,

        exampleResponse: `{
  "translatedText": "你好，世界！",
  "sourceLanguage": "en"
}`,

        category: "文本"
    }];

    const filteredEndpoints = apiEndpoints.filter(endpoint => {
        const matchesCategory = activeTab === "all" || endpoint.category === activeTab;
        const matchesSearch = searchQuery === "" || endpoint.title.toLowerCase().includes(searchQuery.toLowerCase()) || endpoint.description.toLowerCase().includes(searchQuery.toLowerCase()) || endpoint.endpoint.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    const getCategoryCount = (category: string) => {
        return apiEndpoints.filter(endpoint => endpoint.category === category).length;
    };

    const getMethodColor = (method: string) => {
        const colorMap: Record<string, string> = {
            "GET": isDark ? "bg-green-900/30 text-green-400" : "bg-green-100 text-green-600",
            "POST": isDark ? "bg-blue-900/30 text-blue-400" : "bg-blue-100 text-blue-600",
            "PUT": isDark ? "bg-amber-900/30 text-amber-400" : "bg-amber-100 text-amber-600",
            "DELETE": isDark ? "bg-red-900/30 text-red-400" : "bg-red-100 text-red-600"
        };

        return colorMap[method] || "bg-gray-100 text-gray-600";
    };

    const copyToClipboard = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopySuccess(id);
        setTimeout(() => setCopySuccess(null), 2000);
    };

    const formatDate = (dateString: string) => {
        const date = new Date(dateString);

        return new Intl.DateTimeFormat("zh-CN", {
            year: "numeric",
            month: "long",
            day: "numeric"
        }).format(date);
    };

    const containerVariants = {
        hidden: {
            opacity: 0
        },

        visible: {
            opacity: 1,

            transition: {
                staggerChildren: 0.1
            }
        }
    };

    const itemVariants = {
        hidden: {
            opacity: 0,
            y: 20
        },

        visible: {
            opacity: 1,
            y: 0,

            transition: {
                duration: 0.5
            }
        }
    };

    return (
        <div
            className={`min-h-screen flex flex-col ${isDark ? "bg-gradient-to-br from-gray-900 via-purple-950 to-indigo-950 text-white" : "bg-gradient-to-br from-white via-purple-50 to-indigo-50 text-gray-900"} relative overflow-hidden`}>
            {}
            <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
                <div
                    className={`absolute top-20 left-20 w-64 h-64 rounded-full ${isDark ? "bg-purple-700/20" : "bg-purple-200/40"} blur-3xl animate-pulse`}
                    style={{
                        animationDuration: "8s"
                    }}></div>
                <div
                    className={`absolute bottom-20 right-20 w-72 h-72 rounded-full ${isDark ? "bg-indigo-700/20" : "bg-indigo-200/40"} blur-3xl animate-pulse`}
                    style={{
                        animationDuration: "10s",
                        animationDelay: "1s"
                    }}></div>
                <div
                    className={`absolute top-1/2 left-1/3 w-48 h-48 rounded-full ${isDark ? "bg-blue-700/20" : "bg-blue-200/40"} blur-3xl animate-pulse`}
                    style={{
                        animationDuration: "12s",
                        animationDelay: "2s"
                    }}></div>
            </div>
            <NavigationBar currentPage="/api" />
            <div className="container mx-auto px-4 py-8 flex-grow relative z-10">
                <motion.div
                    className="max-w-5xl mx-auto"
                    initial={{
                        opacity: 0,
                        y: 20
                    }}
                    animate={{
                        opacity: 1,
                        y: 0
                    }}
                    transition={{
                        duration: 0.5
                    }}>
                    {}
                    <div className="text-center mb-12">
                        <></>
                        <></>
                    </div>
                    {}
                    <div className="mb-8">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="relative flex-grow">
                                <input
                                    type="text"
                                    placeholder="搜索API..."
                                    value={searchQuery}
                                    onChange={e => setSearchQuery(e.target.value)}
                                    className={`w-full px-4 py-2 rounded-lg border ${isDark ? "bg-gray-800 border-gray-700 text-white" : "bg-white border-gray-300 text-gray-800"} focus:outline-none focus:ring-2 focus:ring-indigo-500`} />
                                <i
                                    className="fas fa-search absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                            </div>
                            <div className="flex flex-wrap gap-2">
                                {["all", "聊天", "图像", "文本", "搜索"].map(category => <motion.button
                                    key={category}
                                    className={`px-3 py-1.5 rounded-full text-sm flex items-center gap-1 transition-all ${activeTab === category ? isDark ? "bg-indigo-900/30 text-indigo-400 border border-indigo-800/50" : "bg-indigo-100 text-indigo-700 border border-indigo-200" : isDark ? "bg-gray-800 text-gray-300 hover:bg-gray-700 border border-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200"}`}
                                    onClick={() => setActiveTab(category)}
                                    whileHover={{
                                        scale: 1.05
                                    }}
                                    whileTap={{
                                        scale: 0.95
                                    }}>
                                    <span>{category === "all" ? "全部" : category}</span>
                                    {category !== "all" && <span
                                        className={`text-xs ${activeTab === category ? "" : isDark ? "text-gray-500" : "text-gray-400"}`}>({getCategoryCount(category)})
                                                              </span>}
                                </motion.button>)}
                            </div>
                        </div>
                        {}
                        {searchQuery || activeTab !== "all" && <div className="mt-3 flex items-center justify-between text-sm">
                            <span className={`${isDark ? "text-gray-400" : "text-gray-600"}`}>显示 {filteredEndpoints.length}个API (共 {apiEndpoints.length}个)
                                                </span>
                            {(searchQuery || activeTab !== "all") && <motion.button
                                whileHover={{
                                    scale: 1.05
                                }}
                                whileTap={{
                                    scale: 0.95
                                }}
                                onClick={() => {
                                    setSearchQuery("");
                                    setActiveTab("all");
                                }}
                                className={`text-xs px-3 py-1 rounded-full ${isDark ? "bg-gray-800 text-gray-300 hover:bg-gray-700" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}>清除筛选
                                                  </motion.button>}
                        </div>}
                    </div>
                    {}
                    <motion.div
                        className="space-y-6"
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible">
                        {filteredEndpoints.map(endpoint => <motion.div
                            key={endpoint.id}
                            className={`rounded-xl border overflow-hidden transition-all backdrop-blur-md ${isDark ? "bg-gray-800/80 border-gray-700" : "bg-white/80 border-gray-100 shadow-md"}`}
                            whileHover={{
                                y: -3,
                                boxShadow: isDark ? "0 10px 25px -5px rgba(139, 92, 246, 0.2)" : "0 10px 25px -5px rgba(139, 92, 246, 0.1)"
                            }}
                            variants={itemVariants}>
                            {}
                            <div
                                className={`p-4 cursor-pointer flex justify-between items-center ${expandedEndpoint === endpoint.id ? isDark ? "bg-gray-700" : "bg-gray-50" : ""}`}
                                onClick={() => setExpandedEndpoint(expandedEndpoint === endpoint.id ? null : endpoint.id)}>
                                <div className="flex items-center gap-3">
                                    <div
                                        className={`w-10 h-10 rounded-full flex items-center justify-center ${isDark ? "bg-gradient-to-br from-indigo-900/50 to-blue-900/50" : "bg-gradient-to-br from-indigo-100 to-blue-100"}`}>
                                        <i className="fas fa-code text-xs text-indigo-500"></i>
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <h3 className="font-semibold text-lg">{endpoint.title}</h3>
                                            <span
                                                className={`text-xs px-2 py-0.5 rounded ${getMethodColor(endpoint.method)} font-mono`}>
                                                {endpoint.method}
                                            </span>
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
                                                {endpoint.description}
                                            </p>
                                            <span
                                                className={`text-xs font-mono ${isDark ? "text-gray-500" : "text-gray-600"} bg-gray-900/30 px-2 py-1 rounded`}>
                                                {endpoint.endpoint}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <motion.div
                                    animate={{
                                        rotate: expandedEndpoint === endpoint.id ? 180 : 0
                                    }}
                                    transition={{
                                        duration: 0.3
                                    }}>
                                    <i
                                        className={`fas fa-chevron-down text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}></i>
                                </motion.div>
                            </div>
                            {}
                            <motion.div
                                initial={false}
                                animate={{
                                    height: expandedEndpoint === endpoint.id ? "auto" : 0,
                                    opacity: expandedEndpoint === endpoint.id ? 1 : 0
                                }}
                                transition={{
                                    duration: 0.3
                                }}
                                className="overflow-hidden">
                                <div className={`p-4 ${isDark ? "bg-gray-800/50" : "bg-white"}`}>
                                    {}
                                    <div className="mb-4">
                                        <h4
                                            className={`text-sm font-medium mb-2 ${isDark ? "text-gray-300" : "text-gray-700"} flex items-center gap-1`}>
                                            <i className="fas fa-params text-xs text-indigo-500"></i>参数
                                                                  </h4>
                                        <div
                                            className={`rounded-lg overflow-hidden border ${isDark ? "border-gray-700" : "border-gray-200"}`}>
                                            <table className="w-full text-sm">
                                                <thead className={isDark ? "bg-gray-700" : "bg-gray-100"}>
                                                    <tr>
                                                        <th className="px-4 py-2 text-left">参数名</th>
                                                        <th className="px-4 py-2 text-left">类型</th>
                                                        <th className="px-4 py-2 text-left">必需</th>
                                                        <th className="px-4 py-2 text-left">描述</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {endpoint.parameters.map((param, index) => <tr
                                                        key={index}
                                                        className={index % 2 === 1 ? isDark ? "bg-gray-800" : "bg-gray-50" : ""}>
                                                        <td className="px-4 py-2 font-medium">{param.name}</td>
                                                        <td className="px-4 py-2 font-mono">{param.type}</td>
                                                        <td className="px-4 py-2">{param.required ? "✓" : "✗"}</td>
                                                        <td className="px-4 py-2">{param.description}</td>
                                                    </tr>)}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    {}
                                    {endpoint.exampleRequest && <div className="mb-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4
                                                className={`text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"} flex items-center gap-1`}>
                                                <i className="fas fa-play-circle text-xs text-indigo-500"></i>示例请求
                                                                          </h4>
                                            <button
                                                onClick={() => copyToClipboard(endpoint.exampleRequest || "", endpoint.id + "-request")}
                                                className={`text-xs px-2 py-1 rounded ${isDark ? "bg-gray-700 hover:bg-gray-600" : "bg-gray-100 hover:bg-gray-200"} transition-colors`}>
                                                {copySuccess === endpoint.id + "-request" ? "已复制" : "复制"}
                                            </button>
                                        </div>
                                        <pre
                                            className={`p-3 rounded-md text-xs overflow-x-auto ${isDark ? "bg-gray-900 text-gray-300" : "bg-gray-100 text-gray-800"}`}>
                                            <code>{endpoint.exampleRequest}</code>
                                        </pre>
                                    </div>}
                                    {}
                                    {endpoint.exampleResponse && <div className="mb-4">
                                        <div className="flex items-center justify-between mb-2">
                                            <h4
                                                className={`text-sm font-medium ${isDark ? "text-gray-300" : "text-gray-700"} flex items-center gap-1`}>
                                                <i className="fas fa-reply text-xs text-indigo-500"></i>示例响应
                                                                          </h4>
                                            <button
                                                onClick={() => copyToClipboard(endpoint.exampleResponse || "", endpoint.id + "-response")}
                                                className={`text-xs px-2 py-1 rounded ${isDark ? "bg-gray-700 hover:bg-gray-600" : "bg-gray-100 hover:bg-gray-200"} transition-colors`}>
                                                {copySuccess === endpoint.id + "-response" ? "已复制" : "复制"}
                                            </button>
                                        </div>
                                        <pre
                                            className={`p-3 rounded-md text-xs overflow-x-auto ${isDark ? "bg-gray-900 text-gray-300" : "bg-gray-100 text-gray-800"}`}>
                                            <code>{endpoint.exampleResponse}</code>
                                        </pre>
                                    </div>}
                                    {}
                                    <div>
                                        <h4
                                            className={`text-sm font-medium mb-2 ${isDark ? "text-gray-300" : "text-gray-700"} flex items-center gap-1`}>
                                            <i className="fas fa-file-code text-xs text-indigo-500"></i>响应格式
                                                                  </h4>
                                        <span
                                            className={`inline-block px-3 py-1 rounded-full text-xs ${isDark ? "bg-gray-700" : "bg-gray-100"}`}>
                                            {endpoint.responseFormat}
                                        </span>
                                    </div>
                                </div>
                            </motion.div>
                        </motion.div>)}
                        {filteredEndpoints.length === 0 && <motion.div
                            className={`text-center p-10 rounded-lg border ${isDark ? "bg-gray-800 border-gray-700" : "bg-gray-50 border-gray-200"}`}
                            variants={{
                                hidden: {
                                    opacity: 0,
                                    y: 20
                                },

                                visible: {
                                    opacity: 1,
                                    y: 0
                                }
                            }}>
                            <i className="fas fa-search text-2xl mb-3 text-gray-400"></i>
                            <h3
                                className={`font-medium mb-1 ${isDark ? "text-gray-300" : "text-gray-700"}`}>没有找到匹配的API
                                                </h3>
                            <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>尝试调整搜索条件或筛选类别
                                                </p>
                        </motion.div>}
                    </motion.div>
                    {}
                    <motion.div
                        className={`mt-12 p-6 rounded-xl border ${isDark ? "bg-gray-800/80 border-gray-700" : "bg-white/80 border-gray-100 shadow-md"}`}
                        initial={{
                            opacity: 0,
                            y: 20
                        }}
                        animate={{
                            opacity: 1,
                            y: 0
                        }}
                        transition={{
                            duration: 0.5,
                            delay: 0.3
                        }}>
                        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                            <i className="fas fa-rocket text-indigo-500"></i>快速开始
                                        </h2>
                        <p className={`mb-4 ${isDark ? "text-gray-300" : "text-gray-700"}`}>要开始使用我们的API，请按照以下步骤操作：
                                        </p>
                        <ol
                            className={`list-decimal pl-5 space-y-2 mb-4 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                            <li>获取API密钥（在实际环境中，您需要从控制面板获取）</li>
                            <li>根据需要选择合适的API端点</li>
                            <li>构建请求，包含所有必需参数</li>
                            <li>发送请求并处理响应</li>
                        </ol>
                        <div className="mt-4">
                            <button
                                className={`px-4 py-2 rounded-lg ${isDark ? "bg-indigo-600 hover:bg-indigo-700" : "bg-indigo-600 hover:bg-indigo-700"} text-white font-medium transition-colors flex items-center gap-1`}>
                                <i className="fas fa-book"></i>查看完整API文档
                                              </button>
                        </div>
                    </motion.div>
                </motion.div>
            </div>
            <footer
                className={`py-6 mt-auto ${isDark ? "bg-gray-900 border-t border-gray-800" : "bg-white border-t border-gray-200"}`}>
                <div className="container mx-auto px-4 text-center">
                    <p className={`text-sm ${isDark ? "text-gray-500" : "text-gray-600"}`}>© 2025 COREX AI 团队 | API文档
                                  </p>
                </div>
            </footer>
        </div>
    );
};

export default ApiPage;