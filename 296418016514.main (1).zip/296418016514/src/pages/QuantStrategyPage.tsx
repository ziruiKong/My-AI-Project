import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useTheme } from "../hooks/useTheme";
import NavigationBar from "../components/NavigationBar";
import { Link } from "react-router-dom";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart, BarChart, Bar } from "recharts";

// 模拟的回测数据
const backtestData = [
  { month: '1月', return: 2.5, benchmark: 1.2 },
  { month: '2月', return: 3.2, benchmark: 1.5 },
  { month: '3月', return: -1.8, benchmark: -0.5 },
  { month: '4月', return: 4.5, benchmark: 2.1 },
  { month: '5月', return: 3.8, benchmark: 2.4 },
  { month: '6月', return: 5.2, benchmark: 3.0 },
  { month: '7月', return: -0.5, benchmark: -1.2 },
  { month: '8月', return: 2.9, benchmark: 1.8 },
  { month: '9月', return: 6.1, benchmark: 3.5 },
  { month: '10月', return: 4.2, benchmark: 2.6 },
  { month: '11月', return: 2.8, benchmark: 1.7 },
  { month: '12月', return: 5.5, benchmark: 3.2 },
];

// 模拟的风险指标数据
const riskMetrics = [
  { name: '年化收益率', value: '24.3%' },
  { name: '最大回撤', value: '12.5%' },
  { name: '夏普比率', value: '2.8' },
  { name: 'Sortino比率', value: '3.2' },
  { name: '胜率', value: '62.8%' },
  { name: '盈亏比', value: '1.8' },
];

// 模拟的压力指标数据
const stressData = [
  { day: '第100天', p_stress: 0.1, crisis: false },
  { day: '第200天', p_stress: 0.2, crisis: false },
  { day: '第300天', p_stress: 0.7, crisis: true },
  { day: '第400天', p_stress: 0.9, crisis: true },
  { day: '第500天', p_stress: 0.3, crisis: false },
  { day: '第600天', p_stress: 0.1, crisis: false },
  { day: '第700天', p_stress: 0.2, crisis: false },
  { day: '第800天', p_stress: 0.8, crisis: true },
  { day: '第820天', p_stress: 1.0, crisis: true },
  { day: '第840天', p_stress: 0.4, crisis: false },
  { day: '第900天', p_stress: 0.2, crisis: false },
  { day: '第1000天', p_stress: 0.1, crisis: false },
];

// 模拟的净值曲线数据
const equityCurveData = [
  { day: '第1天', corexq: 1.000, baseline: 1.000 },
  { day: '第200天', corexq: 1.250, baseline: 1.248 },
  { day: '第400天', corexq: 1.420, baseline: 1.410 },
  { day: '第600天', corexq: 1.580, baseline: 1.572 },
  { day: '第800天', corexq: 1.720, baseline: 1.720 },
  { day: '第820天', corexq: 1.650, baseline: 1.600 },
  { day: '第840天', corexq: 1.700, baseline: 1.640 },
  { day: '第1000天', corexq: 1.832, baseline: 1.784 },
];

// 模拟的回撤曲线数据
const drawdownData = [
  { day: '第1天', corexq: 0, baseline: 0 },
  { day: '第200天', corexq: -5.2, baseline: -5.3 },
  { day: '第400天', corexq: -8.1, baseline: -8.5 },
  { day: '第600天', corexq: -6.4, baseline: -6.7 },
  { day: '第800天', corexq: -4.2, baseline: -4.2 },
  { day: '第820天', corexq: -26.6, baseline: -28.5 },
  { day: '第840天', corexq: -19.2, baseline: -22.4 },
  { day: '第1000天', corexq: 0, baseline: 0 },
];

// 模拟的因子收益拆解数据
const factorContributionData = [
  { day: '第1天', alpha: 1.000, risk: 1.000, combined: 1.000 },
  { day: '第200天', alpha: 1.220, risk: 1.010, combined: 1.250 },
  { day: '第400天', alpha: 1.380, risk: 1.020, combined: 1.420 },
  { day: '第600天', alpha: 1.540, risk: 1.030, combined: 1.580 },
  { day: '第800天', alpha: 1.690, risk: 1.020, combined: 1.720 },
  { day: '第820天', alpha: 1.610, risk: 1.025, combined: 1.650 },
  { day: '第840天', alpha: 1.650, risk: 1.030, combined: 1.700 },
  { day: '第1000天', alpha: 1.780, risk: 1.030, combined: 1.832 },
];

// 模拟的跨资产表现数据
const crossAssetData = [
  { asset: '股票', annualReturn: 18.5, maxDrawdown: 15.2, sharpeRatio: 1.9 },
  { asset: '债券', annualReturn: 8.2, maxDrawdown: 4.5, sharpeRatio: 2.3 },
  { asset: '商品', annualReturn: 12.8, maxDrawdown: 18.7, sharpeRatio: 1.7 },
  { asset: '外汇', annualReturn: 10.5, maxDrawdown: 9.3, sharpeRatio: 2.1 },
];

// 模拟的风险因子暴露数据
const riskExposureData = [
  { factor: '市场风险', exposure: 0.95, maxLimit: 1.0 },
  { factor: '规模因子', exposure: -0.23, maxLimit: 0.5 },
  { factor: '价值因子', exposure: 0.45, maxLimit: 0.5 },
  { factor: '动量因子', exposure: 0.32, maxLimit: 0.5 },
  { factor: '质量因子', exposure: 0.18, maxLimit: 0.5 },
  { factor: '流动性因子', exposure: -0.12, maxLimit: 0.5 },
];

// 模拟的策略配置数据
const strategyConfig = [
  { name: '交易频率', value: '高频' },
  { name: '资产类别', value: '股票、ETF、期货' },
  { name: '市场覆盖', value: 'A股、美股、港股' },
  { name: '适用市场', value: '震荡、趋势' },
  { name: '最大杠杆', value: '1.5x' },
  { name: '资金门槛', value: '10万' },
];

const QuantStrategyPage: React.FC = () => {
  const { isDark } = useTheme();
  const [activeSection, setActiveSection] = useState('overview');
  const [isChartVisible, setIsChartVisible] = useState(false);

  // 页面加载动画
  useEffect(() => {
    setIsChartVisible(true);
    
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { 
      y: 0, 
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };
  
  const chartVariants = {
    hidden: { opacity: 0, scale: 0.95 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: { duration: 0.8, delay: 0.3 }
    }
  };

  // 模拟年化收益计算
  const calculateAnnualReturn = () => {
    return '24.3%';
  };

  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-black">
      {/* 背景装饰 */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(circle_at_center,rgba(168,85,247,0.15)_0%,rgba(139,92,246,0.05)_50%,transparent_100%)]"></div>
      
      {/* 导航栏 */}
      <NavigationBar currentPage="/q/quant-strategy" />
      
      {/* 主内容区域 */}
      <div className="flex-grow relative z-10 flex flex-col px-4 py-12">
        <motion.div
          className="max-w-6xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* 页面标题 */}
          <motion.div 
            className="mb-16 text-center"
            variants={itemVariants}
          >
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white mb-6">
              <i className="fas fa-chart-line text-3xl"></i>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-white">Prism.1-UFRM 量化策略</h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              基于AI Agent COREX Q 的普适性量化交易策略，融合多源信息和智能风险管理
            </p>
            
            {/* 关键指标卡片 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 max-w-4xl mx-auto">
              <motion.div 
                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                variants={itemVariants}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">年化收益率</h3>
                <p className="text-3xl font-bold text-white flex items-center">
                  {calculateAnnualReturn()}
                  <span className="ml-2 text-green-400 text-sm font-normal">
                    <i className="fas fa-arrow-up"></i> +6.8%
                  </span>
                </p>
              </motion.div>
              
              <motion.div 
                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                variants={itemVariants}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">最大回撤</h3>
                <p className="text-3xl font-bold text-white">12.5%</p>
              </motion.div>
              
              <motion.div 
                className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                variants={itemVariants}
                whileHover={{ 
                  y: -5,
                  boxShadow: "0 25px 50px -12px rgba(139, 92, 246, 0.25)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">夏普比率</h3>
                <p className="text-3xl font-bold text-white">2.8</p>
              </motion.div>
            </div>
          </motion.div>
          
          {/* 内容导航 */}
          <motion.div 
            className="flex flex-wrap justify-center gap-2 mb-12"
            variants={itemVariants}
          >
            {['overview', 'performance', 'strategy', 'metrics', 'apply'].map((section) => (
              <motion.button
                key={section}
                onClick={() => setActiveSection(section)}
                className={`px-5 py-2.5 rounded-full text-sm transition-all ${
                  activeSection === section 
                    ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg" 
                    : "bg-white/10 border border-white/20 text-gray-300 hover:bg-white/20"
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {section === 'overview' && '概览'}
                {section === 'performance' && '历史表现'}
                {section === 'strategy' && '策略原理'}
                {section === 'metrics' && '风险指标'}
                {section === 'apply' && '应用配置'}
              </motion.button>
            ))}
          </motion.div>
          
          {/* 内容区域 */}
          <div className="space-y-16">
            {/* 概览部分 */}
            {activeSection === 'overview' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="grid grid-cols-1 lg:grid-cols-5 gap-8"
              >
                <motion.div className="lg:col-span-3" variants={itemVariants}>
                  <h2 className="text-2xl font-bold mb-6 text-white">策略概览</h2>
                  <div className="space-y-6 text-gray-300">
                    <p>COREX Q 量化策略是基于深度学习的综合性投资策略，融合了多因子模型、技术分析和市场情绪分析，旨在捕捉市场中的短期波动和中长期趋势。</p>
                    <p>该策略通过对海量市场数据的深度学习，自动识别交易机会，并在风险可控的前提下实现超额收益。策略覆盖A股、美股和港股市场，可投资于股票、ETF和期货等多种资产类别。</p>
                    <p>策略的核心优势在于其自适应能力，能够根据市场环境的变化自动调整参数和权重，保持策略的有效性和适应性。</p>
                  </div>
                </motion.div>
                
                <motion.div className="lg:col-span-2" variants={itemVariants}>
                  <h2 className="text-2xl font-bold mb-6 text-white">适合人群</h2>
                  <ul className="space-y-4 text-gray-300">
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                      <span>寻求稳定超额收益的投资者</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                      <span>对量化投资感兴趣，但缺乏专业知识的投资者</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                      <span>希望降低投资情绪影响的投资者</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check-circle text-green-500 mt-1 mr-3"></i>
                      <span>有一定风险承受能力，追求长期稳健回报的投资者</span>
                    </li>
                  </ul>
                </motion.div>
              </motion.div>
            )}
            
            {/* 历史表现部分 */}
            {activeSection === 'performance' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <motion.h2 variants={itemVariants} className="text-2xl font-bold mb-8 text-white">历史表现</motion.h2>
                 <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">近一年收益率对比</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={backtestData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="month" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                          formatter={(value) => [`${value}%`, '']}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="return" 
                          stroke="#8b5cf6" 
                          strokeWidth={3} 
                          dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          activeDot={{ r: 8, stroke: '#8b5cf6', strokeWidth: 2, fill: '#c4b5fd' }}
                          name="COREX Q策略"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="benchmark" 
                          stroke="#64748b" 
                          strokeWidth={2}
                          strokeDasharray="5 5" 
                          dot={{ stroke: '#64748b', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="基准指数"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>

                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">策略净值曲线对比</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={equityCurveData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="day" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" domain={[0.9, 2.0]} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="corexq" 
                          stroke="#8b5cf6" 
                          strokeWidth={3} 
                          dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          activeDot={{ r: 8, stroke: '#8b5cf6', strokeWidth: 2, fill: '#c4b5fd' }}
                          name="COREX Q策略（融合风险）"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="baseline" 
                          stroke="#64748b" 
                          strokeWidth={3}
                          dot={{ stroke: '#64748b', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="基线策略（无风险控制）"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    净值曲线显示，在平稳时期两策略表现相似，但在危机时期（第820天左右）COREX Q策略表现更优，最终净值达到1.832，领先基线策略约2.7%。
                  </p>
                </motion.div>

                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">最大回撤曲线</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={drawdownData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="day" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                          formatter={(value) => [`${value}%`, '']}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="corexq" 
                          stroke="#8b5cf6" 
                          strokeWidth={3} 
                          dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="COREX Q策略"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="baseline" 
                          stroke="#64748b" 
                          strokeWidth={3}
                          dot={{ stroke: '#64748b', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="基线策略"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    回撤曲线显示，COREX Q策略的最大回撤为26.6%，低于基线策略的28.5%，表明风险控制模块有效降低了最大损失。
                  </p>
                </motion.div>

                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">因子收益拆解</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={factorContributionData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="day" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" domain={[0.9, 2.0]} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="alpha" 
                          stroke="#10b981" 
                          strokeWidth={2}
                          dot={{ stroke: '#10b981', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="Alpha组件（传统因子）"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="risk" 
                          stroke="#f59e0b" 
                          strokeWidth={2}
                          dot={{ stroke: '#f59e0b', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          name="风险对冲组件"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="combined" 
                          stroke="#8b5cf6" 
                          strokeWidth={3} 
                          dot={{ stroke: '#8b5cf6', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          activeDot={{ r: 8, stroke: '#8b5cf6', strokeWidth: 2, fill: '#c4b5fd' }}
                          name="COREX Q完整策略"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    因子收益拆解显示，Alpha组件是组合收益的主要驱动（约94%），风险对冲组件主要在危机时期提供保护（约6%），两者结合形成COREX Q完整策略。
                  </p>
                </motion.div>

                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">跨资产表现</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={crossAssetData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="asset" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                          formatter={(value, name) => {
                            if (name === 'annualReturn') return [`${value}%`, '年化收益率'];
                            if (name === 'maxDrawdown') return [`${value}%`, '最大回撤'];
                            return [value, '夏普比率'];
                          }}
                        />
                        <Bar dataKey="annualReturn" fill="#8b5cf6" name="年化收益率" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="maxDrawdown" fill="#f43f5e" name="最大回撤" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="sharpeRatio" fill="#10b981" name="夏普比率" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    COREX Q策略在不同资产类别上均表现良好，体现了其跨资产的普适性。
                  </p>
                </motion.div>

                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">压力指标(p_stress)变化</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={stressData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="day" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" domain={[0, 1]} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="p_stress" 
                          stroke="#f43f5e" 
                          strokeWidth={3} 
                          dot={{ stroke: '#f43f5e', strokeWidth: 2, r: 4, fill: '#0f172a' }}
                          activeDot={{ r: 8, stroke: '#f43f5e', strokeWidth: 2, fill: '#fca5a5' }}
                          name="压力指标"
                        />
                        {/* 标记危机时期 */}
                        <defs>
                          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                            <feGaussianBlur stdDeviation="3" result="blur" />
                            <feComposite in="SourceGraphic" in2="blur" operator="over" />
                          </filter>
                        </defs>
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    压力指标(p_stress)在危机时期（如第400天和第820天左右）显著升高，COREX Q策略根据这一指标自动调整风险敞口。
                  </p>
                </motion.div>
              </motion.div>
            )}
            
            {/* 策略原理部分 */}
            {activeSection === 'strategy' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <motion.h2 variants={itemVariants} className="text-2xl font-bold mb-8 text-white">策略原理</motion.h2>
                
                <div className="space-y-8">
                  <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                        <i className="fas fa-brain text-xl"></i>
                      </div>
                      <h3 className="text-xl font-semibold mb-3 text-white">深度学习模型</h3>
                      <p className="text-gray-300">
                        采用多层神经网络结构，融合LSTM、Transformer等先进深度学习技术，自动学习市场数据中的非线性关系和时序特征。
                      </p>
                    </div>
                    
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                        <i className="fas fa-chart-pie text-xl"></i>
                      </div>
                      <h3 className="text-xl font-semibold mb-3 text-white">多因子分析</h3>
                      <p className="text-gray-300">
                        综合考虑技术指标、基本面数据和市场情绪等多种因子，通过深度学习自动分配因子权重，捕捉市场中的alpha机会。
                      </p>
                    </div>
                    
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center mb-4 text-white">
                        <i className="fas fa-shield-alt text-xl"></i>
                      </div>
                      <h3 className="text-xl font-semibold mb-3 text-white">风险管理框架</h3>
                      <p className="text-gray-300">
                        内置多维度风险控制机制，包括仓位管理、止损策略和流动性管理，确保在追求收益的同时有效控制风险。
                      </p>
                    </div>
                  </motion.div>
                  
                   <motion.div variants={itemVariants} className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                    <h3 className="text-xl font-semibold mb-4 text-white">策略流程</h3>
                    <div className="relative">
                      <div className="absolute top-0 bottom-0 left-6 w-0.5 bg-indigo-600/50"></div>
                      
                      <div className="relative pl-16 pb-8">
                        <div className="absolute left-4 top-0 w-4 h-4 rounded-full bg-indigo-600"></div>
                        <h4 className="text-lg font-medium mb-2 text-white">数据收集与预处理</h4>
                        <p className="text-gray-300">
                          收集市场行情、财务数据、新闻舆情等多源数据，进行清洗、标准化和特征工程处理，为模型训练做准备。
                        </p>
                      </div>
                      
                      <div className="relative pl-16 pb-8">
                        <div className="absolute left-4 top-0 w-4 h-4 rounded-full bg-indigo-600"></div>
                        <h4 className="text-lg font-medium mb-2 text-white">模型训练与优化</h4>
                        <p className="text-gray-300">
                          使用深度学习框架训练预测模型，通过交叉验证和参数调优，确保模型的泛化能力和稳定性。
                        </p>
                      </div>
                      
                      <div className="relative pl-16 pb-8">
                        <div className="absolute left-4 top-0 w-4 h-4 rounded-full bg-indigo-600"></div>
                        <h4 className="text-lg font-medium mb-2 text-white">信号生成与过滤</h4>
                        <p className="text-gray-300">
                          模型根据输入数据生成交易信号，经过风险过滤、相关性检验等多道筛选，确定最终交易标的和时机。
                        </p>
                      </div>
                      
                      <div className="relative pl-16 pb-8">
                        <div className="absolute left-4 top-0 w-4 h-4 rounded-full bg-indigo-600"></div>
                        <h4 className="text-lg font-medium mb-2 text-white">组合优化与配置</h4>
                        <p className="text-gray-300">
                          根据风险偏好和收益目标，使用现代投资组合理论进行资产配置和权重优化，构建最优投资组合。
                        </p>
                      </div>
                      
                      <div className="relative pl-16">
                        <div className="absolute left-4 top-0 w-4 h-4 rounded-full bg-indigo-600"></div>
                        <h4 className="text-lg font-medium mb-2 text-white">执行与监控</h4>
                        <p className="text-gray-300">
                          自动执行交易指令，实时监控市场变化和组合表现，根据市场环境变化动态调整策略参数。
                        </p>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            )}
            
            {/* 因子暴露与风险控制部分 */}
            {activeSection === 'strategy' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                className="mt-12"
              >
                <motion.h2 variants={itemVariants} className="text-2xl font-bold mb-8 text-white">风险因子暴露控制</motion.h2>
                <motion.div 
                  variants={chartVariants}
                  className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-white">策略因子暴露情况</h3>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={riskExposureData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="factor" stroke="#94a3b8" />
                        <YAxis stroke="#94a3b8" domain={[-1, 1]} />
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: 'rgba(15, 23, 42, 0.9)', 
                            borderColor: '#475569',
                            borderRadius: '8px',
                            color: '#f1f5f9'
                          }}
                        />
                        <Bar dataKey="exposure" fill="#8b5cf6" name="因子暴露度" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="maxLimit" fill="#f43f5e" name="最大允许暴露度" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="mt-4 text-sm text-gray-400">
                    COREX Q策略严格控制各因子的暴露度，确保组合风险水平符合预设目标，避免过度暴露于单一风险因子。
                  </p>
                </motion.div>

                <motion.div variants={itemVariants} className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                  <h3 className="text-xl font-semibold mb-4 text-white">风险控制的自适应机制</h3>
                  <div className="space-y-6 text-gray-300">
                    <p>COREX Q策略通过动态调整风险厌恶系数λ，实现对市场压力的自适应响应。当市场压力指标p_stress升高时，策略自动增加风险厌恶程度，降低仓位和杠杆水平，从而减少潜在损失。</p>
                    <p>风险控制公式：λ_t = λ_0 × (1 + c × p_stress,t)</p>
                    <p>其中：</p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>λ_0 是基准风险厌恶系数</li>
                      <li>c 是调节系数，控制压力时期的风险厌恶程度增加幅度</li>
                      <li>p_stress,t 是t时刻的市场压力概率</li>
                    </ul>
                  </div>
                </motion.div>
              </motion.div>
            )}
            
            {/* 风险指标部分 */}
            {activeSection === 'metrics' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <motion.h2 variants={itemVariants} className="text-2xl font-bold mb-8 text-white">风险指标</motion.h2>
                
                <motion.div 
                  variants={itemVariants}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8"
                >
                  {riskMetrics.map((metric, index) => (
                    <div 
                      key={index}
                      className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                    >
                      <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">{metric.name}</h3>
                      <p className="text-3xl font-bold text-white">{metric.value}</p>
                    </div>
                  ))}
                </motion.div>
                
                <motion.div variants={itemVariants} className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg">
                  <h3 className="text-xl font-semibold mb-6 text-white">风险说明</h3>
                  <div className="space-y-6 text-gray-300">
                    <p>
                      <span className="text-white font-medium">市场风险：</span>
                      量化策略虽然基于历史数据和模型预测，但无法完全规避市场系统性风险，在极端市场环境下可能面临较大回撤。
                    </p>
                    <p>
                      <span className="text-white font-medium">模型风险：</span>
                      模型基于历史数据构建，存在过拟合风险，当市场环境发生重大变化时，模型预测准确性可能下降。
                    </p>
                    <p>
                      <span className="text-white font-medium">流动性风险：</span>
                      在市场流动性不足的情况下，策略可能面临无法及时以预期价格执行交易的风险。
                    </p>
                    <p>
                      <span className="text-white font-medium">操作风险：</span>
                      包括系统故障、网络中断等技术因素可能导致的交易执行问题。
                    </p>
                    <p className="mt-8 text-yellow-300">
                      <i className="fas fa-exclamation-triangle mr-2"></i>
                      投资有风险，入市需谨慎。过往业绩不代表未来表现。请根据自身风险承受能力谨慎选择投资策略。
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            )}
            
            {/* 应用配置部分 */}
            {activeSection === 'apply' && (
              <motion.div
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                <motion.h2 variants={itemVariants} className="text-2xl font-bold mb-8 text-white">应用配置</motion.h2>
                
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <motion.div variants={itemVariants} className="lg:col-span-1">
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg h-full">
                      <h3 className="text-xl font-semibold mb-4 text-white">策略参数</h3>
                      <div className="space-y-4">
                        {strategyConfig.map((config, index) => (
                          <div key={index} className="flex justify-between items-center border-b border-white/10 pb-3">
                            <span className="text-gray-400">{config.name}</span>
                            <span className="text-white font-medium">{config.value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                  
                  <motion.div variants={itemVariants} className="lg:col-span-2">
                    <div className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg mb-6">
                      <h3 className="text-xl font-semibold mb-4 text-white">如何开始</h3>
                      <ol className="space-y-4 text-gray-300">
                        <li className="flex items-start">
                          <span className="bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">1</span>
                          <span>登录COREX Q平台，完成实名认证和风险评估</span>
                        </li>
                        <li className="flex items-start">
                          <span className="bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">2</span>
                          <span>在"策略市场"中找到"COREX Q 量化策略"，点击"订阅"按钮</span>
                        </li>
                        <li className="flex items-start">
                          <span className="bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">3</span>
                          <span>设置投资金额、风险偏好等参数，确认策略配置</span>
                        </li>
                        <li className="flex items-start">
                          <span className="bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">4</span>
                          <span>完成支付，策略将自动开始运行</span>
                        </li>
                        <li className="flex items-start">
                          <span className="bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">5</span>
                          <span>在"我的策略"中查看策略运行状态和收益情况</span>
                        </li>
                      </ol>
                    </div>
                    
                    <motion.div 
                      variants={itemVariants}
                      className="p-6 rounded-xl backdrop-blur-xl bg-white/10 border border-white/20 shadow-lg"
                    >
                      <h3 className="text-xl font-semibold mb-4 text-white">联系我们</h3>
                      <p className="text-gray-300 mb-6">
                        如有任何问题或需要定制策略，请联系我们的专业团队获取支持
                      </p>
                      <div className="flex flex-wrap gap-4">
                        <motion.button
                          className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium flex items-center justify-center gap-2"
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.97 }}
                        >
                          <i className="fas fa-comments"></i>
                          在线咨询
                        </motion.button>
                        
                        <motion.button
                          className="px-6 py-3 rounded-lg bg-white/10 border border-white/20 text-white font-medium flex items-center justify-center gap-2"
                          whileHover={{ scale: 1.03, backgroundColor: "rgba(255, 255, 255, 0.15)" }}
                          whileTap={{ scale: 0.97 }}
                        >
                          <i className="fas fa-file-alt"></i>
                          查看文档
                        </motion.button>
                      </div>
                    </motion.div>
                  </motion.div>
                </div>
              </motion.div>
            )}
          </div>
          
          {/* 行动按钮 */}
          <motion.div 
            className="mt-16 text-center"
            variants={itemVariants}
          >
            <motion.button
              className="px-8 py-4 rounded-lg bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium text-lg flex items-center justify-center mx-auto gap-2"
              whileHover={{ 
                scale: 1.03,
                boxShadow: "0 0 25px rgba(139, 92, 246, 0.4)" 
              }}
              whileTap={{ scale: 0.97 }}
            >
              <i className="fas fa-rocket"></i>
              立即订阅COREX Q量化策略
            </motion.button>
            <p className="mt-4 text-gray-400 text-sm">
              风险提示：投资有风险，入市需谨慎
            </p>
          </motion.div>
        </motion.div>
      </div>
      
      {/* 返回按钮 */}
      <div className="p-6 relative z-10">
        <Link to="/q" className="inline-flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors">
          <i className="fas fa-arrow-left"></i>
          <span>返回COREX Q主页</span>
        </Link>
      </div>
      
      {/* 页脚 */}
      <footer className="py-6 text-center text-gray-500 text-sm mt-auto">
        <p>© 2025 COREX 人工智能 | COREX Q</p>
      </footer>
    </div>
  );
};

export default QuantStrategyPage;