import { Routes, Route, Link } from "react-router-dom";
import Home from "@/pages/Home";
import About from "@/pages/About";
import MusicLibrary from "@/pages/MusicLibrary";
import LogPage from "@/pages/LogPage";
import ApiPage from "@/pages/ApiPage";
import CodeRuntimePage from "@/pages/CodeRuntimePage";
import CorexQPage from "@/pages/CorexQPage";
import FavoritesPage from "@/pages/FavoritesPage";
import StrategyPage from "@/pages/StrategyPage";
import ResearchPage from "@/pages/ResearchPage";
import AgentPage from "@/pages/AgentPage";
import QuantStrategyPage from "@/pages/QuantStrategyPage";
import QuantStrategyHomePage from "@/pages/QuantStrategyHomePage";
import DatabasePage from "@/pages/DatabasePage";
import GREQuestionBankPage from "@/pages/GREQuestionBankPage";
import GREQuestionEditorPage from "@/pages/GREQuestionEditorPage";
import GRERealExamPage from "@/pages/GRERealExamPage";
import GREQuestionPracticePage from "@/pages/GREQuestionPracticePage";
import { ChatProvider } from './contexts/chatContext';
import { motion } from 'framer-motion';

export default function App() {
  return (
    <ChatProvider>
      <Routes>
         {/* 首页路由 */}
        <Route path="/" element={<Home />} />
        {/* 运行时路由 */}
        <Route path="/runtime" element={<CodeRuntimePage />} />
        {/* 其他页面路由暂时重定向到首页 */}
        <Route path="/api" element={<ApiPage />} />
        <Route path="/dashboard" element={<Home />} />
        <Route path="/log" element={<LogPage />} />
        {/* 关于我们页面 */}
        <Route path="/about" element={<About />} />
        <Route path="/about-us" element={<About />} />
        {/* 音乐库页面 */}
        <Route path="/music" element={<MusicLibrary />} />
         {/* 代码运行时路由 */}
        <Route path="/code-runtime" element={<CodeRuntimePage />} />
         {/* 收藏夹页面 */}
        <Route path="/favorites" element={<FavoritesPage />} />
          {/* COREX Q 页面 */}
         <Route path="/q" element={<CorexQPage />} />
        {/* 重定向 /runtime/q 到 /q */}
        <Route path="/runtime/q" element={<CorexQPage />} />
        {/* 确保所有子页面在runtime路径下也能访问 */}
        <Route path="/runtime/q/strategy" element={<StrategyPage />} />
        <Route path="/runtime/q/research" element={<ResearchPage />} />
        <Route path="/runtime/q/agent" element={<AgentPage />} />
         <Route path="/runtime/q/quant-strategy" element={<QuantStrategyPage />} />
         {/* 运行时量化策略主页 */}
         <Route path="/runtime/q/quant-strategy-home" element={<QuantStrategyHomePage />} />
        {/* 标准路径 */}
        <Route path="/q/strategy" element={<StrategyPage />} />
        <Route path="/q/research" element={<ResearchPage />} />
        <Route path="/q/agent" element={<AgentPage />} />
         <Route path="/q/quant-strategy" element={<QuantStrategyPage />} />
         {/* 量化策略主页 */}
         <Route path="/q/quant-strategy-home" element={<QuantStrategyHomePage />} />
         {/* 数据库页面 */}
        <Route path="/database" element={<DatabasePage />} />
        <Route path="/runtime/database" element={<DatabasePage />} />
        {/* GRE题库页面 */}
        <Route path="/gre-question-bank" element={<GREQuestionBankPage />} />
        <Route path="/gre-question-bank/add" element={<GREQuestionEditorPage />} />
        <Route path="/gre-question-bank/edit/:id" element={<GREQuestionEditorPage />} />
        <Route path="/gre-question-bank/view/:id" element={<GREQuestionEditorPage />} />
        <Route path="/gre-question-bank/practice" element={<GREQuestionPracticePage />} />
        <Route path="/gre-question-bank/exam" element={<GRERealExamPage />} />
        {/* 运行时GRE题库页面 */}
        <Route path="/runtime/gre-question-bank" element={<GREQuestionBankPage />} />
        <Route path="/runtime/gre-question-bank/add" element={<GREQuestionEditorPage />} />
        <Route path="/runtime/gre-question-bank/edit/:id" element={<GREQuestionEditorPage />} />
        <Route path="/runtime/gre-question-bank/practice" element={<GREQuestionPracticePage />} />
        <Route path="/runtime/gre-question-bank/exam" element={<GRERealExamPage />} />
        <Route path="/runtime/gre-question-bank/view/:id" element={<GREQuestionEditorPage />} />
        <Route path="/runtime/gre-question-bank/practice" element={<GREQuestionPracticePage />} />
        {/* 404页面 */}
        <Route path="*" element={
          <div className="min-h-screen flex flex-col items-center justify-center text-xl font-medium p-4">
            <h1 className="text-4xl font-bold mb-4">404 - 页面未找到</h1>
            <p className="mb-8 text-center">抱歉，您访问的页面不存在或已被删除</p>
            <Link to="/" className="px-6 py-3 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 transition-colors">
              返回首页
            </Link>
          </div>
        } />
      </Routes>
    </ChatProvider>
  );
}
