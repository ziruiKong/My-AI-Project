// useStorage.ts - React hooks for accessing storage service

import { useState, useEffect, useCallback } from 'react';
import { storageService, UploadedImage, KnowledgeItem, GREQuestion } from '../lib/StorageService';

/**
 * Hook for managing uploaded images
 */
export const useImages = () => {
  const [images, setImages] = useState<UploadedImage[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Load images initially
  useEffect(() => {
    const loadImages = async () => {
      try {
        const loadedImages = await storageService.getImages();
        setImages(loadedImages);
      } catch (error) {
        console.error('Error loading images:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadImages();
  }, []);
  
  // Add a new image
  const addImage = useCallback(async (image: Omit<UploadedImage, 'id' | 'uploadDate'>): Promise<UploadedImage> => {
    try {
      const newImage = await storageService.addImage(image);
      setImages(prev => [...prev, newImage]);
      return newImage;
    } catch (error) {
      console.error('Error adding image:', error);
      throw error;
    }
  }, []);
  
  // Update an existing image
  const updateImage = useCallback(async (id: string, updates: Partial<UploadedImage>): Promise<boolean> => {
    try {
      const success = await storageService.updateImage(id, updates);
      if (success) {
        setImages(prev => prev.map(img => 
          img.id === id ? { ...img, ...updates } : img
        ));
      }
      return success;
    } catch (error) {
      console.error('Error updating image:', error);
      return false;
    }
  }, []);
  
  // Delete an image
  const deleteImage = useCallback(async (id: string): Promise<boolean> => {
    try {
      const success = await storageService.deleteImage(id);
      if (success) {
        setImages(prev => prev.filter(img => img.id !== id));
      }
      return success;
    } catch (error) {
      console.error('Error deleting image:', error);
      return false;
    }
  }, []);
  
  // Get images by filter
  const getImagesByFilter = useCallback((filter: (image: UploadedImage) => boolean): UploadedImage[] => {
    try {
      return images.filter(filter);
    } catch (error) {
      console.error('Error filtering images:', error);
      return [];
    }
  }, [images]);
  
  return {
    images,
    loading,
    addImage,
    updateImage,
    deleteImage,
    getImagesByFilter
  };
};

/**
 * Hook for managing knowledge items
 */
export const useKnowledge = () => {
  const [knowledgeItems, setKnowledgeItems] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Load knowledge items initially
  useEffect(() => {
    const loadKnowledgeItems = async () => {
      try {
        const items = await storageService.getKnowledgeItems();
        setKnowledgeItems(items);
      } catch (error) {
        console.error('Error loading knowledge items:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadKnowledgeItems();
  }, []);
  
  // Add a new knowledge item
  const addKnowledgeItem = useCallback(async (item: Omit<KnowledgeItem, 'id' | 'createDate'>): Promise<KnowledgeItem> => {
    try {
      const newItem = await storageService.addKnowledgeItem(item);
      setKnowledgeItems(prev => [...prev, newItem]);
      return newItem;
    } catch (error) {
      console.error('Error adding knowledge item:', error);
      throw error;
    }
  }, []);
  
  // Update an existing knowledge item
  const updateKnowledgeItem = useCallback(async (id: string, updates: Partial<KnowledgeItem>): Promise<boolean> => {
    try {
      const success = await storageService.updateKnowledgeItem(id, updates);
      if (success) {
        setKnowledgeItems(prev => prev.map(item => 
          item.id === id ? { ...item, ...updates, updateDate: new Date().toISOString() } : item
        ));
      }
      return success;
    } catch (error) {
      console.error('Error updating knowledge item:', error);
      return false;
    }
  }, []);
  
  // Delete a knowledge item
  const deleteKnowledgeItem = useCallback(async (id: string): Promise<boolean> => {
    try {
      const success = await storageService.deleteKnowledgeItem(id);
      if (success) {
        setKnowledgeItems(prev => prev.filter(item => item.id !== id));
      }
      return success;
    } catch (error) {
      console.error('Error deleting knowledge item:', error);
      return false;
    }
  }, []);
  
  // Get knowledge items by category
  const getKnowledgeItemsByCategory = useCallback((category: string): KnowledgeItem[] => {
    try {
      return knowledgeItems.filter(item => item.category === category);
    } catch (error) {
      console.error('Error filtering knowledge items by category:', error);
      return [];
    }
  }, [knowledgeItems]);
  
  // Search knowledge items
  const searchKnowledgeItems = useCallback((query: string): KnowledgeItem[] => {
    try {
      const lowerQuery = query.toLowerCase();
      return knowledgeItems.filter(item => 
        item.title.toLowerCase().includes(lowerQuery) || 
        item.content.toLowerCase().includes(lowerQuery) ||
        (item.tags && item.tags.some(tag => tag.toLowerCase().includes(lowerQuery)))
      );
    } catch (error) {
      console.error('Error searching knowledge items:', error);
      return [];
    }
  }, [knowledgeItems]);
  
  return {
    knowledgeItems,
    loading,
    addKnowledgeItem,
    updateKnowledgeItem,
    deleteKnowledgeItem,
    getKnowledgeItemsByCategory,
    searchKnowledgeItems
  };
};

/**
 * Hook for managing database operations (backup/restore)
 */
export const useDatabase = () => {
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [exportResult, setExportResult] = useState<string>('');
  const [importError, setImportError] = useState<string | null>(null);
  
  // Export database
  const exportDatabase = useCallback(async (): Promise<string> => {
    try {
      setExporting(true);
      const data = await storageService.exportDatabase();
      setExportResult(data);
      return data;
    } catch (error) {
      console.error('Error exporting database:', error);
      throw error;
    } finally {
      setExporting(false);
    }
  }, []);
  
  // Import database
  const importDatabase = useCallback(async (jsonData: string): Promise<boolean> => {
    try {
      setImporting(true);
      setImportError(null);
      const success = await storageService.importDatabase(jsonData);
      
      // If successful, reload the window to refresh all data
      if (success) {
        setTimeout(() => {
          window.location.reload();
        }, 500);
      }
      
      return success;
    } catch (error) {
      console.error('Error importing database:', error);
      setImportError(error instanceof Error ? error.message : 'Import failed');
      return false;
    } finally {
      setImporting(false);
    }
  }, []);
  
  // Get database statistics
  const getDatabaseStats = useCallback(async () => {
    try {
      const images = await storageService.getImages();
      const knowledgeItems = await storageService.getKnowledgeItems();
      const greQuestions = await storageService.getGREQuestions();
      const version = await storageService.getMetadata('version');
      const lastInitialized = await storageService.getMetadata('lastInitialized');
      const storageType = await storageService.getMetadata('storageType') || 'Unknown';
      const dbVersion = await storageService.getMetadata('dbVersion') || '1.0.0';
      
      // 计算GRE题目按类型的分布
      const greQuestionsByType = {
        multipleChoice: greQuestions.filter(q => q.type === 'multiple_choice').length,
        readingComprehension: greQuestions.filter(q => q.type === 'reading_comprehension').length
      };
      
      return {
        imageCount: images.length,
        knowledgeCount: knowledgeItems.length,
        greQuestionCount: greQuestions.length,
        greQuestionsByType,
        totalItems: images.length + knowledgeItems.length + greQuestions.length,
        version: version || 'Unknown',
        dbVersion,
        lastInitialized: lastInitialized || 'Never',
        storageType
      };
    } catch (error) {
      console.error('Error getting database statistics:', error);
      return {
        imageCount: 0,
        knowledgeCount: 0,
        greQuestionCount: 0,
        greQuestionsByType: { multipleChoice: 0, readingComprehension: 0 },
        totalItems: 0,
        version: 'Unknown',
        dbVersion: '1.0.0',
        lastInitialized: 'Never',
        storageType: 'Unknown'
      };
    }
  }, []);
  
  return {
    exportDatabase,
    importDatabase,
    getDatabaseStats,
    exporting,
    importing,
    exportResult,
    importError
  };
};

/**
 * Hook for managing GRE questions
 */
export const useGREQuestions = () => {
  const [questions, setQuestions] = useState<GREQuestion[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Load questions initially
  useEffect(() => {
    const loadQuestions = async () => {
      try {
        const loadedQuestions = await storageService.getGREQuestions();
        setQuestions(loadedQuestions);
      } catch (error) {
        console.error('Error loading GRE questions:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadQuestions();
  }, []);
  
  // Add a new question
  const addGREQuestion = useCallback(async (question: Omit<GREQuestion, 'id' | 'createDate'>): Promise<GREQuestion> => {
    try {
      const newQuestion = await storageService.addGREQuestion(question);
      setQuestions(prev => [...prev, newQuestion]);
      return newQuestion;
    } catch (error) {
      console.error('Error adding GRE question:', error);
      throw error;
    }
  }, []);
  
  // Update an existing question
  const updateGREQuestion = useCallback(async (id: string, updates: Partial<GREQuestion>): Promise<boolean> => {
    try {
      const success = await storageService.updateGREQuestion(id, updates);
      if (success) {
        setQuestions(prev => prev.map(question => 
          question.id === id ? { ...question, ...updates } : question
        ));
      }
      return success;
    } catch (error) {
      console.error('Error updating GRE question:', error);
      return false;
    }
  }, []);
  
  // Delete a question
  const deleteGREQuestion = useCallback(async (id: string): Promise<boolean> => {
    try {
      const success = await storageService.deleteGREQuestion(id);
      if (success) {
        setQuestions(prev => prev.filter(question => question.id !== id));
      }
      return success;
    } catch (error) {
      console.error('Error deleting GRE question:', error);
      return false;
    }
  }, []);
  
  // Get questions by filter
  const getQuestionsByFilter = useCallback((filter: (question: GREQuestion) => boolean): GREQuestion[] => {
    try {
      return questions.filter(filter);
    } catch (error) {
      console.error('Error filtering GRE questions:', error);
      return [];
    }
  }, [questions]);
  
  // Get questions by type
  const getQuestionsByType = useCallback((type: 'multiple_choice' | 'reading_comprehension'): GREQuestion[] => {
    try {
      return questions.filter(question => question.type === type);
    } catch (error) {
      console.error('Error getting GRE questions by type:', error);
      return [];
    }
  }, [questions]);
  
  // Get questions by difficulty
  const getQuestionsByDifficulty = useCallback((difficulty: 'easy' | 'medium' | 'hard'): GREQuestion[] => {
    try {
      return questions.filter(question => question.difficulty === difficulty);
    } catch (error) {
      console.error('Error getting GRE questions by difficulty:', error);
      return [];
    }
  }, [questions]);
  
  return {
    questions,
    loading,
    addGREQuestion,
    updateGREQuestion,
    deleteGREQuestion,
    getQuestionsByFilter,
    getQuestionsByType,
    getQuestionsByDifficulty
  };
};