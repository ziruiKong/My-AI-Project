import { useState, useEffect } from 'react';

type Theme = 'light' | 'dark';

// 定义NotificationOptions接口以解决TypeScript类型错误
interface NotificationOptions {
  body?: string;
  icon?: string;
  badge?: string;
  dir?: 'auto' | 'ltr' | 'rtl';
  lang?: string;
  tag?: string;
  image?: string;
  data?: any;
  vibrate?: number[];
  timestamp?: number;
  renotify?: boolean;
  requireInteraction?: boolean;
  silent?: boolean;
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem('theme') as Theme;
    if (savedTheme) {
      return savedTheme;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
  };

  // 请求浏览器通知权限
  const requestNotificationPermission = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  };

  // 显示通知
  const showNotification = async (title: string, options?: NotificationOptions) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
         body: options?.body || '',
        icon: options?.icon || 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=company%20logo%20design%20modern%20technology%20purple%20theme&sign=3b7804d1ed0a915a4abfe8060f2c0887',
        ...options
      });
    } else if ('Notification' in window && Notification.permission !== 'denied') {
      // 如果用户还没有决定，请求权限后再显示通知
      const hasPermission = await requestNotificationPermission();
      if (hasPermission) {
        showNotification(title, options);
      }
    }
  };

  return {
    theme,
    toggleTheme,
    isDark: theme === 'dark',
    requestNotificationPermission,
    showNotification
  };
} 